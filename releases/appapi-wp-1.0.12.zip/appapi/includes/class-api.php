<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 요청 입구: ?r=<route> 를 처리하고 {"ok", "data"|"error"} 로 답한다 (docs/API.md).
 * 앱은 쿠키를 쓰지 않는다: Bearer 토큰으로 이번 요청의 회원을 정하고(determine_current_user), 토큰이 없으면 비회원이다.
 */
class BoardMoa_Api
{
    const VERSION = BOARDMOA_VERSION;

    /** route => [메서드, 로그인 필요(true)/선택(false)/토큰 안 봄(null), 처리] */
    private static function routes()
    {
        return [
            'site' => ['GET', false, ['BoardMoa_Boards', 'site']],
            'menu' => ['GET', false, ['BoardMoa_Boards', 'menu']],
            'auth.login' => ['POST', null, [__CLASS__, 'login']],
            'auth.refresh' => ['POST', null, [__CLASS__, 'refresh']],
            'auth.logout' => ['POST', null, [__CLASS__, 'logout']],
            'me' => ['GET', true, [__CLASS__, 'me']],
            'feed' => ['GET', false, ['BoardMoa_Boards', 'feed']],
            'board' => ['GET', false, ['BoardMoa_Boards', 'board']],
            // POST 도 받는다: 비밀번호 글·비회원 비밀글을 비밀번호(password)로 열 때 주소에 남기지 않으려고
            'document' => ['GET|POST', false, ['BoardMoa_Boards', 'document']],
            'comments' => ['GET', false, ['BoardMoa_Boards', 'comments']],
            'page' => ['GET', false, ['BoardMoa_Boards', 'page']],
            'resolve' => ['GET', false, ['BoardMoa_Boards', 'resolve']],
            'file' => ['GET', false, ['BoardMoa_Boards', 'file']],
            // 비회원도 웹이 허락하면 쓴다 (게시판마다 다르다: 어댑터가 판단)
            'document.write' => ['POST', false, ['BoardMoa_Boards', 'write']],
            'document.source' => ['GET|POST', false, ['BoardMoa_Boards', 'source']],
            'document.update' => ['POST', false, ['BoardMoa_Boards', 'update']],
            'document.delete' => ['POST', false, ['BoardMoa_Boards', 'delete']],
            'comment.write' => ['POST', false, ['BoardMoa_Boards', 'commentWrite']],
            'comment.update' => ['POST', false, ['BoardMoa_Boards', 'commentUpdate']],
            'comment.delete' => ['POST', false, ['BoardMoa_Boards', 'commentDelete']],
            'document.vote' => ['POST', false, ['BoardMoa_Boards', 'vote']],
            // 글 속 설문 (WP-Polls, 0.3.0)
            'poll.vote' => ['POST', false, ['BoardMoa_Boards', 'pollVote']],
            'my.menu' => ['GET', true, ['BoardMoa_My', 'menu']],
            'my.documents' => ['GET', true, ['BoardMoa_My', 'documents']],
            'my.comments' => ['GET', true, ['BoardMoa_My', 'comments']],
            'member.menu' => ['GET', false, ['BoardMoa_My', 'memberMenu']],
            'signup.form' => ['GET', false, ['BoardMoa_My', 'signupForm']],
            'me.form' => ['GET', true, ['BoardMoa_My', 'form']],
            'me.update' => ['POST', true, ['BoardMoa_My', 'update']],
            'me.password' => ['POST', true, ['BoardMoa_My', 'password']],
            // 알림 플러그인이 없으면 앱이 종 아이콘을 숨긴다
            'notify.count' => ['GET', true, [__CLASS__, 'noNotify']],
        ];
    }

    /** @var array 이번 요청의 값 (쿼리 + 본문, JSON 본문도) */
    private static $input = null;
    /** @var object|null 이번 요청의 토큰 행 */
    public static $token = null;
    private static $resolved = false;
    private static $userId = 0;
    private static $authError = null;
    private static $handled = false;

    // ---- 시작

    /** 앱 요청인지: api.php 로 들어왔거나, 워드프레스로 넘어온 예전 주소(modules/appapi/api.php, appapi/index.php) */
    public static function isApiRequest()
    {
        if (defined('BOARDMOA_API_ENTRY')) {
            return true;
        }
        $path = rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH));
        if ($path === '') {
            return false;
        }
        $bases = [];
        foreach ([home_url('/'), site_url('/')] as $url) {
            $bases[] = rtrim((string)parse_url($url, PHP_URL_PATH), '/') . '/';
        }
        // 시험·특수 설정용: mu-plugin 에서 add_filter('boardmoa_legacy_paths', '__return_false') 이면 예전 주소를 받지 않는다
        if (!apply_filters('boardmoa_legacy_paths', true)) {
            return false;
        }
        foreach (array_unique($bases) as $base) {
            foreach (['modules/appapi/api.php', 'appapi/index.php'] as $p) {
                if ($path === $base . $p) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function bootstrap()
    {
        if (!self::isApiRequest()) {
            return;
        }
        define('BOARDMOA_DOING_API', true);
        // 세션을 여는 플러그인(KBoard 등)이 JSON 요청에서는 열지 않는다(wp_is_json_request). 열더라도 쿠키는 보내지 않는다
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        @ini_set('session.use_cookies', '0');
        @ini_set('session.use_only_cookies', '1');
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true); // 페이지 캐시 플러그인이 응답을 저장하지 않게
        }
        add_filter('determine_current_user', [__CLASS__, 'determineUser'], PHP_INT_MAX);
        // 다국어 사이트(Polylang): 앱 화면 언어(X-App-Lang)가 사이트가 쓰는 언어면 이번 요청을 그 언어로 (웹에서 그 언어를 고른 것과 같다)
        add_filter('pll_get_current_language', [__CLASS__, 'polylangLanguage'], PHP_INT_MAX);
        // 모든 플러그인의 init 가 끝난 뒤(게시판 플러그인의 글 종류·처리기가 준비된 뒤), 화면을 그리기 전에 처리하고 끝낸다
        add_action('wp_loaded', [__CLASS__, 'handle'], PHP_INT_MAX);
        // 웹 처리 함수가 die() 로 끝냈을 때: 워드프레스 종료 훅(shutdown)이 출력 버퍼를 내보내기 전에 JSON 오류로 바꾼다
        add_action('shutdown', ['BoardMoa_Run', 'onShutdown'], -PHP_INT_MAX);
        register_shutdown_function(['BoardMoa_Run', 'onShutdown']);
    }

    /** 앱이 보낸 화면 언어 (ko|en, 없으면 '') */
    public static function appLanguage()
    {
        $code = strtolower(substr((string)($_SERVER['HTTP_X_APP_LANG'] ?? ''), 0, 2));
        return in_array($code, ['ko', 'en'], true) ? $code : '';
    }

    /**
     * Polylang: 사이트 언어 가운데 앱 화면 언어(X-App-Lang: ko, en, ja, es, pt-BR, de, fr, it, vi, id, zh-Hant, zh-Hans …)와 같은 것.
     * 고르는 순서: 슬러그·locale 이 그대로 같은 것 → 지역 표시를 뺀 언어(pt-BR → pt, pt_BR) → 중국어 번체(zh-Hant → zh_TW·zh_HK·zh)·간체(zh-Hans → zh_CN·zh_SG·zh).
     * 사이트에 없는 언어면 사이트에 영어가 있을 때 영어, 없으면 Polylang 이 고른 그대로. 머리말이 없으면(예전 앱) 그대로.
     */
    public static function polylangLanguage($current)
    {
        $raw = strtolower(str_replace('_', '-', trim((string)($_SERVER['HTTP_X_APP_LANG'] ?? ''))));
        // 앱 설정 '게시판 언어: 사이트 기본 언어' (1.0.12~): X-Content-Lang: site 면 사이트 언어 그대로
        if (strtolower(trim((string)($_SERVER['HTTP_X_CONTENT_LANG'] ?? ''))) === 'site') {
            return $current;
        }
        if ($raw === '' || !preg_match('/^[a-z]{2,3}(-[a-z0-9]{2,8})*$/', $raw) || !function_exists('PLL') || !isset(PLL()->model)) {
            return $current;
        }
        $base = explode('-', $raw)[0];
        $want = [$raw];
        if ($base === 'zh') {
            $want = array_merge($want, preg_match('/-(hans|cn|sg)\b/', $raw) ? ['zh-cn', 'zh-sg', 'zh'] : ['zh-tw', 'zh-hk', 'zh-hant', 'zh']);
        } else {
            $want[] = $base;
        }
        $langs = [];
        foreach ((array)PLL()->model->get_languages_list() as $lang) {
            if (!isset($lang->active) || !empty($lang->active)) {
                $langs[] = $lang;
            }
        }
        // 중국어: 슬러그가 그냥 zh 인 언어는 locale 로 번체·간체를 가린다(번체 사이트를 간체로 고르지 않게)
        $hans = $base === 'zh' && preg_match('/-(hans|cn|sg)\b/', $raw);
        foreach ($want as $code) {
            foreach ($langs as $lang) {
                $locale = strtolower(str_replace('_', '-', (string)$lang->locale));
                if ($base === 'zh' && $code === 'zh' && $locale !== 'zh' && (bool)preg_match('/^zh-(cn|sg)/', $locale) !== (bool)$hans) {
                    continue;
                }
                if (strtolower((string)$lang->slug) === $code || $locale === $code) {
                    return $lang;
                }
            }
        }
        if ($base !== 'zh') {
            foreach ($langs as $lang) {
                if (strpos(strtolower((string)$lang->locale), $base . '_') === 0) {
                    return $lang;
                }
            }
        }
        // 사이트에 없는 언어: 영어가 있으면 영어
        foreach ($langs as $lang) {
            if ($lang->slug === 'en' || strpos(strtolower((string)$lang->locale), 'en_') === 0) {
                return $lang;
            }
        }
        return $current;
    }

    // ---- 응답

    public static function sendJson($body, $status)
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            if (function_exists('header_remove')) {
                header_remove('Set-Cookie');
                header_remove('Location');
                header_remove('Refresh');
            }
            status_header((int)$status);
            header('Content-Type: application/json; charset=utf-8');
            // 앱 응답은 회원마다 다르다 (Authorization 토큰·X-App-Lang): 페이지 캐시·프록시가 저장하지 않게
            header('Cache-Control: no-store, private');
            header('Vary: Authorization, X-App-Lang, X-Content-Lang');
            header('X-Content-Type-Options: nosniff');
        }
        echo wp_json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function handle()
    {
        if (self::$handled) {
            return;
        }
        self::$handled = true;
        $status = 200;
        try {
            BoardMoa_Store::ensureTables();
            $route = (string)wp_unslash($_GET['r'] ?? '');
            $routes = self::routes();
            if (!isset($routes[$route])) {
                throw new BoardMoa_Error(404, 'unknown_route', 'unknown route', true);
            }
            list($method, $login, $handler) = $routes[$route];
            $methods = explode('|', $method);
            $requestMethod = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
            if (!in_array($requestMethod, $methods, true) && !(in_array('GET', $methods, true) && $requestMethod === 'HEAD')) {
                throw new BoardMoa_Error(405, 'method_not_allowed', 'method not allowed', true);
            }
            if ($login !== null) {
                self::authenticate($login);
            }
            $data = call_user_func($handler);
            if ($data === null) {
                exit; // 처리기가 직접 응답했다 (파일 내려받기)
            }
            $body = ['ok' => true, 'data' => $data];
        } catch (BoardMoa_Error $e) {
            $status = $e->status;
            $body = ['ok' => false, 'error' => array_merge(['code' => $e->codeName, 'message' => $e->raw ? $e->getMessage() : BoardMoa_Text::t($e->getMessage())], $e->extra)];
        } catch (Throwable $e) {
            error_log('[boardmoa] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
            $status = 500;
            $body = ['ok' => false, 'error' => ['code' => 'server_error', 'message' => BoardMoa_Text::t('서버에서 처리하지 못했습니다.')]];
        }
        self::sendJson($body, $status);
        exit;
    }

    public static function message($code)
    {
        $messages = [
            'not_found' => '없는 페이지입니다.',
            'not_permitted' => '권한이 없습니다.',
            'login_required' => '로그인이 필요합니다.',
        ];
        return BoardMoa_Text::t(isset($messages[$code]) ? $messages[$code] : '처리하지 못했습니다.');
    }

    /** 권한 없음: 비회원이면 401(앱이 로그인을 권한다), 회원이면 403 */
    public static function denied($message = null)
    {
        return new BoardMoa_Error(is_user_logged_in() ? 403 : 401, 'not_permitted', $message !== null ? $message : '권한이 없습니다.');
    }

    // ---- 입력

    private static function input()
    {
        if (self::$input === null) {
            $input = wp_unslash($_GET);
            $type = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
            if (strpos($type, 'application/json') !== false) {
                $json = json_decode((string)file_get_contents('php://input'), true);
                if (is_array($json)) {
                    $input = array_merge($input, $json);
                }
            } else {
                $input = array_merge($input, wp_unslash($_POST));
            }
            self::$input = $input;
        }
        return self::$input;
    }

    public static function param($name, $default = null)
    {
        $input = self::input();
        if (!array_key_exists($name, $input) || $input[$name] === null) {
            return $default;
        }
        $value = $input[$name];
        if (is_bool($value)) {
            return $value ? '1' : '';
        }
        return is_scalar($value) ? (string)$value : $value;
    }

    public static function intParam($name, $default = 0)
    {
        $value = self::param($name);
        return is_numeric($value) ? (int)$value : $default;
    }

    public static function boolParam($name)
    {
        $value = self::param($name, '');
        return in_array(strtolower((string)$value), ['1', 'true', 'y', 'yes', 'on'], true);
    }

    public static function ip()
    {
        return (string)($_SERVER['REMOTE_ADDR'] ?? '');
    }

    // ---- 인증

    private static function bearer()
    {
        // Apache 는 설정에 따라 Authorization 을 PHP 에 넘기지 않는다: 리디렉트 변수·원본 머리말도 본다
        $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
        if ($header === '') {
            $header = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        }
        if ($header === '' && function_exists('apache_request_headers')) {
            foreach ((array)apache_request_headers() as $name => $value) {
                if (strtolower($name) === 'authorization') {
                    $header = (string)$value;
                }
            }
        }
        return stripos($header, 'Bearer ') === 0 ? trim(substr($header, 7)) : '';
    }

    /**
     * 이번 요청의 회원 (determine_current_user, 가장 마지막에): 토큰의 회원. 토큰이 없으면 비회원 — 쿠키 로그인은 보지 않는다.
     * 매번 회원 상태를 다시 본다: 지운 회원·비밀번호를 바꾼 회원이면 토큰을 지운다.
     */
    public static function determineUser($userId)
    {
        if (self::$resolved) {
            return self::$userId ?: false;
        }
        self::$resolved = true;
        self::$userId = 0;
        $access = self::bearer();
        if ($access === '') {
            return false;
        }
        $row = BoardMoa_Store::findByAccess($access);
        if (!$row) {
            self::$authError = ['token_expired', 'access token expired'];
            return false;
        }
        $user = get_userdata((int)$row->user_id);
        if (!$user || (is_multisite() && is_user_spammy($user)) || self::userBlocked($user)) {
            BoardMoa_Store::revokeUser((int)$row->user_id);
            self::$authError = ['session_revoked', '로그인할 수 없는 계정입니다.'];
            return false;
        }
        if (!hash_equals((string)$row->password_sig, BoardMoa_Store::passwordSig($user->user_pass))) {
            BoardMoa_Store::revoke((int)$row->token_id);
            self::$authError = ['session_revoked', 'password changed'];
            return false;
        }
        if (!self::appPasswordAlive($row, $user)) {
            BoardMoa_Store::revoke((int)$row->token_id);
            self::$authError = ['session_revoked', 'application password revoked'];
            return false;
        }
        self::$token = $row;
        self::$userId = (int)$user->ID;
        return self::$userId;
    }

    /**
     * 애플리케이션 비밀번호로 로그인한 토큰이면 그 비밀번호가 아직 있는가 (프로필 화면에서 지우면 REST 처럼 앱도 끊긴다).
     * 사이트·회원에게 애플리케이션 비밀번호를 끈 경우(보안 플러그인 등)도 끊는다.
     */
    private static function appPasswordAlive($row, $user)
    {
        $uuid = isset($row->app_password) ? (string)$row->app_password : '';
        if ($uuid === '') {
            return true;
        }
        if (!class_exists('WP_Application_Passwords') || !method_exists('WP_Application_Passwords', 'get_user_application_password')) {
            return false;
        }
        if (function_exists('wp_is_application_passwords_available_for_user') && !wp_is_application_passwords_available_for_user($user)) {
            return false;
        }
        return (bool)WP_Application_Passwords::get_user_application_password((int)$user->ID, $uuid);
    }

    /** 프로필 화면의 '모든 곳에서 로그아웃'·'다른 곳에서 모두 로그아웃'(wp_ajax_destroy-sessions): 앱 토큰도 모두 지운다 (웹과 같은 확인을 거친 경우만) */
    public static function onDestroySessions()
    {
        $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
        $user = $userId ? get_userdata($userId) : null;
        if (!$user || !current_user_can('edit_user', $user->ID) || !isset($_POST['nonce']) || !wp_verify_nonce(wp_unslash($_POST['nonce']), 'update-user_' . $user->ID)) {
            return; // 워드프레스 처리기가 거절한다
        }
        BoardMoa_Store::revokeUser($user->ID);
    }

    /** 애플리케이션 비밀번호를 지우면(프로필 화면·REST) 그 비밀번호로 받은 앱 토큰도 지운다 */
    public static function onDeleteAppPassword($userId, $item)
    {
        if (is_array($item) && !empty($item['uuid'])) {
            BoardMoa_Store::revokeAppPassword((int)$userId, (string)$item['uuid']);
        }
    }

    /**
     * 웹에서 더는 로그인할 수 없는 회원인가: Ultimate Member 가 막은(비활성·거절·승인 대기) 계정.
     * 다른 플러그인은 boardmoa_user_blocked 필터로 알린다.
     */
    private static function userBlocked($user)
    {
        $blocked = false;
        if (class_exists('UM') || function_exists('UM')) {
            $status = (string)get_user_meta((int)$user->ID, 'account_status', true);
            $blocked = $status !== '' && $status !== 'approved';
        }
        return (bool)apply_filters('boardmoa_user_blocked', $blocked, $user);
    }

    private static function authenticate($required)
    {
        $user = wp_get_current_user(); // determineUser 를 부른다
        if (self::$authError) {
            throw new BoardMoa_Error(401, self::$authError[0], self::$authError[1]);
        }
        if (!$user || !$user->ID) {
            if ($required) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            return;
        }
        if (self::$token) {
            BoardMoa_Store::touch(self::$token);
        }
    }

    public static function login()
    {
        $id = trim((string)self::param('user_id', ''));
        $password = (string)self::param('password', '');
        if ($id === '' || $password === '') {
            throw new BoardMoa_Error(400, 'missing_credentials', '아이디와 비밀번호를 입력하세요.');
        }
        // 로그인 양식에 CAPTCHA 를 넣는 플러그인: 앱이 풀 수 있으면 답부터 (웹 양식에는 늘 위젯이 있다)
        BoardMoa_Captcha::check('login');
        // 워드프레스의 애플리케이션 비밀번호도 받는다 (REST·XML-RPC 처럼 앱 요청이다). 2단계 인증을 쓰는 회원이 앱에서 로그인하는 길
        $apiRequest = function () {
            return true;
        };
        add_filter('application_password_is_api_request', $apiRequest, PHP_INT_MAX);
        $appPasswordsBefore = did_action('application_password_did_authenticate');
        $appPasswordUuid = '';
        $captureUuid = function ($authUser, $item) use (&$appPasswordUuid) {
            $appPasswordUuid = is_array($item) && isset($item['uuid']) ? (string)$item['uuid'] : '';
        };
        add_action('application_password_did_authenticate', $captureUuid, 10, 2);
        // 웹 로그인(wp_signon)과 같은 확인: authenticate 필터(아이디·이메일·비밀번호, 보안 플러그인의 실패 횟수 제한·2단계 인증 등)와 wp_login_failed
        $run = BoardMoa_Run::call(function () use ($id, $password) {
            return wp_authenticate($id, $password);
        });
        remove_filter('application_password_is_api_request', $apiRequest, PHP_INT_MAX);
        remove_action('application_password_did_authenticate', $captureUuid, 10);
        $viaAppPassword = did_action('application_password_did_authenticate') > $appPasswordsBefore;
        $user = $run['value'];
        if ($run['redirect'] !== null || $run['died'] !== null) {
            throw new BoardMoa_Error(403, 'not_permitted', $run['died'] ?: BoardMoa_Text::t('웹사이트에서 로그인해 주세요.'), (bool)$run['died']);
        }
        if (is_wp_error($user)) {
            $code = $user->get_error_code();
            if (in_array($code, ['incorrect_password', 'invalid_username', 'invalid_email', 'empty_username', 'empty_password', 'authentication_failed',
                'application_passwords_disabled', 'application_passwords_disabled_for_user', 'invalid_application_credentials'], true)) {
                throw new BoardMoa_Error(401, 'login_failed', self::socialUser($id) ? '아이디 또는 비밀번호가 맞지 않습니다. 소셜 로그인으로 가입한 계정이면 웹사이트에서 비밀번호를 정한 뒤 앱에서 로그인해 주세요.' : '아이디 또는 비밀번호가 맞지 않습니다.');
            }
            $message = self::errorText($user);
            if (BoardMoa_Captcha::isError($user)) {
                throw BoardMoa_Captcha::error('login', BoardMoa_Captcha::widget('login') ? null : ($message !== '' ? $message : null));
            }
            if ($code === 'wfls_twofactor_required') {
                // Wordfence: 앱에는 코드 칸이 없다. Wordfence 는 비밀번호 바로 뒤에 붙인 6자리 코드도 받는다
                throw new BoardMoa_Error(403, 'not_permitted', '이 계정은 2단계 인증을 씁니다. 비밀번호 칸에 비밀번호와 인증 앱의 6자리 코드를 이어서 넣어 주세요.', false, ['two_factor' => 'code_after_password']);
            }
            // 보안 플러그인(로그인 제한·차단·2단계 인증)이 막은 까닭은 그대로 보여 준다
            throw new BoardMoa_Error(403, 'not_permitted', $message !== '' ? $message : BoardMoa_Text::t('로그인할 수 없습니다.'), $message !== '');
        }
        if (!$user instanceof WP_User) {
            throw new BoardMoa_Error(401, 'login_failed', '아이디 또는 비밀번호가 맞지 않습니다.');
        }
        if (!$viaAppPassword) {
            // 2단계 인증 플러그인은 웹 로그인 끝(wp_login)에서 코드 화면을 띄운다. 앱에는 그 화면이 없어 먼저 알린다
            if (self::usesTwoFactor($user)) {
                $appPassword = function_exists('wp_is_application_passwords_available_for_user') && wp_is_application_passwords_available_for_user($user);
                throw new BoardMoa_Error(403, 'not_permitted', $appPassword
                    ? '이 계정은 2단계 인증을 씁니다. 웹사이트의 프로필 화면에서 애플리케이션 비밀번호를 만들어 비밀번호 대신 넣어 주세요.'
                    : '이 계정은 2단계 인증을 써서 앱에서 로그인할 수 없습니다.', false, ['two_factor' => $appPassword ? 'app_password' : 'web']);
            }
            wp_set_current_user($user->ID);
            // 웹 로그인 끝의 wp_login 훅 (로그인 기록·2단계 인증 플러그인). 이동하려 하면 무시하고, 화면을 찍고 끝내면(코드 입력 화면 등) 앱에서는 할 수 없다고 알린다
            $run = BoardMoa_Run::call(function () use ($user) {
                do_action('wp_login', $user->user_login, $user);
            }, 'not_permitted', 403, BoardMoa_Text::t('이 사이트는 로그인할 때 웹에서 추가 확인(2단계 인증 등)을 해야 합니다.'));
            if ($run['died'] !== null) {
                throw new BoardMoa_Error(403, 'not_permitted', $run['died'], true);
            }
            // 로그인 화면의 다음 단계(2단계 인증 설정·코드 입력 등)로 보내려 하면 앱에서는 할 수 없다. 다른 곳으로 보내는 것(로그인 뒤 이동)은 무시한다
            if ($run['redirect'] !== null && self::isLoginStep($run['redirect'])) {
                throw new BoardMoa_Error(403, 'not_permitted', '이 사이트는 로그인할 때 웹에서 추가 확인(2단계 인증 등)을 해야 합니다.', false, ['two_factor' => 'web']);
            }
        }
        wp_set_current_user($user->ID);
        $user = get_userdata($user->ID);
        if ($viaAppPassword && $appPasswordUuid === '') {
            throw new BoardMoa_Error(403, 'not_permitted', '로그인할 수 없습니다.');
        }
        $tokens = BoardMoa_Store::issue($user->ID, $user->user_pass, self::param('device_name', ''), self::param('platform', ''), self::ip(), $viaAppPassword ? $appPasswordUuid : '');
        return ['tokens' => $tokens, 'member' => self::profile($user)];
    }

    /** 플러그인 오류 문구 (태그·엔티티를 풀고, 앞의 'ERROR:'·'오류:' 는 뺀다) */
    private static function errorText($wpError)
    {
        $message = trim(html_entity_decode(wp_strip_all_tags($wpError->get_error_message()), ENT_QUOTES, 'UTF-8'));
        return trim(preg_replace('/^(ERROR|Error|오류)\s*:\s*/u', '', $message));
    }

    /** 이동할 곳이 로그인 화면(wp-login.php·로그인 주소를 바꾸는 플러그인의 주소)인가 */
    private static function isLoginStep($url)
    {
        $path = untrailingslashit((string)parse_url((string)$url, PHP_URL_PATH));
        $login = untrailingslashit((string)parse_url(wp_login_url(), PHP_URL_PATH));
        return $path !== '' && ($path === $login || substr($path, -12) === 'wp-login.php');
    }

    /** 2단계 인증을 쓰는 회원 (Two Factor, WP 2FA, Really Simple Security). 다른 플러그인은 boardmoa_two_factor_required 필터 */
    private static function usesTwoFactor($user)
    {
        $uses = false;
        if (class_exists('Two_Factor_Core') && method_exists('Two_Factor_Core', 'is_user_using_two_factor')) {
            $uses = Two_Factor_Core::is_user_using_two_factor($user->ID);
        }
        if (!$uses && class_exists('WP2FA\Admin\Helpers\User_Helper') && method_exists('WP2FA\Admin\Helpers\User_Helper', 'is_user_using_two_factor')) {
            $uses = (bool)WP2FA\Admin\Helpers\User_Helper::is_user_using_two_factor($user->ID);
        }
        $rsssl = 'RSSSL\\Security\\WordPress\\Two_Fa\\Rsssl_Two_Factor';
        if (!$uses && class_exists($rsssl) && method_exists($rsssl, 'is_user_using_two_factor')) {
            try {
                $uses = (bool)$rsssl::is_user_using_two_factor($user);
            } catch (Throwable $e) {
                $uses = false;
            }
        }
        return (bool)apply_filters('boardmoa_two_factor_required', $uses, $user);
    }

    /**
     * 소셜 로그인(Nextend Social Login 등)이 연결된 계정인지: 비밀번호가 틀렸을 때 알맞은 안내를 하려고.
     * 소셜로 가입한 회원은 가입 플러그인이 만든 임의 비밀번호라 비밀번호를 정하기(웹 프로필·비밀번호 찾기) 전에는 비밀번호로 못 들어온다.
     * 다른 소셜 로그인 플러그인은 boardmoa_social_user 필터로 알린다.
     */
    private static function socialUser($login)
    {
        $user = is_email($login) ? get_user_by('email', $login) : get_user_by('login', $login);
        if (!$user) {
            return false;
        }
        $social = false;
        global $wpdb;
        $table = $wpdb->prefix . 'social_users';
        if (class_exists('NextendSocialLogin') && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
            $social = (bool)$wpdb->get_var($wpdb->prepare("SELECT 1 FROM `$table` WHERE ID = %d LIMIT 1", $user->ID));
        }
        return (bool)apply_filters('boardmoa_social_user', $social, $user);
    }

    public static function refresh()
    {
        $result = BoardMoa_Store::rotate((string)self::param('refresh_token', ''), self::ip());
        if (!$result) {
            throw new BoardMoa_Error(401, 'refresh_invalid', 'login required', true);
        }
        $row = $result[0];
        $user = get_userdata((int)$row->user_id);
        if (!$user || !hash_equals((string)$row->password_sig, BoardMoa_Store::passwordSig($user->user_pass))
            || (is_multisite() && is_user_spammy($user)) || self::userBlocked($user) || !self::appPasswordAlive($row, $user)) {
            BoardMoa_Store::revoke((int)$row->token_id);
            throw new BoardMoa_Error(401, 'session_revoked', '로그인할 수 없는 계정입니다.');
        }
        return ['tokens' => $result[1]];
    }

    public static function logout()
    {
        $row = BoardMoa_Store::findByAccess(self::bearer());
        if (!$row && self::param('refresh_token')) {
            $result = BoardMoa_Store::rotate((string)self::param('refresh_token'), self::ip());
            $row = $result ? $result[0] : null;
        }
        if ($row) {
            BoardMoa_Store::revoke((int)$row->token_id);
        }
        return ['logged_out' => true];
    }

    public static function me()
    {
        return self::profile(wp_get_current_user());
    }

    /** 앱의 member 객체 (비회원이면 null) */
    public static function profile($user = null)
    {
        $user = $user ?: wp_get_current_user();
        if (!$user || !$user->ID) {
            return null;
        }
        $groups = [];
        $names = wp_roles()->get_names();
        foreach ((array)$user->roles as $role) {
            $groups[] = isset($names[$role]) ? translate_user_role($names[$role]) : (string)$role;
        }
        return [
            'member_srl' => (int)$user->ID,
            'user_id' => (string)$user->user_login,
            'nick_name' => (string)$user->display_name,
            'email_address' => $user->user_email ? (string)$user->user_email : null,
            'profile_image' => self::avatar($user->ID),
            'groups' => $groups,
            'is_admin' => user_can($user, 'manage_options'),
        ];
    }

    /**
     * 프로필 사진: 사이트가 아바타를 보이고(설정 → 토론), 회원 사진 플러그인이 정한 사진일 때만.
     * 그라바타 기본값(회색 사람)은 앱의 기본 모양이 더 낫고 사진마다 외부 요청이 생겨 보내지 않는다.
     */
    public static function avatar($userId)
    {
        static $cache = [];
        $userId = (int)$userId;
        if ($userId <= 0 || !get_option('show_avatars')) {
            return null;
        }
        if (!array_key_exists($userId, $cache)) {
            $url = (string)get_avatar_url($userId, ['size' => 96]);
            $host = strtolower((string)parse_url($url, PHP_URL_HOST));
            $cache[$userId] = ($url !== '' && strpos($host, 'gravatar.com') === false) ? BoardMoa_Html::absolute($url) : null;
        }
        return $cache[$userId];
    }

    public static function noNotify()
    {
        return ['enabled' => false, 'unread' => 0];
    }
}
