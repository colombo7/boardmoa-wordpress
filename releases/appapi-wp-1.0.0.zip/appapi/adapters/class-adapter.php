<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 게시판 어댑터: 워드프레스 글·KBoard·망보드·bbPress 마다 하나.
 * 게시판 = ['mid', 'title', 'adapter', 'module' => 'board'|'page', 'ref' => 어댑터가 쓰는 값, 'url' => 웹 주소]
 * 권한 판단은 각 플러그인이 웹 화면에서 쓰는 함수를 부르거나 같은 순서로 따라 한다. 웹보다 더 보여 주지 않는다.
 */
abstract class BoardMoa_Adapter
{
    abstract public function key();

    abstract public function available();

    /** @return array[] 이 어댑터의 모든 게시판 (권한과 상관없이) */
    abstract public function boards();

    /** 이 사이트가 이 어댑터로 할 줄 아는 기능 (site.features) */
    public function features()
    {
        return [];
    }

    /** 메뉴 줄이 이 어댑터의 것이면 ['mid' => …|null, 'expand' => 아래 줄|null], 아니면 null */
    public function fromMenuNode($node)
    {
        return null;
    }

    /** 메뉴에 없을 때 '게시판' 묶음에 더할 줄 (['mid' => …, 'title' => …] 또는 묶음) */
    public function menuBoards()
    {
        return [];
    }

    /** 목록을 볼 수 있는가 (메뉴·모아 보기에 나와도 되는가) — 웹에서 그 게시판 화면이 열리는가와 같다 */
    abstract public function canList($board);

    /** ['list', 'view', 'write_document', 'write_comment', 'manager'] */
    abstract public function grant($board);

    /** 모아 보기에 넣는가 (자기 글만 보는 게시판은 뺀다) */
    public function inFeed($board)
    {
        return true;
    }

    /** board 응답 */
    abstract public function listPage($board);

    /** 모아 보기용 최근 글 [['time' => 유닉스 시각, 'summary' => 문서요약]] (최신순, $limit 개까지) */
    abstract public function recent($board, $limit);

    abstract public function document($board, $srl);

    abstract public function comments($board, $srl);

    /** 글 번호가 이 어댑터의 것이면 그 게시판 (resolve) */
    public function boardOfDocument($srl)
    {
        return null;
    }

    /** 같은 사이트 주소가 이 어댑터의 게시판·글이면 ['mid', 'document_srl'?] */
    public function locate($url)
    {
        return null;
    }

    public function file($board)
    {
        throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
    }

    public function write($board)
    {
        throw BoardMoa_Api::denied();
    }

    public function source($board, $srl)
    {
        throw BoardMoa_Api::denied();
    }

    public function update($board, $srl)
    {
        throw BoardMoa_Api::denied();
    }

    public function delete($board, $srl)
    {
        throw BoardMoa_Api::denied();
    }

    public function commentWrite($board, $srl)
    {
        throw BoardMoa_Api::denied();
    }

    public function commentUpdate($board, $commentSrl)
    {
        throw BoardMoa_Api::denied();
    }

    public function commentDelete($board, $commentSrl)
    {
        throw BoardMoa_Api::denied();
    }

    public function vote($board, $srl)
    {
        throw new BoardMoa_Error(403, 'not_permitted', '이 게시판은 추천을 쓰지 않습니다.');
    }

    public function page($board)
    {
        throw new BoardMoa_Error(400, 'not_page', 'not a page', true);
    }

    // ---- 공통 모양

    /** board 응답의 board (앱 BoardInfo). 어댑터가 준 값 위에 기본값 */
    protected function boardInfo($board, array $grant, array $extra = [])
    {
        $loggedIn = is_user_logged_in();
        return array_merge([
            'mid' => $board['mid'],
            'title' => $board['title'],
            'style' => 'list',
            'columns' => ['read_count' => false, 'vote_count' => false],
            'use_secret' => false,
            'categories' => [],
            'grant' => [
                'list' => (bool)$grant['list'], 'view' => (bool)$grant['view'], 'write_document' => (bool)$grant['write_document'],
                'write_comment' => (bool)$grant['write_comment'], 'manager' => (bool)$grant['manager'],
            ],
            'upload' => ['allowed' => false, 'max_file_size' => null, 'max_total_size' => null],
            'category_required' => false,
            'extra_keys' => [],
            'captcha' => ['document' => false, 'comment' => false],
            'captcha_widget' => null,
            'write_url' => $board['url'] ? BoardMoa_Html::absolute($board['url']) : null,
            'guest_fields' => null,
            'guest_comment_fields' => null,
            'guest_certify_fields' => $loggedIn ? null : ['password'],
        ], $extra);
    }

    /** 문서요약 기본값 */
    protected function summary(array $values)
    {
        return array_merge([
            'document_srl' => 0, 'title' => '', 'author' => '', 'author_image' => null, 'author_srl' => 0, 'is_mine' => false,
            'regdate' => null, 'last_update' => null, 'category_srl' => 0, 'comment_count' => 0, 'read_count' => null, 'vote_count' => null,
            'is_notice' => false, 'is_secret' => false, 'has_files' => false, 'thumbnail' => null, 'summary' => '',
        ], $values);
    }

    /** 본문 응답에 꼭 있어야 하는 것 */
    protected function detail(array $summary, array $values)
    {
        return array_merge($summary, [
            'content_html' => null, 'files' => [], 'extra_vars' => [], 'permanent_url' => null,
            'can_comment' => false, 'can_edit' => false, 'can_delete' => false, 'password_edit' => false, 'password_view' => false,
            'actions' => null, 'comments' => self::emptyComments(),
        ], $values);
    }

    public static function emptyComments()
    {
        return ['items' => [], 'page' => 1, 'total_pages' => 1, 'total_count' => 0];
    }

    protected function commentItem(array $values)
    {
        return array_merge([
            'comment_srl' => 0, 'parent_srl' => 0, 'depth' => 0, 'author' => '', 'author_image' => null, 'author_srl' => 0, 'is_mine' => false,
            'regdate' => null, 'is_secret' => false, 'content_html' => null, 'vote_count' => 0, 'can_delete' => false, 'can_edit' => false,
            'password_edit' => false, 'files' => [],
        ], $values);
    }

    /** 페이지 나누기 */
    protected static function pageArgs($perPage)
    {
        $page = max(1, BoardMoa_Api::intParam('page', 1));
        return [$page, max(1, (int)$perPage)];
    }

    /** 검색어·대상 */
    protected static function search()
    {
        $keyword = trim((string)BoardMoa_Api::param('search_keyword', ''));
        $target = (string)BoardMoa_Api::param('search_target', 'title_content');
        return [$keyword, $target];
    }

    /** multipart photos[] — 정상 업로드인 그림만, 30장까지. $_FILES 꼴 배열 목록 */
    protected static function photos()
    {
        if (empty($_FILES['photos'])) {
            return [];
        }
        $f = $_FILES['photos'];
        $list = [];
        if (is_array($f['name'])) {
            foreach ($f['name'] as $i => $name) {
                $list[] = ['name' => $name, 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
            }
        } else {
            $list[] = $f;
        }
        if (count($list) > 30) {
            throw new BoardMoa_Error(400, 'too_many_photos', '사진은 한 번에 30장까지 올릴 수 있습니다.');
        }
        foreach ($list as $file) {
            if ((int)$file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
                throw new BoardMoa_Error(400, 'upload_failed', '사진을 올리지 못했습니다.');
            }
        }
        return $list;
    }

    /** 사진 크기 꼴 (앱의 photo_width) */
    protected static function photoStyle()
    {
        $width = (string)BoardMoa_Api::param('photo_width', 'full');
        return $width === 'half' ? 'width:50%;height:auto;' : ($width === 'original' ? 'max-width:100%;height:auto;' : 'width:100%;height:auto;');
    }
}
