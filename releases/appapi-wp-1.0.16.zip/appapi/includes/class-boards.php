<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 사이트·메뉴·모아 보기와, 게시판 요청을 알맞은 어댑터로 보내는 곳.
 *
 * 게시판(mid)은 어댑터가 정한다:
 *   posts (글 전체) · cat-<분류 번호> · page-<글 번호>(페이지·글 하나)  — 워드프레스 (BoardMoa_Core)
 *   kb-<게시판 번호>                                                   — KBoard
 *   mb-<게시판 이름>                                                   — 망보드
 *   forum-<포럼 번호>                                                  — bbPress
 * 메뉴는 사이트 메뉴(클래식 테마의 메뉴 위치, 블록 테마의 내비게이션)를 따른다. 메뉴에 없는 게시판은 '게시판' 묶음에 더한다.
 * 목록을 볼 수 없는 게시판은 메뉴·모아 보기·링크 어디에도 내보내지 않는다.
 */
class BoardMoa_Boards
{
    /** 모아 보기·내 활동의 마지막 쪽 (쪽마다 모든 게시판에서 그만큼 모아 고른다) */
    const MAX_FEED_PAGE = 50;

    /** @var BoardMoa_Adapter[]|null */
    private static $adapters = null;
    private static $all = null;

    /** @return BoardMoa_Adapter[] 설치된 것만 (key => 어댑터) */
    public static function adapters()
    {
        if (self::$adapters === null) {
            self::$adapters = [];
            // 페이지 안의 게시판(KBoard·망보드)·포럼을 먼저 알아보고, 나머지는 워드프레스 글·페이지로
            foreach ([new BoardMoa_KBoard(), new BoardMoa_Mangboard(), new BoardMoa_BBPress(), new BoardMoa_Core()] as $adapter) {
                if ($adapter->available()) {
                    self::$adapters[$adapter->key()] = $adapter;
                }
            }
        }
        return self::$adapters;
    }

    /** @return BoardMoa_Adapter|null */
    public static function adapter($key)
    {
        $adapters = self::adapters();
        return isset($adapters[$key]) ? $adapters[$key] : null;
    }

    /** 모든 게시판 (권한과 상관없이) mid => 게시판 */
    public static function all()
    {
        if (self::$all === null) {
            self::$all = [];
            foreach (self::adapters() as $adapter) {
                foreach ($adapter->boards() as $board) {
                    self::$all[$board['mid']] = $board;
                }
            }
        }
        return self::$all;
    }

    /** mid 의 게시판·페이지 (없으면 null). 페이지(page-<번호>)는 목록에 없어도 찾는다 */
    public static function get($mid)
    {
        $all = self::all();
        if (isset($all[$mid])) {
            return $all[$mid];
        }
        $core = self::adapter('core');
        return $core ? $core->pageBoard($mid) : null;
    }

    /** mid 의 게시판. 없거나 목록을 볼 수 없으면 없는 게시판처럼 404 */
    public static function find($mid, $mustList = true)
    {
        $mid = (string)$mid;
        if (!preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $mid)) {
            throw new BoardMoa_Error(400, 'invalid_mid', 'invalid mid', true);
        }
        $all = self::all();
        if (!isset($all[$mid]) || $all[$mid]['module'] !== 'board') {
            if (isset($all[$mid]) && $all[$mid]['module'] === 'page') {
                throw new BoardMoa_Error(400, 'not_board', 'not a board', true);
            }
            throw new BoardMoa_Error(404, 'board_not_found', '없는 게시판입니다.');
        }
        $board = $all[$mid];
        if ($mustList && !self::adapter($board['adapter'])->canList($board)) {
            throw new BoardMoa_Error(404, 'board_not_found', '없는 게시판입니다.');
        }
        if ($mustList && self::gated($board)) {
            throw BoardMoa_Gate::error();
        }
        if ($mustList && !self::listable($board)) {
            // 게시판이 든 페이지를 볼 수 없다: 비회원은 로그인을 권하고, 회원에게는 없는 게시판
            throw is_user_logged_in() ? new BoardMoa_Error(404, 'board_not_found', '없는 게시판입니다.') : BoardMoa_Gate::error();
        }
        return $board;
    }

    /** 회원만 보는 사이트(Force Login 등)라 비회원에게 막힌 게시판·페이지 */
    public static function gated($board)
    {
        return BoardMoa_Gate::blocks(!empty($board['url']) ? BoardMoa_Html::absolute($board['url']) : home_url('/'));
    }

    /** 목록을 볼 수 있는가: 게시판 플러그인의 판단 + 회원 전용 사이트 */
    public static function listable($board)
    {
        if (!self::adapterOf($board)->canList($board) || self::gated($board)) {
            return false;
        }
        // 게시판이 든 페이지(KBoard·망보드)를 웹에서 볼 수 없으면(비공개 페이지, 회원 등급 플러그인이 가린 페이지) 게시판도 없다
        if (!empty($board['page']) && ($page = get_post((int)$board['page'])) && $page->ID !== (int)get_option('page_on_front')) {
            if (!BoardMoa_Core::readable($page) || BoardMoa_Core::restricted($page)) {
                return false;
            }
        }
        return true;
    }

    /** @return BoardMoa_Adapter */
    public static function adapterOf($board)
    {
        return self::adapter($board['adapter']);
    }

    // ---- 사이트

    public static function site()
    {
        $icon = get_site_icon_url(192);
        $logoId = (int)get_theme_mod('custom_logo');
        $logo = $logoId ? wp_get_attachment_image_url($logoId, 'full') : '';
        $features = ['html_write', 'resolve_path', 'comment_edit', 'edit_photos'];
        foreach (self::adapters() as $adapter) {
            $features = array_merge($features, $adapter->features());
        }
        if (BoardMoa_Polls::available()) {
            $features[] = 'polls'; // WP-Polls 설문 (0.3.0)
        }
        if (BoardMoa_Captcha::widget('login') || BoardMoa_Captcha::widget('comment')) {
            $features[] = 'captcha_solve'; // 로그인·댓글 CAPTCHA (CAPTCHA 4WP, 0.3.0)
        }
        return [
            'name' => BoardMoa_Html::text(get_bloginfo('name')) ?: (string)parse_url(home_url('/'), PHP_URL_HOST),
            // Polylang 으로 사이트 제목을 언어별로 번역해 두었으면 언어별 이름 (1.0.13~, 앱 언어 코드 => 이름)
            'names' => self::siteNames(),
            // 설정 '개발자에게 알리기' (1.0.14~). 끄면 설치 현황 서버가 이 사이트를 목록에 넣지 않고 있던 줄도 지운다
            'share_site' => BoardMoa_Updater::shareSite(),
            'base_url' => trailingslashit(home_url('/')),
            'theme_color' => null,
            'logo_url' => $logo ? BoardMoa_Html::absolute($logo) : null,
            'icon_url' => $icon ? BoardMoa_Html::absolute($icon) : BoardMoa_Html::absolute('/favicon.ico'),
            'home_mid' => self::homeMid(),
            'engine' => 'wordpress',
            'engine_version' => (string)get_bloginfo('version'),
            'api_version' => BoardMoa_Api::VERSION,
            // 쓰는 게시판 플러그인 (새 필드, 예전 앱은 무시한다)
            'boards' => array_keys(self::adapters()),
            'features' => array_values(array_unique($features)),
            'member' => BoardMoa_Api::profile(),
        ];
    }

    /** Polylang '문자열 번역'의 사이트 제목. Polylang 이 없거나 언어가 하나뿐이거나 모두 같으면 null */
    private static function siteNames()
    {
        global $wpdb;
        if (!function_exists('pll_translate_string') || !function_exists('PLL') || !isset(PLL()->model)) {
            return null;
        }
        // 원문: get_option 은 Polylang 이 지금 언어로 바꿔 돌려주므로 DB 값 그대로
        $raw = (string)$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'blogname'));
        if ($raw === '') {
            return null;
        }
        $names = [];
        foreach ((array)PLL()->model->get_languages_list() as $lang) {
            $code = BoardMoa_Api::appLangCode((string)$lang->locale);
            $value = BoardMoa_Html::text((string)pll_translate_string($raw, (string)$lang->slug));
            if ($code !== null && $value !== '' && !isset($names[$code])) {
                $names[$code] = $value;
            }
        }
        return count(array_unique($names)) > 1 ? $names : null;
    }

    /** 첫 화면: 정적 첫 페이지면 그 페이지(게시판이 들어 있으면 그 게시판), 아니면 글 전체 */
    public static function homeMid()
    {
        if (get_option('show_on_front') === 'page' && ($front = (int)get_option('page_on_front'))) {
            $target = self::targetOfPost(get_post($front));
            if ($target && $target['mid']) {
                return $target['mid'];
            }
        }
        return 'posts';
    }

    // ---- 메뉴

    public static function menu()
    {
        $placed = [];
        $items = [];
        foreach (BoardMoa_Menu::tree() as $node) {
            if ($out = self::menuItem($node, $placed)) {
                $items[] = $out;
            }
        }
        $menus = [];
        if ($items) {
            $menus[] = ['id' => 'main_menu', 'title' => BoardMoa_Menu::title(), 'items' => $items];
        }
        // 메뉴에 없는 게시판 (KBoard 를 넣은 페이지가 메뉴에 없을 때 등). 목록을 볼 수 있는 것만
        $extra = [];
        foreach (self::adapters() as $adapter) {
            foreach ($adapter->menuBoards() as $node) {
                if ($out = self::menuItem($node, $placed)) {
                    $extra[] = $out;
                }
            }
        }
        if ($extra) {
            // 앱(예전 앱 포함)은 첫 메뉴만 그린다: 첫 메뉴 끝에 '그 밖의 게시판' 묶음으로도 넣는다 (같은 줄이라 앱은 처음 것만 쓴다)
            if ($menus) {
                $menus[0]['items'][] = ['title' => BoardMoa_Text::t('그 밖의 게시판'), 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $extra];
            }
            $menus[] = ['id' => 'boards', 'title' => BoardMoa_Text::t('게시판'), 'items' => $extra];
        }
        // 회원만 보는 사이트: 비회원에게 보일 것이 없으면 웹처럼 로그인부터 (앱이 로그인을 권한다)
        if (BoardMoa_Gate::siteLocked() && !self::hasBoard($menus)) {
            throw BoardMoa_Gate::error();
        }
        return ['menus' => $menus];
    }

    /** 메뉴에 게시판·페이지(mid)가 하나라도 있는가 */
    private static function hasBoard($items)
    {
        foreach ($items as $item) {
            if (!empty($item['mid']) || self::hasBoard(isset($item['items']) ? $item['items'] : (isset($item['children']) ? $item['children'] : []))) {
                return true;
            }
        }
        return false;
    }

    /**
     * 메뉴 한 줄: 볼 수 없는 것은 빼고, 아래에 볼 것이 남은 경우에만 제목만 있는 묶음(mid null)으로 남긴다.
     * $node: ['title', 'url', 'target', 'object', 'object_id', 'type', 'children' => [...]] 또는 ['mid' => …] (어댑터가 만든 줄)
     */
    private static function menuItem($node, &$placed)
    {
        $target = isset($node['mid']) ? ['mid' => $node['mid'], 'expand' => null] : self::targetOfNode($node);
        $children = [];
        $childNodes = isset($node['children']) ? $node['children'] : [];
        if (!$childNodes && $target && !empty($target['expand'])) {
            $childNodes = $target['expand'];
        }
        foreach ($childNodes as $child) {
            if ($out = self::menuItem($child, $placed)) {
                $children[] = $out;
            }
        }
        $title = BoardMoa_Html::text(isset($node['title']) ? $node['title'] : '');
        $group = ['title' => $title, 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children];
        if ($target === null) {
            // 같은 사이트의 알 수 없는 곳·바깥 링크는 웹으로. '#' 같은 빈 링크는 묶음일 때만
            $url = isset($node['url']) ? trim((string)$node['url']) : '';
            if ($url === '' || $url === '#' || strpos($url, '#') === 0) {
                return $children ? $group : null;
            }
            return ['title' => $title, 'mid' => null, 'module' => null, 'grant' => null, 'url' => BoardMoa_Html::absolute($url),
                'open_window' => isset($node['target']) && $node['target'] === '_blank', 'children' => $children];
        }
        if ($target['mid'] === null) {
            return $children ? $group : null;
        }
        $board = self::get($target['mid']);
        if (!$board) {
            return $children ? $group : null;
        }
        $adapter = self::adapterOf($board);
        if (!self::listable($board)) {
            return $children ? $group : null;
        }
        if (isset($placed[$board['mid']])) {
            // 같은 게시판이 메뉴에 두 번: 앱의 넘겨보기가 꼬이지 않게 처음 것만 (아래 줄이 있으면 제목만 있는 묶음으로)
            return $children ? $group : null;
        }
        $placed[$board['mid']] = true;
        $grant = null;
        if ($board['module'] === 'board') {
            $g = $adapter->grant($board);
            $grant = ['view' => (bool)$g['view'], 'write_document' => (bool)$g['write_document'], 'write_comment' => (bool)$g['write_comment']];
        }
        return [
            'title' => $title !== '' ? $title : $board['title'],
            'mid' => $board['mid'],
            'module' => $board['module'],
            'grant' => $grant,
            'url' => $board['url'] ? BoardMoa_Html::absolute($board['url']) : null,
            'open_window' => false,
            'children' => $children,
        ];
    }

    /** 메뉴 줄이 가리키는 곳: ['mid' => …|null, 'expand' => 아래 줄 목록|null] 또는 null(웹 링크) */
    private static function targetOfNode($node)
    {
        foreach (self::adapters() as $adapter) {
            $target = $adapter->fromMenuNode($node);
            if ($target !== null) {
                return $target;
            }
        }
        return null;
    }

    /** 글 하나(페이지 등)가 가리키는 게시판·페이지 */
    public static function targetOfPost($post)
    {
        if (!$post) {
            return null;
        }
        return self::targetOfNode(['type' => 'post_type', 'object' => $post->post_type, 'object_id' => $post->ID, 'url' => get_permalink($post), 'title' => $post->post_title]);
    }

    // ---- 모아 보기

    /** 목록을 볼 수 있는 게시판 (모아 보기 대상, 메뉴 순서) */
    public static function visibleBoards()
    {
        $boards = [];
        $menu = self::menu();
        $walk = function ($items) use (&$walk, &$boards) {
            foreach ($items as $item) {
                if ($item['module'] === 'board' && $item['mid'] !== null) {
                    $boards[$item['mid']] = true;
                }
                $walk($item['children']);
            }
        };
        foreach ($menu['menus'] as $m) {
            $walk($m['items']);
        }
        $all = self::all();
        $out = [];
        foreach (array_keys($boards) as $mid) {
            if (isset($all[$mid])) {
                $out[$mid] = $all[$mid];
            }
        }
        return $out;
    }

    public static function feed()
    {
        $boards = self::visibleBoards();
        if (!$boards && BoardMoa_Gate::siteLocked()) {
            throw BoardMoa_Gate::error();
        }
        $mids = array_filter(array_map('trim', explode(',', (string)BoardMoa_Api::param('mids', ''))));
        if ($mids) {
            $boards = array_intersect_key($boards, array_flip($mids));
        }
        $count = min(50, max(5, BoardMoa_Api::intParam('list_count', 20)));
        // 게시판마다 page × list_count 개를 모아 고르므로 쪽은 50 까지 (그 뒤는 각 게시판 목록에서)
        $page = min(self::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $need = $page * $count + 1;
        $rows = [];
        foreach ($boards as $board) {
            $adapter = self::adapterOf($board);
            if (!$adapter->inFeed($board)) {
                continue; // 자기 글만 보는 게시판(상담 등)은 모아 보기에서 뺀다
            }
            foreach ($adapter->recent($board, $need) as $row) {
                $row['summary']['mid'] = $board['mid'];
                $row['summary']['board_title'] = $board['title'];
                $rows[] = $row;
            }
        }
        // 최신순. 같은 글이 '글 전체'와 분류 게시판에 다 있으면 분류 쪽 이름으로 보이게 분류를 앞에
        usort($rows, function ($a, $b) {
            return [$b['time'], $a['summary']['mid'] === 'posts' ? 1 : 0] <=> [$a['time'], $b['summary']['mid'] === 'posts' ? 1 : 0];
        });
        $seen = [];
        $unique = [];
        foreach ($rows as $row) {
            $key = $row['summary']['document_srl'];
            if (isset($seen[$key])) {
                continue; // 분류가 여럿인 글은 한 번만
            }
            $seen[$key] = true;
            $unique[] = $row['summary'];
        }
        $documents = array_slice($unique, ($page - 1) * $count, $count);
        $more = count($unique) > $page * $count;
        return ['documents' => $documents, 'page' => $page, 'total_pages' => $more ? $page + 1 : $page];
    }

    // ---- 게시판 요청 (어댑터로)

    public static function board()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->listPage($board);
    }

    public static function document()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        $srl = BoardMoa_Api::intParam('document_srl');
        if (!$srl) {
            throw new BoardMoa_Error(400, 'missing_document_srl', 'document_srl is required', true);
        }
        // 회원 전용 사이트에서 게시판 화면은 열려도 글 화면은 막힌 경우 (Force Login 예외 주소 등).
        // 주소를 미리 알 수 있으면 글을 열기 전에(조회수·읽기 포인트가 움직이기 전에) 본다
        $pre = self::adapterOf($board)->documentUrl($board, $srl);
        if ($pre && BoardMoa_Gate::blocks(BoardMoa_Html::absolute($pre))) {
            throw BoardMoa_Gate::error();
        }
        $doc = self::adapterOf($board)->document($board, $srl);
        if (!empty($doc['permanent_url']) && BoardMoa_Gate::blocks(BoardMoa_Html::absolute($doc['permanent_url']))) {
            throw BoardMoa_Gate::error();
        }
        return $doc;
    }

    public static function comments()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        $srl = BoardMoa_Api::intParam('document_srl');
        if (BoardMoa_Gate::siteLocked()) {
            // 회원 전용 사이트(비회원)에서만: 글 화면이 막혔으면 댓글도 (앱은 글을 먼저 열어 보통은 여기 오지 않는다)
            $pre = self::adapterOf($board)->documentUrl($board, $srl);
            if ($pre && BoardMoa_Gate::blocks(BoardMoa_Html::absolute($pre))) {
                throw BoardMoa_Gate::error();
            }
            $doc = self::adapterOf($board)->document($board, $srl);
            if (!empty($doc['permanent_url']) && BoardMoa_Gate::blocks(BoardMoa_Html::absolute($doc['permanent_url']))) {
                throw BoardMoa_Gate::error();
            }
        }
        return self::adapterOf($board)->comments($board, $srl);
    }

    public static function file()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->file($board);
    }

    public static function write()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->write($board);
    }

    public static function source()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->source($board, BoardMoa_Api::intParam('document_srl'));
    }

    public static function update()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->update($board, BoardMoa_Api::intParam('document_srl'));
    }

    public static function delete()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->delete($board, BoardMoa_Api::intParam('document_srl'));
    }

    public static function commentWrite()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->commentWrite($board, BoardMoa_Api::intParam('document_srl'));
    }

    public static function commentUpdate()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->commentUpdate($board, BoardMoa_Api::intParam('comment_srl'));
    }

    public static function commentDelete()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->commentDelete($board, BoardMoa_Api::intParam('comment_srl'));
    }

    public static function pollVote()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        $adapter = self::adapterOf($board);
        if (!method_exists($adapter, 'pollVote')) {
            throw new BoardMoa_Error(404, 'poll_not_found', '없는 설문입니다.');
        }
        return $adapter->pollVote($board, BoardMoa_Api::intParam('document_srl'));
    }

    public static function vote()
    {
        $board = self::find(BoardMoa_Api::param('mid'));
        return self::adapterOf($board)->vote($board, BoardMoa_Api::intParam('document_srl'));
    }

    // ---- 페이지·링크

    public static function page()
    {
        $board = self::get((string)BoardMoa_Api::param('mid', ''));
        if ($board && self::adapterOf($board)->canList($board) && self::gated($board)) {
            throw BoardMoa_Gate::error();
        }
        if (!$board || !self::listable($board)) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        if ($board['module'] !== 'page') {
            throw new BoardMoa_Error(400, 'not_page', 'not a page', true);
        }
        return self::adapterOf($board)->page($board);
    }

    /** 같은 사이트 주소가 가리키는 게시판·글 ['mid', 'module', 'title', 'document_srl'] (볼 수 없으면 null) */
    public static function locate($url)
    {
        static $cache = [];
        if (array_key_exists($url, $cache)) {
            return $cache[$url];
        }
        $found = null;
        // 웹 화면으로 열라고 표시한 링크(본문 속 양식 자리)는 풀지 않는다 → 앱이 브라우저로 연다
        if (strpos((string)parse_url($url, PHP_URL_QUERY), 'boardmoa_web=') !== false) {
            return $cache[$url] = null;
        }
        foreach (self::adapters() as $adapter) {
            $found = $adapter->locate($url);
            if ($found) {
                break;
            }
        }
        if ($found) {
            $board = self::get($found['mid']);
            if (!$board || !self::listable($board)) {
                $found = null;
            } else {
                $found = ['mid' => $board['mid'], 'module' => $board['module'], 'title' => $board['title'],
                    'document_srl' => !empty($found['document_srl']) ? (int)$found['document_srl'] : null];
            }
        }
        return $cache[$url] = $found;
    }

    /**
     * 링크 풀이 (docs/API.md resolve). mid·document_srl, 또는 path(새 앱, 기능 resolve_path).
     * 워드프레스 주소 꼴(/글-슬러그/, /category/news/, /?p=1, KBoard 의 ?uid=…)도 푼다.
     */
    public static function resolve()
    {
        $mid = (string)BoardMoa_Api::param('mid', '');
        $srl = BoardMoa_Api::intParam('document_srl');
        $path = (string)(BoardMoa_Api::param('path', '') ?: BoardMoa_Api::param('url', ''));
        if ($mid !== '' && ($board = self::get($mid)) && $path === '') {
            if (!self::listable($board)) {
                throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
            }
            return ['mid' => $board['mid'], 'module' => $board['module'], 'title' => $board['title'], 'document_srl' => $srl ?: null];
        }
        if ($mid === '' && $srl && $path === '') {
            foreach (self::adapters() as $adapter) {
                if ($board = $adapter->boardOfDocument($srl)) {
                    if (!self::listable($board)) {
                        break;
                    }
                    return ['mid' => $board['mid'], 'module' => $board['module'], 'title' => $board['title'], 'document_srl' => $srl];
                }
            }
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        // 앱이 경로 첫 칸을 mid 로 보낸 경우(/글-슬러그/)도 주소로 푼다
        if ($path === '' && $mid !== '') {
            $path = '/' . $mid . '/';
        }
        if ($path === '') {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        $url = preg_match('#^(https?:)?//#i', $path) ? $path : BoardMoa_Html::origin() . '/' . ltrim($path, '/');
        $found = self::locate($url);
        if (!$found) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        return $found;
    }
}

/** 사이트 메뉴 읽기: 클래식 테마의 메뉴 위치 → 블록 테마의 내비게이션 → 페이지 목록 */
class BoardMoa_Menu
{
    private static $title = '';

    public static function title()
    {
        return self::$title !== '' ? self::$title : BoardMoa_Text::t('메뉴');
    }

    public static function tree()
    {
        $menu = self::classicMenu();
        if ($menu) {
            self::$title = BoardMoa_Html::text($menu->name);
            return self::classicTree($menu);
        }
        if (function_exists('wp_is_block_theme') && wp_is_block_theme()) {
            $nav = self::blockNavigation();
            if ($nav !== null) {
                return $nav;
            }
        }
        // 메뉴가 없으면 워드프레스가 보이는 기본 메뉴처럼: 공개 페이지 목록
        $nodes = [];
        foreach (get_pages(['sort_column' => 'menu_order,post_title', 'parent' => 0]) as $page) {
            $nodes[] = self::pageNode($page);
        }
        return $nodes;
    }

    private static function pageNode($page)
    {
        $children = [];
        foreach (get_pages(['sort_column' => 'menu_order,post_title', 'parent' => $page->ID]) as $child) {
            $children[] = self::pageNode($child);
        }
        return ['title' => $page->post_title, 'url' => get_permalink($page), 'type' => 'post_type', 'object' => 'page', 'object_id' => $page->ID, 'target' => '', 'children' => $children];
    }

    /** 머리 메뉴 위치에 걸린 메뉴 (위치 이름이 흔한 것부터, 없으면 걸린 첫 메뉴) */
    private static function classicMenu()
    {
        $locations = get_nav_menu_locations();
        if (!$locations) {
            return null;
        }
        foreach (['primary', 'main', 'main-menu', 'primary-menu', 'header', 'header-menu', 'menu-1', 'top'] as $name) {
            if (!empty($locations[$name]) && ($menu = wp_get_nav_menu_object($locations[$name]))) {
                return $menu;
            }
        }
        foreach ($locations as $id) {
            if ($id && ($menu = wp_get_nav_menu_object($id))) {
                return $menu;
            }
        }
        return null;
    }

    private static function classicTree($menu)
    {
        $items = wp_get_nav_menu_items($menu->term_id, ['update_post_term_cache' => false]);
        if (!$items) {
            return [];
        }
        // 테마가 wp_nav_menu() 로 그릴 때와 같은 거르기 (역할별 메뉴 플러그인 등)
        $args = (object)['menu' => $menu, 'theme_location' => '', 'depth' => 0, 'walker' => '', 'container' => 'div', 'fallback_cb' => '', 'echo' => false];
        $items = apply_filters('wp_nav_menu_objects', $items, $args);
        $byParent = [];
        foreach ((array)$items as $item) {
            if (!empty($item->_invalid)) {
                continue;
            }
            $byParent[(int)$item->menu_item_parent][] = $item;
        }
        $build = function ($parent) use (&$build, $byParent) {
            $out = [];
            foreach (isset($byParent[$parent]) ? $byParent[$parent] : [] as $item) {
                $out[] = ['title' => $item->title, 'url' => $item->url, 'type' => $item->type, 'object' => $item->object,
                    'object_id' => (int)$item->object_id, 'target' => $item->target, 'children' => $build((int)$item->ID)];
            }
            return $out;
        };
        return $build(0);
    }

    /**
     * 블록 테마: 머리(header) 템플릿 부분에 든 내비게이션 블록이 웹에 그리는 메뉴.
     * 블록에 ref(내비게이션 글)가 있으면 그 글, 블록 안에 링크가 있으면 그 링크, 둘 다 없으면 워드프레스의 대체 메뉴
     * (WP_Navigation_Fallback: 가장 최근에 발행한 내비게이션 글)를 쓴다. 템플릿 부분 속 패턴·템플릿 부분도 펼쳐 찾는다.
     */
    private static function blockNavigation()
    {
        $block = self::headerNavigationBlock();
        if ($block) {
            $ref = isset($block['attrs']['ref']) ? (int)$block['attrs']['ref'] : 0;
            if ($ref) {
                $post = get_post($ref);
                if ($post && $post->post_type === 'wp_navigation' && $post->post_status === 'publish') {
                    self::$title = BoardMoa_Html::text($post->post_title);
                    return self::blockNodes(parse_blocks($post->post_content));
                }
            } elseif (!empty($block['innerBlocks'])) {
                return self::blockNodes($block['innerBlocks']);
            }
        }
        $navs = get_posts(['post_type' => 'wp_navigation', 'post_status' => 'publish', 'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'DESC']);
        if (!$navs) {
            return null;
        }
        self::$title = BoardMoa_Html::text($navs[0]->post_title);
        return self::blockNodes(parse_blocks($navs[0]->post_content));
    }

    /** 머리 템플릿 부분(이름 header, 없으면 area 가 header 인 첫 부분)의 첫 core/navigation 블록 */
    private static function headerNavigationBlock()
    {
        if (!function_exists('get_block_template')) {
            return null;
        }
        $part = get_block_template(get_stylesheet() . '//header', 'wp_template_part');
        if (!$part && function_exists('get_block_templates')) {
            $parts = get_block_templates(['area' => 'header'], 'wp_template_part');
            $part = $parts ? $parts[0] : null;
        }
        return $part ? self::findNavigation(parse_blocks((string)$part->content), 0) : null;
    }

    private static function findNavigation($blocks, $level)
    {
        if ($level > 5) {
            return null;
        }
        foreach ((array)$blocks as $block) {
            $name = isset($block['blockName']) ? $block['blockName'] : '';
            $attrs = isset($block['attrs']) ? $block['attrs'] : [];
            if ($name === 'core/navigation') {
                return $block;
            }
            $inner = isset($block['innerBlocks']) ? $block['innerBlocks'] : [];
            if ($name === 'core/pattern' && !empty($attrs['slug']) && class_exists('WP_Block_Patterns_Registry')) {
                $pattern = WP_Block_Patterns_Registry::get_instance()->get_registered($attrs['slug']);
                $inner = $pattern && !empty($pattern['content']) ? parse_blocks($pattern['content']) : [];
            } elseif ($name === 'core/template-part' && !empty($attrs['slug'])) {
                $theme = !empty($attrs['theme']) ? $attrs['theme'] : get_stylesheet();
                $part = get_block_template($theme . '//' . $attrs['slug'], 'wp_template_part');
                $inner = $part ? parse_blocks((string)$part->content) : [];
            }
            $found = self::findNavigation($inner, $level + 1);
            if ($found) {
                return $found;
            }
        }
        return null;
    }

    private static function blockNodes($blocks)
    {
        $out = [];
        foreach ($blocks as $block) {
            $name = isset($block['blockName']) ? $block['blockName'] : '';
            $a = isset($block['attrs']) ? $block['attrs'] : [];
            if ($name === 'core/navigation-link' || $name === 'core/navigation-submenu') {
                $kind = isset($a['kind']) ? $a['kind'] : 'custom';
                $type = isset($a['type']) ? $a['type'] : '';
                $out[] = [
                    'title' => isset($a['label']) ? $a['label'] : '',
                    'url' => isset($a['url']) ? $a['url'] : '',
                    'type' => $kind === 'post-type' ? 'post_type' : ($kind === 'taxonomy' ? 'taxonomy' : 'custom'),
                    'object' => $kind === 'taxonomy' && $type === 'tag' ? 'post_tag' : $type,
                    'object_id' => isset($a['id']) ? (int)$a['id'] : 0,
                    'target' => !empty($a['opensInNewTab']) ? '_blank' : '',
                    'children' => self::blockNodes(isset($block['innerBlocks']) ? $block['innerBlocks'] : []),
                ];
            } elseif ($name === 'core/page-list') {
                foreach (get_pages(['sort_column' => 'menu_order,post_title', 'parent' => 0]) as $page) {
                    $out[] = self::pageNode($page);
                }
            } elseif ($name === 'core/home-link') {
                $out[] = ['title' => isset($a['label']) ? $a['label'] : BoardMoa_Text::t('홈'), 'url' => home_url('/'), 'type' => 'custom', 'object' => 'custom', 'object_id' => 0, 'target' => '', 'children' => []];
            } elseif (!empty($block['innerBlocks'])) {
                $out = array_merge($out, self::blockNodes($block['innerBlocks']));
            }
        }
        return $out;
    }
}
