<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 요청 입구: ?r=<route> 를 처리하고 {"ok", "data"|"error"} 로 답한다 (docs/API.md).
 * 앱은 쿠키를 쓰지 않는다: Bearer 토큰으로 이번 요청의 회원을 정하고(determine_current_user), 토큰이 없으면 비회원이다.
 */
class BoardMoa_Api
{
    const VERSION = BOARDMOA_VERSION;

    /** route => [메서드, 로그인 필요(true)/선택(false)/토큰 안 봄(null), 처리] */
    private static function routes()
    {
        return [
            'site' => ['GET', false, ['BoardMoa_Boards', 'site']],
            'menu' => ['GET', false, ['BoardMoa_Boards', 'menu']],
            'auth.login' => ['POST', null, [__CLASS__, 'login']],
            'auth.refresh' => ['POST', null, [__CLASS__, 'refresh']],
            'auth.logout' => ['POST', null, [__CLASS__, 'logout']],
            'me' => ['GET', true, [__CLASS__, 'me']],
            'feed' => ['GET', false, ['BoardMoa_Boards', 'feed']],
            'board' => ['GET', false, ['BoardMoa_Boards', 'board']],
            // POST 도 받는다: 비밀번호 글·비회원 비밀글을 비밀번호(password)로 열 때 주소에 남기지 않으려고
            'document' => ['GET|POST', false, ['BoardMoa_Boards', 'document']],
            'comments' => ['GET', false, ['BoardMoa_Boards', 'comments']],
            'page' => ['GET', false, ['BoardMoa_Boards', 'page']],
            'resolve' => ['GET', false, ['BoardMoa_Boards', 'resolve']],
            'file' => ['GET', false, ['BoardMoa_Boards', 'file']],
            // 비회원도 웹이 허락하면 쓴다 (게시판마다 다르다: 어댑터가 판단)
            'document.write' => ['POST', false, ['BoardMoa_Boards', 'write']],
            'document.source' => ['GET|POST', false, ['BoardMoa_Boards', 'source']],
            'document.update' => ['POST', false, ['BoardMoa_Boards', 'update']],
            'document.delete' => ['POST', false, ['BoardMoa_Boards', 'delete']],
            'comment.write' => ['POST', false, ['BoardMoa_Boards', 'commentWrite']],
            'comment.update' => ['POST', false, ['BoardMoa_Boards', 'commentUpdate']],
            'comment.delete' => ['POST', false, ['BoardMoa_Boards', 'commentDelete']],
            'document.vote' => ['POST', false, ['BoardMoa_Boards', 'vote']],
            'my.menu' => ['GET', true, ['BoardMoa_My', 'menu']],
            'my.documents' => ['GET', true, ['BoardMoa_My', 'documents']],
            'my.comments' => ['GET', true, ['BoardMoa_My', 'comments']],
            'member.menu' => ['GET', false, ['BoardMoa_My', 'memberMenu']],
            'signup.form' => ['GET', false, ['BoardMoa_My', 'signupForm']],
            'me.form' => ['GET', true, ['BoardMoa_My', 'form']],
            'me.update' => ['POST', true, ['BoardMoa_My', 'update']],
            'me.password' => ['POST', true, ['BoardMoa_My', 'password']],
            // 알림 플러그인이 없으면 앱이 종 아이콘을 숨긴다
            'notify.count' => ['GET', true, [__CLASS__, 'noNotify']],
        ];
    }

    /** @var array 이번 요청의 값 (쿼리 + 본문, JSON 본문도) */
    private static $input = null;
    /** @var object|null 이번 요청의 토큰 행 */
    public static $token = null;
    private static $resolved = false;
    private static $userId = 0;
    private static $authError = null;
    private static $handled = false;

    // ---- 시작

    /** 앱 요청인지: api.php 로 들어왔거나, 워드프레스로 넘어온 예전 주소(modules/appapi/api.php, appapi/index.php) */
    public static function isApiRequest()
    {
        if (defined('BOARDMOA_API_ENTRY')) {
            return true;
        }
        $path = rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH));
        if ($path === '') {
            return false;
        }
        $bases = [];
        foreach ([home_url('/'), site_url('/')] as $url) {
            $bases[] = rtrim((string)parse_url($url, PHP_URL_PATH), '/') . '/';
        }
        // 시험·특수 설정용: mu-plugin 에서 add_filter('boardmoa_legacy_paths', '__return_false') 이면 예전 주소를 받지 않는다
        if (!apply_filters('boardmoa_legacy_paths', true)) {
            return false;
        }
        foreach (array_unique($bases) as $base) {
            foreach (['modules/appapi/api.php', 'appapi/index.php'] as $p) {
                if ($path === $base . $p) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function bootstrap()
    {
        if (!self::isApiRequest()) {
            return;
        }
        define('BOARDMOA_DOING_API', true);
        // 세션을 여는 플러그인(KBoard 등)이 JSON 요청에서는 열지 않는다(wp_is_json_request). 열더라도 쿠키는 보내지 않는다
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        @ini_set('session.use_cookies', '0');
        @ini_set('session.use_only_cookies', '1');
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true); // 페이지 캐시 플러그인이 응답을 저장하지 않게
        }
        add_filter('determine_current_user', [__CLASS__, 'determineUser'], PHP_INT_MAX);
        // 모든 플러그인의 init 가 끝난 뒤(게시판 플러그인의 글 종류·처리기가 준비된 뒤), 화면을 그리기 전에 처리하고 끝낸다
        add_action('wp_loaded', [__CLASS__, 'handle'], PHP_INT_MAX);
        // 웹 처리 함수가 die() 로 끝냈을 때: 워드프레스 종료 훅(shutdown)이 출력 버퍼를 내보내기 전에 JSON 오류로 바꾼다
        add_action('shutdown', ['BoardMoa_Run', 'onShutdown'], -PHP_INT_MAX);
        register_shutdown_function(['BoardMoa_Run', 'onShutdown']);
    }

    // ---- 응답

    public static function sendJson($body, $status)
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            if (function_exists('header_remove')) {
                header_remove('Set-Cookie');
                header_remove('Location');
                header_remove('Refresh');
            }
            status_header((int)$status);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store');
            header('X-Content-Type-Options: nosniff');
        }
        echo wp_json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function handle()
    {
        if (self::$handled) {
            return;
        }
        self::$handled = true;
        $status = 200;
        try {
            BoardMoa_Store::ensureTables();
            $route = (string)wp_unslash($_GET['r'] ?? '');
            $routes = self::routes();
            if (!isset($routes[$route])) {
                throw new BoardMoa_Error(404, 'unknown_route', 'unknown route', true);
            }
            list($method, $login, $handler) = $routes[$route];
            $methods = explode('|', $method);
            $requestMethod = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
            if (!in_array($requestMethod, $methods, true) && !(in_array('GET', $methods, true) && $requestMethod === 'HEAD')) {
                throw new BoardMoa_Error(405, 'method_not_allowed', 'method not allowed', true);
            }
            if ($login !== null) {
                self::authenticate($login);
            }
            $data = call_user_func($handler);
            if ($data === null) {
                exit; // 처리기가 직접 응답했다 (파일 내려받기)
            }
            $body = ['ok' => true, 'data' => $data];
        } catch (BoardMoa_Error $e) {
            $status = $e->status;
            $body = ['ok' => false, 'error' => array_merge(['code' => $e->codeName, 'message' => $e->raw ? $e->getMessage() : BoardMoa_Text::t($e->getMessage())], $e->extra)];
        } catch (Throwable $e) {
            error_log('[boardmoa] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
            $status = 500;
            $body = ['ok' => false, 'error' => ['code' => 'server_error', 'message' => BoardMoa_Text::t('서버에서 처리하지 못했습니다.')]];
        }
        self::sendJson($body, $status);
        exit;
    }

    public static function message($code)
    {
        $messages = [
            'not_found' => '없는 페이지입니다.',
            'not_permitted' => '권한이 없습니다.',
            'login_required' => '로그인이 필요합니다.',
        ];
        return BoardMoa_Text::t(isset($messages[$code]) ? $messages[$code] : '처리하지 못했습니다.');
    }

    /** 권한 없음: 비회원이면 401(앱이 로그인을 권한다), 회원이면 403 */
    public static function denied($message = null)
    {
        return new BoardMoa_Error(is_user_logged_in() ? 403 : 401, 'not_permitted', $message !== null ? $message : '권한이 없습니다.');
    }

    // ---- 입력

    private static function input()
    {
        if (self::$input === null) {
            $input = wp_unslash($_GET);
            $type = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
            if (strpos($type, 'application/json') !== false) {
                $json = json_decode((string)file_get_contents('php://input'), true);
                if (is_array($json)) {
                    $input = array_merge($input, $json);
                }
            } else {
                $input = array_merge($input, wp_unslash($_POST));
            }
            self::$input = $input;
        }
        return self::$input;
    }

    public static function param($name, $default = null)
    {
        $input = self::input();
        if (!array_key_exists($name, $input) || $input[$name] === null) {
            return $default;
        }
        $value = $input[$name];
        if (is_bool($value)) {
            return $value ? '1' : '';
        }
        return is_scalar($value) ? (string)$value : $value;
    }

    public static function intParam($name, $default = 0)
    {
        $value = self::param($name);
        return is_numeric($value) ? (int)$value : $default;
    }

    public static function boolParam($name)
    {
        $value = self::param($name, '');
        return in_array(strtolower((string)$value), ['1', 'true', 'y', 'yes', 'on'], true);
    }

    public static function ip()
    {
        return (string)($_SERVER['REMOTE_ADDR'] ?? '');
    }

    // ---- 인증

    private static function bearer()
    {
        // Apache 는 설정에 따라 Authorization 을 PHP 에 넘기지 않는다: 리디렉트 변수·원본 머리말도 본다
        $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
        if ($header === '') {
            $header = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        }
        if ($header === '' && function_exists('apache_request_headers')) {
            foreach ((array)apache_request_headers() as $name => $value) {
                if (strtolower($name) === 'authorization') {
                    $header = (string)$value;
                }
            }
        }
        return stripos($header, 'Bearer ') === 0 ? trim(substr($header, 7)) : '';
    }

    /**
     * 이번 요청의 회원 (determine_current_user, 가장 마지막에): 토큰의 회원. 토큰이 없으면 비회원 — 쿠키 로그인은 보지 않는다.
     * 매번 회원 상태를 다시 본다: 지운 회원·비밀번호를 바꾼 회원이면 토큰을 지운다.
     */
    public static function determineUser($userId)
    {
        if (self::$resolved) {
            return self::$userId ?: false;
        }
        self::$resolved = true;
        self::$userId = 0;
        $access = self::bearer();
        if ($access === '') {
            return false;
        }
        $row = BoardMoa_Store::findByAccess($access);
        if (!$row) {
            self::$authError = ['token_expired', 'access token expired'];
            return false;
        }
        $user = get_userdata((int)$row->user_id);
        if (!$user || (is_multisite() && is_user_spammy($user))) {
            BoardMoa_Store::revokeUser((int)$row->user_id);
            self::$authError = ['session_revoked', '로그인할 수 없는 계정입니다.'];
            return false;
        }
        if (!hash_equals((string)$row->password_sig, BoardMoa_Store::passwordSig($user->user_pass))) {
            BoardMoa_Store::revoke((int)$row->token_id);
            self::$authError = ['session_revoked', 'password changed'];
            return false;
        }
        self::$token = $row;
        self::$userId = (int)$user->ID;
        return self::$userId;
    }

    private static function authenticate($required)
    {
        $user = wp_get_current_user(); // determineUser 를 부른다
        if (self::$authError) {
            throw new BoardMoa_Error(401, self::$authError[0], self::$authError[1]);
        }
        if (!$user || !$user->ID) {
            if ($required) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            return;
        }
        if (self::$token) {
            BoardMoa_Store::touch(self::$token);
        }
    }

    public static function login()
    {
        $id = trim((string)self::param('user_id', ''));
        $password = (string)self::param('password', '');
        if ($id === '' || $password === '') {
            throw new BoardMoa_Error(400, 'missing_credentials', '아이디와 비밀번호를 입력하세요.');
        }
        // 웹 로그인(wp_signon)과 같은 확인: authenticate 필터(아이디·이메일·비밀번호, 보안 플러그인의 실패 횟수 제한·2단계 인증 등)와 wp_login_failed
        $run = BoardMoa_Run::call(function () use ($id, $password) {
            return wp_authenticate($id, $password);
        });
        $user = $run['value'];
        if ($run['redirect'] !== null || $run['died'] !== null) {
            throw new BoardMoa_Error(403, 'not_permitted', $run['died'] ?: BoardMoa_Text::t('웹사이트에서 로그인해 주세요.'), (bool)$run['died']);
        }
        if (is_wp_error($user)) {
            $code = $user->get_error_code();
            if (in_array($code, ['incorrect_password', 'invalid_username', 'invalid_email', 'empty_username', 'empty_password', 'authentication_failed'], true)) {
                throw new BoardMoa_Error(401, 'login_failed', '아이디 또는 비밀번호가 맞지 않습니다.');
            }
            // 보안 플러그인(로그인 제한·차단·2단계 인증)이 막은 까닭은 그대로 보여 준다
            $message = trim(html_entity_decode(wp_strip_all_tags($user->get_error_message()), ENT_QUOTES, 'UTF-8'));
            throw new BoardMoa_Error(403, 'not_permitted', $message !== '' ? $message : BoardMoa_Text::t('로그인할 수 없습니다.'), $message !== '');
        }
        if (!$user instanceof WP_User) {
            throw new BoardMoa_Error(401, 'login_failed', '아이디 또는 비밀번호가 맞지 않습니다.');
        }
        wp_set_current_user($user->ID);
        // 웹 로그인 끝의 wp_login 훅 (로그인 기록·2단계 인증 플러그인). 이동하려 하면 무시하고, 화면을 찍고 끝내면 그 안내를 보인다
        $run = BoardMoa_Run::call(function () use ($user) {
            do_action('wp_login', $user->user_login, $user);
        });
        if ($run['died'] !== null) {
            throw new BoardMoa_Error(403, 'not_permitted', $run['died'], true);
        }
        $user = get_userdata($user->ID);
        $tokens = BoardMoa_Store::issue($user->ID, $user->user_pass, self::param('device_name', ''), self::param('platform', ''), self::ip());
        return ['tokens' => $tokens, 'member' => self::profile($user)];
    }

    public static function refresh()
    {
        $result = BoardMoa_Store::rotate((string)self::param('refresh_token', ''), self::ip());
        if (!$result) {
            throw new BoardMoa_Error(401, 'refresh_invalid', 'login required', true);
        }
        $row = $result[0];
        $user = get_userdata((int)$row->user_id);
        if (!$user || !hash_equals((string)$row->password_sig, BoardMoa_Store::passwordSig($user->user_pass))) {
            BoardMoa_Store::revoke((int)$row->token_id);
            throw new BoardMoa_Error(401, 'session_revoked', '로그인할 수 없는 계정입니다.');
        }
        return ['tokens' => $result[1]];
    }

    public static function logout()
    {
        $row = BoardMoa_Store::findByAccess(self::bearer());
        if (!$row && self::param('refresh_token')) {
            $result = BoardMoa_Store::rotate((string)self::param('refresh_token'), self::ip());
            $row = $result ? $result[0] : null;
        }
        if ($row) {
            BoardMoa_Store::revoke((int)$row->token_id);
        }
        return ['logged_out' => true];
    }

    public static function me()
    {
        return self::profile(wp_get_current_user());
    }

    /** 앱의 member 객체 (비회원이면 null) */
    public static function profile($user = null)
    {
        $user = $user ?: wp_get_current_user();
        if (!$user || !$user->ID) {
            return null;
        }
        $groups = [];
        $names = wp_roles()->get_names();
        foreach ((array)$user->roles as $role) {
            $groups[] = isset($names[$role]) ? translate_user_role($names[$role]) : (string)$role;
        }
        return [
            'member_srl' => (int)$user->ID,
            'user_id' => (string)$user->user_login,
            'nick_name' => (string)$user->display_name,
            'email_address' => $user->user_email ? (string)$user->user_email : null,
            'profile_image' => self::avatar($user->ID),
            'groups' => $groups,
            'is_admin' => user_can($user, 'manage_options'),
        ];
    }

    /**
     * 프로필 사진: 사이트가 아바타를 보이고(설정 → 토론), 회원 사진 플러그인이 정한 사진일 때만.
     * 그라바타 기본값(회색 사람)은 앱의 기본 모양이 더 낫고 사진마다 외부 요청이 생겨 보내지 않는다.
     */
    public static function avatar($userId)
    {
        static $cache = [];
        $userId = (int)$userId;
        if ($userId <= 0 || !get_option('show_avatars')) {
            return null;
        }
        if (!array_key_exists($userId, $cache)) {
            $url = (string)get_avatar_url($userId, ['size' => 96]);
            $host = strtolower((string)parse_url($url, PHP_URL_HOST));
            $cache[$userId] = ($url !== '' && strpos($host, 'gravatar.com') === false) ? BoardMoa_Html::absolute($url) : null;
        }
        return $cache[$userId];
    }

    public static function noNotify()
    {
        return ['enabled' => false, 'unread' => 0];
    }
}
