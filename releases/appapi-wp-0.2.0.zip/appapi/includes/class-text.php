<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 플러그인 문구 언어 (한국어·영어). 한국어 원문을 열쇠로 BoardMoa_Text::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 영어 문구는 lang/text.en.php. 앱에 보내는 문구는 X-App-Lang(ko|en), 없으면(예전 앱) 사이트 언어. 관리 화면은 관리자 언어.
 * 워드프레스·게시판 플러그인이 만든 문구와 사이트 내용은 바꾸지 않는다.
 */
class BoardMoa_Text
{
    private static $code = null;
    private static $english = null;

    public static function code()
    {
        if (self::$code === null) {
            $requested = strtolower(substr((string)($_SERVER['HTTP_X_APP_LANG'] ?? ''), 0, 2));
            if (defined('BOARDMOA_DOING_API') && ($requested === 'ko' || $requested === 'en')) {
                self::$code = $requested;
            } else {
                $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
                self::$code = strpos((string)$locale, 'ko') === 0 ? 'ko' : 'en';
            }
        }
        return self::$code;
    }

    public static function t($ko, ...$args)
    {
        $text = (string)$ko;
        if (self::code() === 'en') {
            if (self::$english === null) {
                $file = BOARDMOA_DIR . '/lang/text.en.php';
                self::$english = is_file($file) ? (array)include $file : [];
            }
            if (isset(self::$english[$text])) {
                $text = self::$english[$text];
            }
        }
        foreach ($args as $i => $value) {
            $text = str_replace('{' . $i . '}', (string)$value, $text);
        }
        return $text;
    }
}
