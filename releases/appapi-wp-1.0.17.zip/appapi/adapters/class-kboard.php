<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * KBoard (코스모스팜). 게시판은 숏코드 [kboard id=N] 이나 '자동 페이지'(auto_page)로 페이지에 들어 있고, 그 페이지가 게시판 주소다.
 * 권한은 KBoard 의 판단 함수를 그대로 부른다: KBoard::isReader·isWriter·isEditor·isAdmin·isPrivate, KBContent::isReader·isConfirm,
 * 댓글은 KBCommentsBuilder::isWriter·KBComment::isReader·isEditor. 본문 화면의 순서(KBoardBuilder::builderDocument)를 그대로 따른다.
 * 글·댓글 등록은 웹 양식을 받는 처리 함수(KBController::editorExecute, KBCommentController::insert)를 그대로 실행한다
 * (금지어·글 수 제한·작성 간격·포인트·알림 메일·훅이 웹과 같다).
 */
class BoardMoa_KBoard extends BoardMoa_Adapter
{
    private $boards = null;
    private $pages = null;
    private $objects = [];

    public function key()
    {
        return 'kboard';
    }

    public function available()
    {
        return class_exists('KBoard') && class_exists('KBContentList');
    }

    public function features()
    {
        $features = ['guest_write', 'guest_manage', 'guest_comment', 'reply_write'];
        if (self::captchaWidget()) {
            $features[] = 'captcha_solve';
        }
        return $features;
    }

    /**
     * KBoard 의 비회원 자동 입력 방지(KBoard::useCAPTCHA): 글쓰기 양식에 captcha 칸이 있을 때 글, 댓글은 늘(댓글 처리 함수가 확인한다).
     * 구글 reCAPTCHA v2 를 쓰면 앱이 풀 수 있게 위젯 정보를 준다. KBoard 그림 글자 CAPTCHA 는 앱에서 풀 수 없어 위젯이 없다(앱은 웹으로 안내한다).
     */
    private function captchaNeeded($kb, $comment)
    {
        if (!$kb->useCAPTCHA()) {
            return false;
        }
        if ($comment) {
            return true;
        }
        $fields = $kb->fields();
        $skin = $fields ? $fields->getSkinFields() : [];
        return isset($skin['captcha']);
    }

    /**
     * 앱이 풀 수 있는 KBoard CAPTCHA: 구글 reCAPTCHA v2 는 위젯, KBoard 그림 글자(KBCaptcha, 대문자 5자)는 그림(type image, 새 앱만).
     * v3 는 앱이 풀 수 없어 null (앱은 웹으로 안내한다)
     */
    private static function captchaWidget($board = null)
    {
        if (function_exists('kboard_use_recaptcha') && kboard_use_recaptcha()) {
            if (kboard_recaptcha_type() !== 'v2') {
                return null;
            }
            return ['type' => 'recaptcha', 'site_key' => (string)get_option('kboard_recaptcha_site_key'), 'theme' => 'auto', 'size' => 'normal'];
        }
        if (!defined('KBOARD_DIR_PATH') || !is_file(KBOARD_DIR_PATH . '/class/KBCaptcha.class.php') || !function_exists('imagecreate')) {
            return null;
        }
        return BoardMoa_Captcha::imageWidget($board ? $board['mid'] : '', 'document', 5, 'text');
    }

    /** KBoard 그림 글자: 웹의 KBCaptcha::createImage 로 그림을 만들고 답은 번호로 둔다 (그림 파일은 읽고 지운다) */
    public function captchaImage($board, $for)
    {
        $widget = self::captchaWidget($board);
        if (!$widget || $widget['type'] !== 'image') {
            return parent::captchaImage($board, $for);
        }
        if (!class_exists('KBCaptcha')) {
            include_once KBOARD_DIR_PATH . '/class/KBCaptcha.class.php';
        }
        BoardMoa_Captcha::session();
        $_SESSION['kboard_captcha'] = [];
        $src = (new KBCaptcha())->createImage();
        $text = (string)end($_SESSION['kboard_captcha']);
        unset($_SESSION['kboard_captcha']);
        $file = WP_CONTENT_DIR . '/uploads/kboard_captcha/' . basename((string)wp_parse_url($src, PHP_URL_PATH));
        $bytes = is_file($file) ? (string)@file_get_contents($file) : '';
        @unlink($file);
        if ($text === '' || $text === 'ERROR' || $bytes === '') {
            throw new BoardMoa_Error(500, 'server_error', '자동 입력 방지 그림을 만들지 못했습니다.');
        }
        return BoardMoa_Captcha::imageResult($text, $bytes, 5, 'text');
    }

    /** 처리 함수가 알림으로 끝냈을 때: 그림 글자 답이 틀렸으면 다시 풀게 captcha_required, 그 밖은 not_permitted */
    private function diedError($text, $board, $usedImage)
    {
        if ($usedImage && (stripos($text, 'CAPTCHA') !== false || $text === __('CAPTCHA is invalid.', 'kboard') || $text === __('CAPTCHA is invalid.', 'kboard-comments'))) {
            return new BoardMoa_Error(403, 'captcha_required', $text, true, ['captcha' => self::captchaWidget($board)]);
        }
        return new BoardMoa_Error(403, 'not_permitted', $text, true);
    }

    /** 자동 입력 방지를 요구하면 앱이 푼 답을 웹 양식처럼 넘긴다 (reCAPTCHA 는 g-recaptcha-response, 그림 글자는 세션의 답 + captcha). 없거나 앱이 풀 수 없으면 403 captcha_required */
    private function captchaInput($kb, $comment, array &$post, $board = null)
    {
        if (!$this->captchaNeeded($kb, $comment)) {
            return;
        }
        $answer = (string)BoardMoa_Api::param('captcha_response', '');
        $widget = self::captchaWidget($board);
        if ($answer !== '' && $widget && $widget['type'] === 'image') {
            $kept = BoardMoa_Captcha::take($answer);
            if ($kept) {
                BoardMoa_Captcha::session();
                $_SESSION['kboard_captcha'] = [$kept[0]];
                $post['captcha'] = $kept[1];
                BoardMoa_Run::$captchaRetry = ['widget' => $widget, 'texts' => [__('CAPTCHA is invalid.', 'kboard'), __('CAPTCHA is invalid.', 'kboard-comments')]];
                return;
            }
        } elseif ($answer !== '' && $widget) {
            $post['g-recaptcha-response'] = $answer;
            return;
        }
        throw new BoardMoa_Error(403, 'captcha_required', $widget ? '자동 입력 방지 확인이 필요합니다.' : '이 게시판은 웹에서 자동 입력 방지 확인을 해야 글을 쓸 수 있습니다.', false, ['captcha' => $widget]);
    }

    /** 게시판 번호 => 페이지 번호 (숏코드·자동 페이지) */
    private function pages()
    {
        global $wpdb;
        if ($this->pages === null) {
            $this->pages = [];
            $rows = $wpdb->get_results("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_type IN ('page','post') AND post_status IN ('publish','private') AND post_content LIKE '%[kboard%' ORDER BY post_status = 'publish' DESC, ID ASC");
            foreach ($rows as $row) {
                if (preg_match_all('/\[kboard\s[^\]]*\bid\s*=\s*["\']?(\d+)/i', $row->post_content, $m)) {
                    foreach ($m[1] as $id) {
                        if (!isset($this->pages[(int)$id])) {
                            $this->pages[(int)$id] = (int)$row->ID;
                        }
                    }
                }
            }
            $auto = $wpdb->get_results("SELECT board_id, value FROM {$wpdb->prefix}kboard_board_meta WHERE `key` = 'auto_page'");
            foreach ((array)$auto as $row) {
                if ((int)$row->value && !isset($this->pages[(int)$row->board_id])) {
                    $this->pages[(int)$row->board_id] = (int)$row->value;
                }
            }
        }
        return $this->pages;
    }

    public function boards()
    {
        global $wpdb;
        if ($this->boards === null) {
            $this->boards = [];
            $pages = $this->pages();
            foreach ((array)$wpdb->get_results("SELECT uid, board_name FROM {$wpdb->prefix}kboard_board_setting ORDER BY uid") as $row) {
                $id = (int)$row->uid;
                if (!isset($pages[$id])) {
                    continue; // 페이지에 넣지 않은 게시판은 웹에서 열 곳이 없다
                }
                $this->boards['kb-' . $id] = [
                    'mid' => 'kb-' . $id, 'adapter' => 'kboard', 'module' => 'board', 'ref' => $id, 'page' => $pages[$id],
                    'title' => BoardMoa_Html::text($row->board_name), 'url' => get_permalink($pages[$id]),
                ];
            }
        }
        return $this->boards;
    }

    /** @return KBoard */
    private function kb($board)
    {
        $id = (int)$board['ref'];
        if (!isset($this->objects[$id])) {
            $this->objects[$id] = new KBoard($id);
        }
        return $this->objects[$id];
    }

    public function fromMenuNode($node)
    {
        if ((isset($node['type']) && $node['type'] === 'post_type') && !empty($node['object_id'])) {
            $boardId = array_search((int)$node['object_id'], $this->pages(), true);
            // 같은 게시판을 넣은 다른 페이지(다국어 사이트의 번역 페이지 등)도 그 게시판이다 — 게시판 주소는 첫 페이지 그대로
            if ($boardId === false && preg_match('/\[kboard\s[^\]]*\bid\s*=\s*["\']?(\d+)/i', (string)get_post_field('post_content', (int)$node['object_id']), $m)) {
                $boardId = (int)$m[1];
            }
            if ($boardId !== false && isset($this->boards()['kb-' . $boardId])) {
                return ['mid' => 'kb-' . $boardId, 'expand' => null];
            }
        }
        return null;
    }

    public function menuBoards()
    {
        $out = [];
        foreach ($this->boards() as $board) {
            $out[] = ['mid' => $board['mid'], 'title' => $board['title']];
        }
        return $out;
    }

    public function canList($board)
    {
        $page = get_post((int)$board['page']);
        if (!$page || !BoardMoa_Core::readable($page)) {
            return false;
        }
        $kb = $this->kb($board);
        // 웹(KBoardBuilder::create): '내 글만 보기' + '로그인한 사람만 접근'이면 비회원은 로그인 화면으로 보낸다
        if ($kb->meta->permission_list && $kb->meta->permission_access && !is_user_logged_in()) {
            return false;
        }
        return true;
    }

    public function inFeed($board)
    {
        return !$this->kb($board)->isPrivate();
    }

    private function commentBuilder($kb)
    {
        $builder = new KBCommentsBuilder();
        $builder->board = $kb;
        $builder->board_id = $kb->id;
        $builder->permission_comment_write = $kb->meta->permission_comment_write;
        return $builder;
    }

    /** KBoard 댓글 플러그인(kboard-comments)을 쓰고, 이 게시판에서 댓글을 켰는가 (다른 댓글 플러그인 연동은 앱에서 쓰지 않는다) */
    private function kbComments($kb)
    {
        return defined('KBOARD_COMMNETS_VERSION') && $kb->use_comment && class_exists('KBCommentsBuilder') && !($kb->meta->comments_plugin_id && $kb->meta->use_comments_plugin);
    }

    public function grant($board)
    {
        $kb = $this->kb($board);
        return [
            'list' => $this->canList($board),
            // 남의 글(비밀글 아님)을 읽을 수 있는가: 글쓴이 번호 -1 은 누구의 글도 아닌 자리
            'view' => (bool)$kb->isReader(-1, ''),
            'write_document' => (bool)$kb->isWriter(),
            'write_comment' => $this->kbComments($kb) && $this->commentBuilder($kb)->isWriter(),
            'manager' => (bool)$kb->isAdmin(),
        ];
    }

    /** 분류: category1_list (쉼표 구분). 번호는 1부터 차례. 계층형 분류를 쓰면 웹 글쓰기 화면처럼 category1 은 쓰지 않는다 */
    private function categoryNames($kb)
    {
        if ($kb->use_category !== 'yes' || $kb->isTreeCategoryActive()) {
            return [];
        }
        return array_values(array_filter(array_map('trim', explode(',', (string)$kb->category1_list)), 'strlen'));
    }

    /**
     * 계층형 분류(KBoardTreeCategory): [['id', 'category_name', 'parent_id']] 를 설정 순서대로. 번호는 1부터 차례, parent 는 부모의 번호.
     * 글에는 뿌리부터의 이름 경로가 옵션 tree_category_1, tree_category_2 … 로 저장된다 (웹 글쓰기 양식 kboard_option_tree_category_N)
     */
    private function treeCategories($kb)
    {
        if ($kb->use_category !== 'yes' || !$kb->isTreeCategoryActive() || empty($kb->tree_category->tree_category) || !is_array($kb->tree_category->tree_category)) {
            return [];
        }
        $items = array_values(array_filter($kb->tree_category->tree_category, function ($item) {
            return is_array($item) && isset($item['id'], $item['category_name']) && (string)$item['category_name'] !== '';
        }));
        $numbers = [];
        foreach ($items as $i => $item) {
            $numbers[(string)$item['id']] = $i + 1;
        }
        $out = [];
        foreach ($items as $i => $item) {
            $parent = isset($item['parent_id']) ? (string)$item['parent_id'] : '';
            $out[$i + 1] = ['srl' => $i + 1, 'parent' => ($parent !== '' && isset($numbers[$parent])) ? $numbers[$parent] : 0, 'name' => (string)$item['category_name']];
        }
        return $out;
    }

    /** 계층형 분류 번호 → 뿌리부터의 이름 경로 */
    private function treePath($kb, $srl)
    {
        $tree = $this->treeCategories($kb);
        $path = [];
        $seen = [];
        while ($srl && isset($tree[$srl]) && !isset($seen[$srl])) {
            $seen[$srl] = true;
            array_unshift($path, $tree[$srl]['name']);
            $srl = $tree[$srl]['parent'];
        }
        return $path;
    }

    /** 글의 계층형 분류(옵션 tree_category_N 이름 경로) → 번호 */
    private function treeOf($kb, $content)
    {
        $tree = $this->treeCategories($kb);
        if (!$tree) {
            return 0;
        }
        $found = 0;
        for ($depth = 1; $depth <= count($tree); $depth++) {
            $name = (string)$content->option->{'tree_category_' . $depth};
            if ($name === '') {
                break;
            }
            $next = 0;
            foreach ($tree as $item) {
                if ($item['parent'] === $found && $item['name'] === $name) {
                    $next = $item['srl'];
                    break;
                }
            }
            if (!$next) {
                break;
            }
            $found = $next;
        }
        return $found;
    }

    private function fieldsOption($kb)
    {
        $fields = $kb->fields();
        if (!$fields) {
            return [null, null];
        }
        $skin = $fields->getSkinFields();
        return [$fields, isset($skin['option']) ? $skin['option'] : null];
    }

    private function info($board, $grant)
    {
        $kb = $this->kb($board);
        $loggedIn = is_user_logged_in();
        $categories = [];
        foreach ($this->categoryNames($kb) as $i => $name) {
            $categories[] = ['category_srl' => $i + 1, 'parent_srl' => 0, 'title' => $name, 'document_count' => (int)$kb->getCategoryCount(['category1' => $name]), 'writable' => true];
        }
        foreach ($this->treeCategories($kb) as $item) {
            $categories[] = ['category_srl' => $item['srl'], 'parent_srl' => $item['parent'], 'title' => $item['name'], 'document_count' => 0, 'writable' => true];
        }
        list($fields, $option) = $this->fieldsOption($kb);
        $useSecret = $option && $fields->isUseFields(isset($option['secret_permission']) ? $option['secret_permission'] : '', isset($option['secret']) ? $option['secret'] : []);
        $captcha = ['document' => $grant['write_document'] && $this->captchaNeeded($kb, false), 'comment' => $grant['write_comment'] && $this->captchaNeeded($kb, true)];
        $url = new KBUrl();
        $url->setBoard($kb);
        return $this->boardInfo($board, $grant, [
            'style' => in_array($kb->skin, ['thumbnail', 'avatar'], true) ? ($kb->skin === 'thumbnail' ? 'gallery' : 'list') : 'list',
            'columns' => ['read_count' => true, 'vote_count' => true],
            'use_secret' => (bool)$useSecret || (bool)$kb->meta->secret_checked_forced,
            'categories' => $categories,
            'write_url' => add_query_arg('mod', 'editor', get_permalink((int)$board['page'])),
            'captcha' => $captcha,
            'captcha_widget' => ($captcha['document'] || $captcha['comment']) ? self::captchaWidget($board) : null,
            'guest_fields' => ($grant['write_document'] && !$loggedIn) ? ['nick_name', 'password'] : null,
            'guest_comment_fields' => ($grant['write_comment'] && !$loggedIn) ? ['nick_name', 'password'] : null,
            'upload' => $grant['write_document'] ? $this->uploadInfo($kb, null) : ['allowed' => false, 'max_file_size' => null, 'max_total_size' => null],
        ]);
    }

    // ---- 사진 (KBoard 의 '사진' 칸 = 미디어 추가: KBContentMedia, 본문에 그림으로 들어간다)

    /** 글쓰기 양식의 '사진'(media) 칸: 스킨 칸에 있고 그 칸의 권한(isUseFields)이 이 회원에게 열려 있을 때 웹에 보인다 */
    private function mediaField($kb)
    {
        $fields = $kb->fields();
        if (!$fields) {
            return false;
        }
        foreach ((array)$fields->getSkinFields() as $field) {
            if (isset($field['field_type']) && $field['field_type'] === 'media') {
                return (bool)$fields->isUseFields(isset($field['permission']) ? $field['permission'] : '', isset($field['roles']) && $field['roles'] ? $field['roles'] : []);
            }
        }
        return false;
    }

    /**
     * 사진을 붙일 수 있는가: 웹 글쓰기 화면의 '사진' 칸과 KBoard 미디어 올리기 권한(KBContentMedia::hasPermission — 새 글은 쓰기 권한,
     * 고치는 글은 고칠 권한·비회원 글 비밀번호)이 되고, 허용 확장자에 jpg 가 있을 때. 한 장 크기는 KBoard 설정(kboard_limit_file_size)
     */
    private function uploadInfo($kb, $content)
    {
        $none = ['allowed' => false, 'max_file_size' => null, 'max_total_size' => null];
        if (!class_exists('KBContentMedia') || !function_exists('kboard_allow_file_extensions') || !$this->mediaField($kb)) {
            return $none;
        }
        $extensions = array_map('strtolower', (array)apply_filters('kboard_upload_extension', kboard_allow_file_extensions(true)));
        if (!in_array('jpg', $extensions, true) && !in_array('jpeg', $extensions, true)) {
            return $none;
        }
        $media = new KBContentMedia();
        $media->board_id = (int)$kb->id;
        $media->media_group = 'boardmoa';
        $media->content_uid = $content ? (int)$content->uid : 0;
        if (!$media->hasPermission()) {
            return $none;
        }
        $limit = (int)kboard_limit_file_size();
        return ['allowed' => true, 'max_file_size' => $limit > 0 ? $limit : null, 'max_total_size' => null];
    }

    /**
     * 사진을 웹의 '미디어 추가'와 같은 처리(KBContentMedia::upload — KBFileHandler 의 확장자·크기 검사, 사진 최적화 설정)로 올리고
     * [미디어 묶음 이름, 본문 끝에 넣을 HTML]. 글을 저장할 때 media_group 으로 넘기면 KBoard 가 글과 잇는다(addMediaRelationships)
     */
    private function uploadPhotos($kb, array $photos, $content)
    {
        global $wpdb;
        if (!$photos) {
            return ['', ''];
        }
        if (!$this->uploadInfo($kb, $content)['allowed']) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        $group = 'boardmoa' . strtolower(wp_generate_password(16, false, false));
        // 웹 미디어 창처럼 여러 장을 한 번에 (kboard_media_file[])
        $files = ['name' => [], 'type' => [], 'tmp_name' => [], 'error' => [], 'size' => []];
        foreach ($photos as $i => $photo) {
            $files['name'][] = 'photo' . ($i + 1) . '.jpg';
            $files['type'][] = 'image/jpeg';
            $files['tmp_name'][] = $photo['tmp_name'];
            $files['error'][] = (int)$photo['error'];
            $files['size'][] = (int)$photo['size'];
        }
        $savedFiles = $_FILES;
        $_FILES = ['kboard_media_file' => $files];
        $media = new KBContentMedia();
        $media->board_id = (int)$kb->id;
        $media->media_group = $group;
        $media->content_uid = $content ? (int)$content->uid : 0;
        // KBFileHandler 는 거절할 때(확장자·크기) alert 화면을 찍고 끝낸다: 그 문구로 오류 (BoardMoa_Run)
        $run = BoardMoa_Run::call(function () use ($media) {
            $media->upload();
        }, 'upload_failed', 400);
        $_FILES = $savedFiles;
        if ($run['died'] !== null) {
            throw new BoardMoa_Error(400, 'upload_failed', $run['died'] !== '' ? $run['died'] : BoardMoa_Text::t('사진을 올리지 못했습니다.'), $run['died'] !== '');
        }
        $paths = $wpdb->get_col($wpdb->prepare("SELECT file_path FROM {$wpdb->prefix}kboard_meida WHERE media_group = %s ORDER BY uid ASC", $group));
        if (count($paths) !== count($photos)) {
            throw new BoardMoa_Error(400, 'upload_failed', '사진을 올리지 못했습니다.');
        }
        $style = self::photoStyle();
        $html = '';
        foreach ($paths as $path) {
            $html .= '<p><img src="' . esc_url(site_url(stripslashes((string)$path))) . '" alt="" style="' . esc_attr($style) . '"></p>';
        }
        return [$group, $html];
    }

    // ---- 목록

    private function listObject($board, $page, $perPage)
    {
        $kb = $this->kb($board);
        $list = new KBContentList($kb->id);
        $category = BoardMoa_Api::intParam('category');
        $names = $this->categoryNames($kb);
        if ($category && isset($names[$category - 1])) {
            $list->category1($names[$category - 1]);
        }
        // 계층형 분류: 웹의 분류 고르기(kboard_search_option[tree_category_N])와 같은 옵션 검색
        if ($category && ($path = $this->treePath($kb, $category))) {
            $option = [];
            foreach ($path as $i => $name) {
                $option['tree_category_' . ($i + 1)] = ['key' => 'tree_category_' . ($i + 1), 'value' => $name];
            }
            $list->setSearchOption($option);
        }
        // 웹(KBoardBuilder::getList): '내 글만 보기'면 내 글만, 비회원은 빈 목록
        if ($kb->isPrivate()) {
            if (is_user_logged_in()) {
                $list->memberUID(get_current_user_id());
            } else {
                $list->stop = true;
            }
        }
        $list->rpp($perPage);
        $list->page($page);
        return $list;
    }

    public function listPage($board)
    {
        $kb = $this->kb($board);
        $grant = $this->grant($board);
        list($page, $perPage) = self::pageArgs($kb->page_rpp ?: 10);
        kboard_builder_mod('list'); // 승인 대기 글의 제목을 웹 목록처럼 가린다
        $list = $this->listObject($board, $page, $perPage);
        list($keyword, $target) = self::search();
        $map = ['title' => 'title', 'content' => 'content', 'title_content' => '', 'nick_name' => 'member_display', 'user_id' => 'member_display'];
        $list->getList($keyword, isset($map[$target]) ? $map[$target] : '', false);
        $notices = [];
        if ($page === 1 && $keyword === '') {
            while ($content = $list->hasNextNotice()) {
                $notices[] = $this->summarize($content, $kb);
            }
        }
        $documents = [];
        while ($content = $list->hasNext()) {
            $documents[] = $this->summarize($content, $kb);
            // 웹 목록(KBoardBuilder::builderReply)처럼 답글을 원글 아래에 들여 쓴다. 검색 결과에는 답글도 따로 나오므로 붙이지 않는다
            if ($keyword === '') {
                $this->appendReplies($documents, $kb, (int)$content->uid, 1);
            }
        }
        $total = (int)$list->total;
        return [
            'board' => $this->info($board, $grant),
            'notices' => $notices,
            'documents' => $documents,
            'page' => $page,
            'total_pages' => max(1, (int)ceil($total / $perPage)),
            'total_count' => $total,
        ];
    }

    /** 답글 나무 (KBContentList::getReplyList: 휴지통 아닌 글, 쓴 시각 순) */
    private function appendReplies(array &$documents, $kb, $parentUid, $depth)
    {
        if ($depth > 20) {
            return;
        }
        $list = new KBContentList($kb->id);
        $list->getReplyList($parentUid);
        while ($reply = $list->hasNextReply()) {
            $summary = $this->summarize($reply, $kb);
            $summary['reply_depth'] = $depth;
            $documents[] = $summary;
            $this->appendReplies($documents, $kb, (int)$reply->uid, $depth + 1);
        }
    }

    public function recent($board, $limit)
    {
        $kb = $this->kb($board);
        kboard_builder_mod('list');
        $list = $this->listObject($board, 1, $limit);
        $list->getList('', '', false);
        $out = [];
        while ($content = $list->hasNext()) {
            $out[] = ['time' => BoardMoa_Html::timestamp($content->date), 'summary' => $this->summarize($content, $kb)];
        }
        return $out;
    }

    private static function num($uid)
    {
        return BoardMoa_Store::num('kb:' . (int)$uid);
    }

    private static function uid($srl)
    {
        $ref = BoardMoa_Store::ref($srl);
        return ($ref && preg_match('/^kb:(\d+)$/', $ref, $m)) ? (int)$m[1] : 0;
    }

    private function summarize($content, $kb)
    {
        $uid = get_current_user_id();
        // 승인 대기 글: 고칠 수 있는 사람(글쓴이·관리자) 말고는 웹처럼 KBoard 의 안내 문구만 (본문·사진 없음)
        $hidden = self::pendingHidden($content);
        $readable = !$hidden && (bool)$kb->isReader($content->member_uid, $content->secret);
        $names = $this->categoryNames($kb);
        $cat = $names ? array_search((string)$content->category1, $names, true) : false;
        $tree = $cat === false ? $this->treeOf($kb, $content) : 0;
        $attach = (array)$content->attach;
        $thumb = $readable ? ($content->getThumbnail() ?: BoardMoa_Html::firstImage(self::contentOf($content))) : '';
        return $this->summary([
            'document_srl' => self::num($content->uid),
            'title' => BoardMoa_Html::text(self::titleOf($content)),
            'author' => BoardMoa_Html::text($content->getUserName()),
            'author_image' => $content->member_uid ? BoardMoa_Api::avatar($content->member_uid) : null,
            'author_srl' => (int)$content->member_uid,
            'is_mine' => $uid && (int)$content->member_uid === $uid,
            'regdate' => BoardMoa_Html::iso($content->date),
            'last_update' => BoardMoa_Html::iso($content->update),
            'category_srl' => $cat === false ? $tree : $cat + 1,
            'comment_count' => (int)$content->comment,
            'read_count' => (int)$content->view,
            'vote_count' => (int)$content->like,
            'is_notice' => (string)$content->notice !== '',
            'is_secret' => (string)$content->secret !== '',
            'has_files' => !$hidden && count($attach) > 0,
            'thumbnail' => $thumb ? BoardMoa_Html::absolute($thumb) : null,
            'summary' => ($readable || $hidden) ? BoardMoa_Html::summary(self::contentOf($content)) : '',
        ]);
    }

    /** 승인 대기(pending_approval) 글인가 */
    private static function pending($content)
    {
        return isset($content->row->status) && (string)$content->row->status === 'pending_approval';
    }

    /** 승인 대기 글이라 이 사람에게는 제목·본문이 가려지는가 (KBContent::__get: 고칠 수 있는 사람만 원래 내용) */
    private static function pendingHidden($content)
    {
        return self::pending($content) && !$content->isEditor();
    }

    /**
     * 제목: KBoard 웹 목록·본문 화면(mod=list|document)의 KBContent::__get 과 같다 — 승인 대기 글은 '[Pending] …' 안내.
     * __get 은 주소의 mod 값(kboard_mod)을 보고 가려서, 앱 요청에서는 같은 판단을 여기서 한다 (필터 kboard_pending_approval_title 그대로).
     */
    private static function titleOf($content)
    {
        if (!self::pending($content)) {
            return (string)$content->title;
        }
        $raw = isset($content->row->title) ? (string)$content->row->title : '';
        if ($content->isEditor()) {
            return (string)apply_filters('kboard_pending_approval_title', sprintf(__('&#91;Pending&#93; %s', 'kboard'), $raw), $content);
        }
        return (string)apply_filters('kboard_pending_approval_title', __('&#91;Pending&#93; Waiting for administrator Approval.', 'kboard'), $content);
    }

    /** 본문 원문: 승인 대기 글은 KBoard 의 안내 문구 (고칠 수 있는 사람은 안내 + 본문) */
    private static function contentOf($content)
    {
        if (!self::pending($content)) {
            return (string)$content->getContent();
        }
        $raw = isset($content->row->content) ? (string)$content->row->content : '';
        if ($content->isEditor()) {
            return (string)apply_filters('kboard_pending_approval_content', sprintf(__('<p>&#91;Waiting for administrator Approval.&#93;</p>%s', 'kboard'), $raw), $content);
        }
        return (string)apply_filters('kboard_pending_approval_content', __('&#91;Waiting for administrator Approval.&#93;', 'kboard'), $content);
    }

    // ---- 글

    /** 이 게시판의 글 (휴지통·다른 게시판으로 옮긴 글은 없는 글) */
    private function content($board, $srl)
    {
        $uid = self::uid($srl);
        $content = new KBContent();
        $content->initWithUID($uid);
        if (!$uid || !$content->uid || $content->isTrash() || (int)$content->board_id !== (int)$board['ref']) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        return $content;
    }

    /**
     * 웹 본문 화면(KBoardBuilder::builderDocument)과 같은 판단: 'ok' | 'locked'(비밀글: 비밀번호를 넣으면 열림) 또는 예외.
     * 비밀번호(password)를 보냈으면 웹 비밀번호 확인 양식처럼 $_POST['password'] 로 KBoard 가 확인한다(이번 요청만).
     */
    private function readState($kb, $content)
    {
        $uid = get_current_user_id();
        if ($kb->isPrivate()) {
            if (!is_user_logged_in()) {
                throw new BoardMoa_Error(401, 'not_permitted', '글쓴이만 읽을 수 있는 글입니다.');
            }
            if (!$content->notice && (int)$content->member_uid !== $uid && (int)$content->getTopContent()->member_uid !== $uid) {
                throw new BoardMoa_Error(403, 'not_permitted', '글쓴이만 읽을 수 있는 글입니다.');
            }
        }
        $password = BoardMoa_Api::param('password');
        if ($password !== null && $password !== '') {
            $_POST['password'] = $password;
        } else {
            unset($_POST['password']);
        }
        if ($content->isReader()) {
            return 'ok';
        }
        if ($kb->permission_read !== 'all' && !is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!$content->secret) {
            throw BoardMoa_Api::denied();
        }
        if ($content->isConfirm()) {
            return 'ok';
        }
        if ($content->parent_uid) {
            $parent = new KBContent();
            $parent->initWithUID($content->getTopContentUID());
            if ($kb->isReader($parent->member_uid, $content->secret) || $parent->isConfirm()) {
                return 'ok';
            }
        }
        if ($password !== null && $password !== '') {
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        return 'locked';
    }

    /** 글 읽기 감소 포인트(myCRED): 웹 본문 화면과 같다. 모자라면 읽지 못한다 */
    private function readPoints($kb, $content)
    {
        if (!$kb->meta->document_read_down_point || ($kb->meta->point_applied_to && $kb->isAdmin()) || !function_exists('mycred_add')) {
            return;
        }
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if ((int)$content->member_uid === get_current_user_id() || !class_exists('myCRED_Query_Log')) {
            return;
        }
        $log = new myCRED_Query_Log(['user_id' => get_current_user_id(), 'ref' => 'document_read_down_point', 'ref_id' => $content->uid]);
        if ($log->have_entries()) {
            return;
        }
        $balance = mycred_get_users_balance(get_current_user_id());
        if ($kb->meta->document_read_down_point > $balance) {
            throw new BoardMoa_Error(403, 'not_permitted', '포인트가 모자랍니다.');
        }
        $point = intval(get_user_meta(get_current_user_id(), 'kboard_document_mycred_point', true));
        update_user_meta(get_current_user_id(), 'kboard_document_mycred_point', $point + ($kb->meta->document_read_down_point * -1));
        mycred_add('document_read_down_point', get_current_user_id(), ($kb->meta->document_read_down_point * -1), __('Reading decrease points', 'kboard'), $content->uid);
    }

    /** 본문 HTML: 웹 본문 화면과 같은 필터 (자동 링크·동영상·kboard_content·숏코드 설정) */
    private function render($kb, $content)
    {
        include_once KBOARD_DIR_PATH . '/helper/Autolink.helper.php';
        if (!$kb->use_editor && $kb->meta->autolink) {
            add_filter('kboard_content', 'kboard_video_url_to_iframe', 10, 1);
            add_filter('kboard_comments_content', 'kboard_video_url_to_iframe', 10, 1);
            add_filter('kboard_comments_content', 'kboard_autolink', 10, 1);
            $html = apply_filters('kboard_content_paragraph_breaks', kboard_autolink(self::contentOf($content)), null);
        } else {
            add_filter('kboard_comments_content', 'kboard_video_url_to_iframe', 10, 1);
            $html = apply_filters('kboard_content_paragraph_breaks', self::contentOf($content), null);
        }
        $html = apply_filters('kboard_content', $html, $content->uid, $kb->id);
        if ($kb->meta->shortcode_execute == 1) {
            if (!$kb->meta->shortcode_execute_only_admin || ($content->member_uid && $kb->isAdmin($content->member_uid))) {
                $html = do_shortcode($html);
            }
        } else {
            $html = str_replace(['[', ']'], ['&#91;', '&#93;'], $html);
        }
        return BoardMoa_Html::content($html);
    }

    private function files($board, $content, $srl)
    {
        $out = [];
        $i = 0;
        foreach ($content->getAttachmentList() as $key => $file) {
            $i++;
            $name = (string)(isset($file['file_name']) ? $file['file_name'] : $file[1]);
            $path = (string)(isset($file['file_path']) ? $file['file_path'] : $file[0]);
            $image = (bool)preg_match('/\.(jpe?g|png|gif|webp)$/i', $name);
            $out[] = [
                'file_srl' => BoardMoa_Store::num('kbf:' . (int)$content->uid . ':' . $key),
                'name' => $name,
                'size' => (int)(isset($file['file_size']) ? $file['file_size'] : $file[3]),
                'is_image' => $image,
                'image_url' => $image ? site_url($path) : null,
                'download' => ['r' => 'file', 'mid' => $board['mid'], 'document_srl' => $srl, 'file_srl' => BoardMoa_Store::num('kbf:' . (int)$content->uid . ':' . $key)],
            ];
        }
        return $out;
    }

    /** 답글을 쓸 수 있는가: 웹 글 화면의 [답글] 단추(isReply, 공지 아님)와 글 저장(editorExecute 의 isWriter) */
    private function canReply($kb, $content)
    {
        return (bool)$kb->isReply() && (bool)$kb->isWriter() && !$content->notice;
    }

    /** 비회원 글(손님 쓰기 게시판의 회원 번호 없는 글)이라 웹이 비밀번호로 고치고 지우게 하는가 */
    private function passwordManaged($kb, $content)
    {
        return !$content->isEditor() && $kb->permission_write === 'all' && !$content->member_uid && $content->getPassword() !== '';
    }

    public function document($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->content($board, $srl);
        $content->board = $kb;
        $kb->content = $content;
        kboard_builder_mod('document');
        $state = $this->readState($kb, $content);
        $grant = $this->grant($board);
        if ($state === 'locked') {
            kboard_builder_mod('list');
            return $this->detail($this->summarize($content, $kb), [
                'permanent_url' => add_query_arg(['mod' => 'document', 'uid' => $content->uid], get_permalink((int)$board['page'])),
                'password_edit' => $this->passwordManaged($kb, $content),
                'password_view' => $content->getPassword() !== '',
                'board' => $this->info($board, $grant),
            ]);
        }
        $this->readPoints($kb, $content);
        $content->increaseView();
        $html = $this->render($kb, $content);
        $summary = $this->summarize($content, $kb);
        $summary['summary'] = BoardMoa_Html::summary(self::contentOf($content));
        $editor = (bool)$content->isEditor();
        $passwordManaged = $this->passwordManaged($kb, $content);
        $visibleComments = $content->visibleComments() && $this->kbComments($kb);
        return $this->detail($summary, [
            'content_html' => $html,
            'files' => ($kb->isAttachmentDownload() && !self::pendingHidden($content)) ? $this->files($board, $content, $srl) : [],
            'permanent_url' => add_query_arg(['mod' => 'document', 'uid' => $content->uid], get_permalink((int)$board['page'])),
            'can_comment' => $visibleComments && $grant['write_comment'],
            'can_reply' => $this->canReply($kb, $content),
            'reply_title' => 'Re:' . (string)$content->title,
            'reply_secret' => (bool)$content->secret,
            'can_edit' => $editor,
            'can_delete' => $editor,
            // 비회원 글: 웹처럼 비밀번호를 넣으면 고치고 지운다. 비밀번호로 연 이번 요청에서도 권한은 주지 않는다(앱이 매번 비밀번호를 보낸다)
            'password_edit' => $passwordManaged,
            'board' => $this->info($board, $grant),
            'actions' => $this->actions($kb, $content),
            'comments' => $visibleComments ? $this->commentPage($kb, $content) : self::emptyComments(),
        ]);
    }

    /** 좋아요·싫어요 (KBoard 추천 권한 isVote, 설정 '추천 숨기기'면 없음) */
    private function actions($kb, $content)
    {
        $enabled = !$kb->meta->permission_vote_hide;
        $my = 0;
        if ($enabled && class_exists('KBVote')) {
            $vote = new KBVote();
            $args = ['target_uid' => $content->uid, 'target_type' => KBVote::$TYPE_DOCUMENT];
            if ($vote->isExists($args + ['target_vote' => KBVote::$VOTE_LIKE])) {
                $my = 1;
            } elseif ($vote->isExists($args + ['target_vote' => KBVote::$VOTE_UNLIKE])) {
                $my = -1;
            }
        }
        return [
            'vote_up' => ['enabled' => $enabled, 'count' => (int)$content->like, 'public' => false],
            'vote_down' => ['enabled' => $enabled, 'count' => (int)$content->unlike, 'public' => false],
            'my_vote' => $my,
            'can_cancel_vote' => false,
            'is_mine' => is_user_logged_in() && (int)$content->member_uid === get_current_user_id(),
            'can_scrap' => false,
            'can_declare' => false,
        ];
    }

    public function comments($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->content($board, $srl);
        if ($this->readState($kb, $content) !== 'ok') {
            throw BoardMoa_Api::denied('비밀글입니다.');
        }
        return ($content->visibleComments() && $this->kbComments($kb)) ? $this->commentPage($kb, $content) : self::emptyComments();
    }

    /** 댓글 나무를 웹 순서대로 펼친다 (KBCommentsBuilder::buildTreeList) */
    private function commentPage($kb, $content)
    {
        $builder = $this->commentBuilder($kb);
        $writer = $builder->isWriter();
        $flat = [];
        $walk = function ($parent, $depth) use (&$walk, &$flat, $kb, $content) {
            $list = new KBCommentList();
            $list->board = $kb;
            if ($parent) {
                $list->initWithParentUID($parent);
            } else {
                $list->initWithUID($content->uid);
            }
            while ($comment = $list->hasNext()) {
                $flat[] = [$comment, $depth, $parent];
                $walk((int)$comment->uid, $depth + 1);
            }
        };
        $walk(0, 0);
        $uid = get_current_user_id();
        $perPage = 100;
        $page = max(1, BoardMoa_Api::intParam('cpage', 1));
        $items = [];
        foreach (array_slice($flat, ($page - 1) * $perPage, $perPage) as $row) {
            list($c, $depth, $parent) = $row;
            $readable = (bool)$c->isReader();
            $editor = (bool)$c->isEditor();
            $userId = (int)$c->user_uid;
            $items[] = $this->commentItem([
                'comment_srl' => BoardMoa_Store::num('kbc:' . (int)$c->uid),
                'parent_srl' => $parent ? BoardMoa_Store::num('kbc:' . (int)$parent) : 0,
                'depth' => (int)$depth,
                'author' => BoardMoa_Html::text($c->getUserName()),
                'author_image' => $userId ? BoardMoa_Api::avatar($userId) : null,
                'author_srl' => $userId,
                'is_mine' => $uid && $userId === $uid,
                'regdate' => BoardMoa_Html::iso($c->created),
                'content_html' => $readable ? BoardMoa_Html::content(wpautop(kboard_autolink($c->content))) : null,
                'vote_count' => (int)$c->like,
                // 웹 댓글 목록: 댓글을 쓸 수 있는 사람에게만 지우기·고치기 단추, 관리 권한이면 바로, 비회원 댓글은 비회원에게 비밀번호로
                'can_delete' => $writer && $editor,
                'can_edit' => $writer && $editor && $readable,
                'password_edit' => $writer && !$editor && !is_user_logged_in() && (string)$c->password !== '',
            ]);
        }
        $total = count($flat);
        return ['items' => $items, 'page' => $page, 'total_pages' => max(1, (int)ceil($total / $perPage)), 'total_count' => $total];
    }

    public function boardOfDocument($srl)
    {
        $uid = self::uid($srl);
        if (!$uid) {
            return null;
        }
        global $wpdb;
        $boardId = (int)$wpdb->get_var($wpdb->prepare("SELECT board_id FROM {$wpdb->prefix}kboard_board_content WHERE uid = %d", $uid));
        $boards = $this->boards();
        return isset($boards['kb-' . $boardId]) ? $boards['kb-' . $boardId] : null;
    }

    public function locate($url)
    {
        $postId = url_to_postid($url);
        parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
        if (!$postId) {
            return null;
        }
        $boardId = array_search((int)$postId, $this->pages(), true);
        if ($boardId === false || !isset($this->boards()['kb-' . $boardId])) {
            return null;
        }
        $out = ['mid' => 'kb-' . $boardId];
        if (!empty($query['uid']) && (!isset($query['mod']) || $query['mod'] === 'document')) {
            // 번호 표에는 이 게시판에 실제로 있는 글만 넣는다 (아무 번호나 보내 표를 키우지 못하게)
            global $wpdb;
            $uid = (int)$query['uid'];
            $srl = BoardMoa_Store::find('kb:' . $uid);
            if (!$srl && $uid > 0 && $wpdb->get_var($wpdb->prepare("SELECT uid FROM {$wpdb->prefix}kboard_board_content WHERE uid = %d AND board_id = %d AND (status IS NULL OR status <> 'trash')", $uid, (int)$boardId))) {
                $srl = self::num($uid);
            }
            if ($srl) {
                $out['document_srl'] = $srl;
            }
        }
        return $out;
    }

    public function file($board)
    {
        $kb = $this->kb($board);
        $srl = BoardMoa_Api::intParam('document_srl');
        $content = $this->content($board, $srl);
        if ($this->readState($kb, $content) !== 'ok') {
            throw BoardMoa_Api::denied('비밀글입니다.');
        }
        if (!$kb->isAttachmentDownload()) {
            throw BoardMoa_Api::denied('파일을 내려받을 권한이 없습니다.');
        }
        $ref = BoardMoa_Store::ref(BoardMoa_Api::intParam('file_srl'));
        if (!$ref || !preg_match('/^kbf:(\d+):(.+)$/', $ref, $m) || (int)$m[1] !== (int)$content->uid) {
            throw new BoardMoa_Error(404, 'not_found', '없는 파일입니다.');
        }
        $list = $content->getAttachmentList();
        if (!isset($list[$m[2]])) {
            throw new BoardMoa_Error(404, 'not_found', '없는 파일입니다.');
        }
        // 웹 내려받기(KBController::fileDownload)를 그대로: 내려받기 포인트·횟수·훅
        $_GET['action'] = 'kboard_file_download';
        $_GET['uid'] = $content->uid;
        $_GET['file'] = $m[2];
        $_GET['kboard-file-download-nonce'] = wp_create_nonce('kboard-file-download');
        $_REQUEST = array_merge($_REQUEST, $_GET);
        $_SERVER['HTTP_REFERER'] = add_query_arg(['mod' => 'document', 'uid' => $content->uid], get_permalink((int)$board['page']));
        // KBoard 가 내려받기를 거절할 때(kboard_cannot_download_file 뒤 exit, '파일이 없습니다' alert 뒤 exit)는 웹 화면 대신 JSON 오류로.
        // 거절 훅은 KBoard 의 처리(alert·이동)보다 먼저 예외로 빠져나오고, 파일을 보내기 시작하면(kboard_file_download 뒤) 그대로 둔다
        $refuse = function ($action) {
            if ($action === 'go_login') {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            if ($action === 'not_enough_points') {
                throw new BoardMoa_Error(403, 'not_permitted', '포인트가 모자랍니다.');
            }
            throw BoardMoa_Api::denied('파일을 내려받을 권한이 없습니다.');
        };
        $release = function () {
            BoardMoa_Run::release();
        };
        add_action('kboard_cannot_download_file', $refuse, -1000, 1);
        add_action('kboard_file_download', $release, PHP_INT_MAX, 0);
        BoardMoa_Run::guard('not_found', 404, BoardMoa_Text::t('없는 파일입니다.'));
        try {
            $controller = new KBController();
            $controller->fileDownload();
        } finally {
            BoardMoa_Run::release();
            remove_action('kboard_cannot_download_file', $refuse, -1000);
            remove_action('kboard_file_download', $release, PHP_INT_MAX);
        }
        return null;
    }

    /** 글 화면 주소 (회원 전용 사이트 확인을 조회수·포인트보다 먼저 하려고) */
    public function documentUrl($board, $srl)
    {
        $uid = self::uid($srl);
        return $uid ? add_query_arg(['mod' => 'document', 'uid' => $uid], get_permalink((int)$board['page'])) : null;
    }

    // ---- 쓰기 (웹 양식 처리 함수를 그대로)

    /** 웹 글쓰기 양식과 같은 값으로 KBController::editorExecute 를 실행하고 글 번호를 돌려준다 */
    private function editorExecute($board, $content, array $fields)
    {
        $kb = $this->kb($board);
        $isUpdate = $content && $content->uid;
        $post = [
            'action' => 'kboard_editor_execute',
            'mod' => 'editor',
            'kboard-editor-execute-nonce' => wp_create_nonce('kboard-editor-execute'),
            'uid' => $isUpdate ? (int)$content->uid : 0,
            'board_id' => (int)$kb->id,
            'parent_uid' => $isUpdate ? (int)$content->parent_uid : 0,
            'member_uid' => $isUpdate ? (int)$content->member_uid : 0,
            'member_display' => $isUpdate ? (string)$content->member_display : '',
            'date' => $isUpdate ? (string)$content->date : '',
            'user_id' => get_current_user_id(),
            'category1' => $isUpdate ? (string)$content->category1 : '',
            'category2' => $isUpdate ? (string)$content->category2 : '',
            'secret' => $isUpdate ? (string)$content->secret : '',
            'notice' => $isUpdate ? (string)$content->notice : '',
            'wordpress_search' => $isUpdate ? (string)$content->search : '1',
        ];
        if ($isUpdate) {
            $post['kboard-editor-content-nonce'] = wp_create_nonce('kboard-editor-content-' . (int)$content->uid);
            if ($content->status) {
                $post['status'] = (string)$content->status;
            }
            // 옵션(추가 항목)은 웹 양식이 다시 보내므로 그대로 넘긴다
            foreach ((array)$content->option->toArray() as $key => $value) {
                $post['kboard_option_' . $key] = $value;
            }
        }
        $post = array_merge($post, $fields);
        $_POST = wp_slash($post);
        $_REQUEST = $_POST;
        $_SERVER['HTTP_REFERER'] = add_query_arg('mod', 'editor', get_permalink((int)$board['page']));
        $before = time();
        $run = BoardMoa_Run::call(function () {
            $controller = new KBController();
            $controller->editorExecute();
        });
        if ($run['died'] !== null) {
            throw $this->diedError($run['died'], $board, isset($post['captcha']));
        }
        if ($run['redirect'] === null) {
            $message = BoardMoa_Run::messageOf($run['output']);
            throw new BoardMoa_Error(400, 'write_failed', $message !== '' ? $message : BoardMoa_Text::t('글을 저장하지 못했습니다.'), $message !== '');
        }
        parse_str((string)parse_url($run['redirect'], PHP_URL_QUERY), $query);
        $uid = (int)(isset($query['execute_uid']) ? $query['execute_uid'] : (isset($query['uid']) ? $query['uid'] : 0));
        if (!$uid && $isUpdate) {
            $uid = (int)$content->uid;
        }
        if (!$uid) {
            throw new BoardMoa_Error(400, 'write_failed', '글을 저장하지 못했습니다.');
        }
        return $uid;
    }

    /** 분류 번호(앱) → 이름. 없으면 원래 값 */
    private function categoryName($kb, $default)
    {
        $category = BoardMoa_Api::param('category_srl');
        if ($category === null) {
            return $default;
        }
        $names = $this->categoryNames($kb);
        return isset($names[(int)$category - 1]) ? $names[(int)$category - 1] : '';
    }

    /** 계층형 분류 번호(앱) → 웹 양식 값 kboard_option_tree_category_N (보내지 않으면 그대로, 0 이면 비운다) */
    private function treeFields($kb, array &$fields)
    {
        $tree = $this->treeCategories($kb);
        $category = BoardMoa_Api::param('category_srl');
        if (!$tree || $category === null) {
            return;
        }
        $path = $this->treePath($kb, (int)$category);
        for ($i = 1; $i <= count($tree); $i++) {
            $fields['kboard_option_tree_category_' . $i] = isset($path[$i - 1]) ? $path[$i - 1] : '';
        }
    }

    public function write($board)
    {
        $kb = $this->kb($board);
        if (!$kb->isWriter()) {
            throw BoardMoa_Api::denied();
        }
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $html = BoardMoa_Html::contentParam();
        if ($title === '' || $html === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $photos = self::photos();
        // 답글 (parent_srl): 웹의 [답글] 과 같은 조건, 원글을 읽을 수 있어야 한다. 분류는 원글 것을 이어받는다 (웹 답글 양식과 같다)
        $parent = null;
        if (BoardMoa_Api::intParam('parent_srl')) {
            $parent = $this->content($board, BoardMoa_Api::intParam('parent_srl'));
            $parent->board = $kb;
            if ($this->readState($kb, $parent) === 'locked' || !$this->canReply($kb, $parent)) {
                throw BoardMoa_Api::denied();
            }
        }
        $fields = ['title' => $title, 'kboard_content' => $html, 'category1' => $this->categoryName($kb, $parent ? (string)$parent->category1 : ''), 'secret' => BoardMoa_Api::boolParam('is_secret') ? 'true' : ''];
        if ($parent) {
            $fields['parent_uid'] = (int)$parent->uid;
            $fields['category2'] = (string)$parent->category2;
        }
        $this->treeFields($kb, $fields);
        if (!is_user_logged_in()) {
            $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
            $password = (string)BoardMoa_Api::param('password', '');
            if ($nick === '' || $password === '') {
                throw new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력해 주세요.');
            }
            $fields['member_display'] = $nick;
            $fields['password'] = $password;
        }
        $this->captchaInput($kb, false, $fields, $board);
        if ($photos) {
            list($group, $photoHtml) = $this->uploadPhotos($kb, $photos, null);
            $fields['media_group'] = $group;
            $fields['kboard_content'] .= "\n" . $photoHtml;
        }
        $uid = $this->editorExecute($board, null, $fields);
        return ['document_srl' => self::num($uid)];
    }

    /**
     * 고칠 수 있는 글: 웹 글쓰기 화면(builderEditor)·처리 함수와 같다 — isEditor, 또는 손님 쓰기 게시판의 비회원 글이면 비밀번호 확인.
     * 비밀번호는 KBoard 가 $_POST['password'] 로 확인한다.
     */
    private function editable($board, $srl, $forDelete = false)
    {
        $kb = $this->kb($board);
        $content = $this->content($board, $srl);
        if ($content->isEditor()) {
            return $content;
        }
        if ($kb->permission_write === 'all' && !$content->member_uid) {
            $password = (string)BoardMoa_Api::param('password', '');
            if ($password === '') {
                if (!is_user_logged_in()) {
                    throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
                }
                throw BoardMoa_Api::denied();
            }
            $_POST['password'] = $password;
            if (!$content->isConfirm($forDelete)) {
                throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
            }
            return $content;
        }
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        throw BoardMoa_Api::denied();
    }

    public function source($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->editable($board, $srl);
        $names = $this->categoryNames($kb);
        $cat = $names ? array_search((string)$content->category1, $names, true) : false;
        $grant = $this->grant($board);
        return [
            'document_srl' => (int)$srl,
            'title' => BoardMoa_Html::text($content->getTitle()),
            'content' => (string)$content->getContent(),
            'base_url' => trailingslashit(home_url('/')),
            'manage' => null,
            'extra_keys' => [],
            'extra_values' => (object)[],
            'board' => $this->info($board, $grant),
            'category_srl' => $cat === false ? $this->treeOf($kb, $content) : $cat + 1,
            'upload' => $this->uploadInfo($kb, $content),
        ];
    }

    public function update($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->editable($board, $srl);
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $html = (string)BoardMoa_Api::param('content', '');
        if ($title === '' || trim(wp_strip_all_tags($html)) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $photos = self::photos();
        $fields = ['title' => $title, 'kboard_content' => $html, 'category1' => $this->categoryName($kb, (string)$content->category1)];
        $this->treeFields($kb, $fields);
        if (BoardMoa_Api::param('password') !== null) {
            $fields['password'] = (string)BoardMoa_Api::param('password');
        }
        if ($photos) {
            list($group, $photoHtml) = $this->uploadPhotos($kb, $photos, $content);
            $fields['media_group'] = $group;
            $fields['kboard_content'] .= "\n" . $photoHtml;
        }
        $this->editorExecute($board, $content, $fields);
        return ['document_srl' => (int)$srl];
    }

    public function delete($board, $srl)
    {
        // 웹 지우기(KBoardBuilder::builderRemove)와 같다: 고칠 권한 또는 비밀번호, 설정에 따라 휴지통 또는 바로 삭제
        $content = $this->editable($board, $srl, true);
        if (get_option('kboard_content_delete_immediately')) {
            $content->remove();
        } else {
            $content->status = 'trash';
            $content->updateContent();
        }
        return ['deleted' => true];
    }

    public function vote($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->content($board, $srl);
        if ($this->readState($kb, $content) !== 'ok') {
            throw BoardMoa_Api::denied('비밀글입니다.');
        }
        $point = BoardMoa_Api::intParam('point', 1);
        if (BoardMoa_Api::boolParam('cancel')) {
            throw new BoardMoa_Error(400, 'vote_failed', '추천은 취소할 수 없습니다.');
        }
        // 웹 좋아요·싫어요(KBController::documentLike·documentUnlike)와 같은 처리
        if ($kb->meta->permission_vote_hide || !$kb->isVote()) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $args = ['target_uid' => $content->uid, 'target_type' => KBVote::$TYPE_DOCUMENT, 'target_vote' => $point < 0 ? KBVote::$VOTE_UNLIKE : KBVote::$VOTE_LIKE];
        $vote = new KBVote();
        if ($vote->isExists($args) !== 0) {
            throw new BoardMoa_Error(400, 'vote_failed', __('You have already voted.', 'kboard'), true);
        }
        if ($vote->insert($args)) {
            if ($point < 0) {
                $content->unlike += 1;
            } else {
                $content->like += 1;
            }
            $content->vote = $content->like - $content->unlike;
            $content->updateContent();
            do_action($point < 0 ? 'kboard_content_unlike' : 'kboard_content_like', $content, $kb);
        }
        $content = $this->content($board, $srl);
        return $this->actions($kb, $content);
    }

    // ---- 댓글

    private function commentObject($board, $commentSrl)
    {
        $ref = BoardMoa_Store::ref($commentSrl);
        if (!$ref || !preg_match('/^kbc:(\d+)$/', $ref, $m)) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        $comment = new KBComment();
        $comment->initWithUID((int)$m[1]);
        if (!$comment->uid) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        $content = $this->content($board, self::num((int)$comment->content_uid));
        return [$comment, $content];
    }

    public function commentWrite($board, $srl)
    {
        $kb = $this->kb($board);
        $content = $this->content($board, $srl);
        if ($this->readState($kb, $content) !== 'ok' || !$content->visibleComments() || !$this->kbComments($kb)) {
            throw BoardMoa_Api::denied();
        }
        if (!$this->commentBuilder($kb)->isWriter()) {
            throw BoardMoa_Api::denied();
        }
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        if ($text === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $post = [
            'content_uid' => (int)$content->uid,
            'comment_content' => esc_html($text),
            'parent_uid' => 0,
            'member_uid' => get_current_user_id(),
            'kboard-comments-execute-nonce' => wp_create_nonce('kboard-comments-execute-' . (int)$content->uid),
        ];
        $parent = BoardMoa_Api::intParam('parent_srl');
        if ($parent) {
            $ref = BoardMoa_Store::ref($parent);
            if ($ref && preg_match('/^kbc:(\d+)$/', $ref, $m)) {
                $post['parent_uid'] = (int)$m[1];
            }
        }
        if (!is_user_logged_in()) {
            $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
            $password = (string)BoardMoa_Api::param('password', '');
            if ($nick === '' && $password === '') {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            if ($nick === '' || $password === '') {
                throw new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력해 주세요.');
            }
            $post['member_display'] = $nick;
            $post['password'] = $password;
        }
        $this->captchaInput($kb, true, $post, $board);
        $_POST = wp_slash($post);
        $_REQUEST = $_POST;
        $_SERVER['HTTP_REFERER'] = add_query_arg(['mod' => 'document', 'uid' => $content->uid], get_permalink((int)$board['page']));
        $captured = 0;
        $hook = function ($commentUid) use (&$captured) {
            $captured = (int)$commentUid;
        };
        add_action('kboard_comments_insert', $hook, 1);
        $run = BoardMoa_Run::call(function () {
            $controller = new KBCommentController();
            $controller->insert();
        });
        remove_action('kboard_comments_insert', $hook, 1);
        if ($run['died'] !== null) {
            throw $this->diedError($run['died'], $board, isset($post['captcha']));
        }
        if (!$captured) {
            $message = BoardMoa_Run::messageOf($run['output']);
            throw new BoardMoa_Error(400, 'comment_failed', $message !== '' ? $message : BoardMoa_Text::t('댓글을 쓰지 못했습니다.'), $message !== '');
        }
        return ['comment_srl' => BoardMoa_Store::num('kbc:' . $captured), 'document_srl' => (int)$srl, 'pending' => (bool)$kb->meta->comment_permit];
    }

    /** 댓글을 고치거나 지울 수 있는가 (웹 KBCommentController::update·delete 와 같은 판단: isEditor 또는 비회원 댓글 비밀번호) */
    private function editableComment($board, $commentSrl)
    {
        $kb = $this->kb($board);
        list($comment, $content) = $this->commentObject($board, $commentSrl);
        if ($this->readState($kb, $content) !== 'ok' || !$this->commentBuilder($kb)->isWriter()) {
            throw BoardMoa_Api::denied();
        }
        if ($comment->isEditor()) {
            return [$comment, $content];
        }
        $password = (string)BoardMoa_Api::param('password', '');
        if ($password === '') {
            if (!is_user_logged_in()) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            throw BoardMoa_Api::denied();
        }
        if (is_user_logged_in() || !$comment->getPassword()) {
            throw BoardMoa_Api::denied();
        }
        if (!$comment->checkPassword($password, false)) {
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        return [$comment, $content];
    }

    public function commentUpdate($board, $commentSrl)
    {
        $kb = $this->kb($board);
        list($comment, $content) = $this->editableComment($board, $commentSrl);
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        if ($text === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        do_action('kboard_comments_pre_update', $comment->uid, $comment->content_uid, $kb);
        $comment->content = esc_html($text);
        $comment = apply_filters('kboard_comments_update_data', $comment, $kb->id);
        $comment->update();
        return ['comment_srl' => (int)$commentSrl, 'document_srl' => self::num((int)$content->uid)];
    }

    public function commentDelete($board, $commentSrl)
    {
        $kb = $this->kb($board);
        list($comment) = $this->editableComment($board, $commentSrl);
        do_action('kboard_comments_pre_delete', $comment->uid, $comment->content_uid, $kb);
        $comment->delete();
        return ['deleted' => true];
    }

    // ---- 내 활동 (목록을 볼 수 있는 게시판의 내 글·댓글)

    private function listableById()
    {
        $out = [];
        foreach ($this->boards() as $b) {
            if ($this->canList($b)) {
                $out[(int)$b['ref']] = $b;
            }
        }
        return $out;
    }

    public function myDocuments($limit)
    {
        global $wpdb;
        $boards = $this->listableById();
        if (!$boards) {
            return [];
        }
        $ids = implode(',', array_map('intval', array_keys($boards)));
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}kboard_board_content WHERE member_uid = %d AND board_id IN ($ids) AND (status IS NULL OR status <> 'trash') ORDER BY date DESC LIMIT %d", get_current_user_id(), $limit));
        $out = [];
        kboard_builder_mod('list');
        foreach ((array)$rows as $row) {
            $content = new KBContent();
            $content->initWithRow($row);
            $b = $boards[(int)$row->board_id];
            $s = $this->summarize($content, $this->kb($b));
            $s['mid'] = $b['mid'];
            $s['board_title'] = $b['title'];
            $out[] = ['time' => BoardMoa_Html::timestamp($row->date), 'summary' => $s];
        }
        return $out;
    }

    public function myComments($limit)
    {
        global $wpdb;
        $boards = $this->listableById();
        if (!$boards) {
            return [];
        }
        $ids = implode(',', array_map('intval', array_keys($boards)));
        $rows = $wpdb->get_results($wpdb->prepare("SELECT c.uid, c.content, c.created, c.content_uid, d.title, d.board_id, d.status FROM {$wpdb->prefix}kboard_comments c JOIN {$wpdb->prefix}kboard_board_content d ON d.uid = c.content_uid WHERE c.user_uid = %d AND d.board_id IN ($ids) AND (d.status IS NULL OR d.status <> 'trash') ORDER BY c.created DESC LIMIT %d", get_current_user_id(), $limit));
        $out = [];
        foreach ((array)$rows as $row) {
            $b = $boards[(int)$row->board_id];
            $title = (string)$row->title;
            if ((string)$row->status === 'pending_approval') {
                // 남의 승인 대기 글에 단 댓글: 글 제목은 웹처럼 안내 문구
                $doc = new KBContent();
                $doc->initWithUID((int)$row->content_uid);
                $title = self::titleOf($doc);
            }
            $out[] = ['time' => BoardMoa_Html::timestamp($row->created), 'comment' => [
                'comment_srl' => BoardMoa_Store::num('kbc:' . (int)$row->uid), 'document_srl' => self::num((int)$row->content_uid),
                'content' => BoardMoa_Html::summary($row->content, 200), 'regdate' => BoardMoa_Html::iso($row->created), 'is_secret' => false,
                'document_title' => BoardMoa_Html::text($title), 'mid' => $b['mid'], 'board_title' => $b['title'],
            ]];
        }
        return $out;
    }
}
