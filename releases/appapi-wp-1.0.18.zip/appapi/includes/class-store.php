<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 플러그인이 쓰는 표 두 개.
 * - <prefix>appapi_tokens: 기기별 로그인 토큰 (원문 대신 SHA-256 해시만). XE1 모듈·XE3 플러그인과 같은 동작.
 * - <prefix>appapi_views: 앱 접속(X-BoardHub-Session)별로 읽은 글 (하루, 해시만). 조회수를 웹 세션처럼 한 번만 올린다.
 * - <prefix>appapi_ids: KBoard·망보드 글·댓글처럼 워드프레스 글 번호가 아닌 것 ↔ 앱이 쓰는 정수 번호.
 *   워드프레스 글(post)·bbPress 토픽·답글·워드프레스 댓글은 원래 번호를 그대로 쓰고, 이 표의 번호는 1,000,000,000 부터라 겹치지 않는다.
 */
class BoardMoa_Store
{
    const ACCESS_TTL = 3600;
    const REFRESH_TTL = 31536000;
    const DB_VERSION = '3';
    const ID_BASE = 1000000000;

    public static function tokens()
    {
        global $wpdb;
        return $wpdb->prefix . 'appapi_tokens';
    }

    public static function ids()
    {
        global $wpdb;
        return $wpdb->prefix . 'appapi_ids';
    }

    public static function views()
    {
        global $wpdb;
        return $wpdb->prefix . 'appapi_views';
    }

    public static function install()
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $tokens = self::tokens();
        $ids = self::ids();
        dbDelta("CREATE TABLE $tokens (
  token_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  access_hash char(64) NOT NULL,
  access_expires int(10) unsigned NOT NULL,
  refresh_hash char(64) NOT NULL,
  prev_refresh_hash char(64) DEFAULT NULL,
  refresh_expires int(10) unsigned NOT NULL,
  password_sig char(64) NOT NULL,
  app_password char(36) NOT NULL DEFAULT '',
  device_name varchar(100) NOT NULL DEFAULT '',
  platform varchar(20) NOT NULL DEFAULT '',
  ipaddress varchar(64) NOT NULL DEFAULT '',
  created int(10) unsigned NOT NULL,
  last_used int(10) unsigned NOT NULL,
  PRIMARY KEY  (token_id),
  UNIQUE KEY access_hash (access_hash),
  UNIQUE KEY refresh_hash (refresh_hash),
  KEY prev_refresh_hash (prev_refresh_hash),
  KEY user_id (user_id)
) $charset;");
        dbDelta("CREATE TABLE $ids (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(190) NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref)
) $charset;");
        $views = self::views();
        dbDelta("CREATE TABLE $views (
  view_hash char(64) NOT NULL,
  created int(10) unsigned NOT NULL,
  PRIMARY KEY  (view_hash),
  KEY created (created)
) $charset;");
        // 번호가 워드프레스 글 번호와 겹치지 않게: 시작 번호 줄(ID_BASE)을 실제로 넣어 둔다.
        // AUTO_INCREMENT 값만 바꾸면 MySQL 5.7 이하는 다시 켤 때 표의 가장 큰 번호 + 1 로 되돌려(빈 표면 1) 겹칠 수 있다
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $ids (id, ref) VALUES (%d, %s)", self::ID_BASE, '#base'));
        // 그렇게 되돌아가 이미 작은 번호로 들어간 줄은 쓸 수 없다(ref() 가 읽지 않는다): 지우면 다음에 새 번호로 다시 만든다
        $wpdb->query($wpdb->prepare("DELETE FROM $ids WHERE id < %d", self::ID_BASE));
        update_option('boardmoa_db_version', self::DB_VERSION, false);
    }

    public static function ensureTables()
    {
        if (get_option('boardmoa_db_version') !== self::DB_VERSION) {
            self::install();
        }
    }

    // ---- 앱 접속별로 읽은 글 (그누보드·XE 모듈과 같다: 앱은 실행할 때마다 만드는 접속 번호를 X-BoardHub-Session 으로 보낸다)

    private static function viewHash($ref)
    {
        $session = isset($_SERVER['HTTP_X_BOARDHUB_SESSION']) ? (string)$_SERVER['HTTP_X_BOARDHUB_SESSION'] : '';
        if (!preg_match('/^[A-Za-z0-9\-]{16,64}$/', $session)) {
            return null;
        }
        return hash('sha256', $session . '|' . $ref);
    }

    /** 이 앱 접속에서 이 글을 처음 읽는가 (하루). 처음이면 읽었다고 적어 두고 참. 접속 번호가 없으면(예전 앱) 늘 참 */
    public static function firstView($ref)
    {
        global $wpdb;
        $hash = self::viewHash($ref);
        if ($hash === null) {
            return true;
        }
        $table = self::views();
        $now = time();
        if ($wpdb->get_var($wpdb->prepare("SELECT 1 FROM $table WHERE view_hash = %s AND created > %d", $hash, $now - 86400))) {
            return false;
        }
        $wpdb->query($wpdb->prepare("REPLACE INTO $table (view_hash, created) VALUES (%s, %d)", $hash, $now));
        if (mt_rand(1, 100) === 1) {
            $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE created < %d", $now - 86400));
        }
        return true;
    }

    // ---- 외부 번호 ↔ 정수

    private static $num = [];
    private static $ref = [];

    /** 'kb:12'·'kbc:5'·'mb:free:3' 같은 열쇠의 정수 번호 (처음 보면 만든다) */
    public static function num($ref)
    {
        global $wpdb;
        $ref = (string)$ref;
        if ($ref === '') {
            return 0;
        }
        if (!isset(self::$num[$ref])) {
            $table = self::ids();
            $id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE ref = %s", $ref));
            if (!$id) {
                $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (ref) VALUES (%s)", $ref));
                $id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE ref = %s", $ref));
            }
            self::$num[$ref] = $id;
            self::$ref[$id] = $ref;
        }
        return self::$num[$ref];
    }

    /** 이미 있는 번호만 (없으면 0, 만들지 않는다). 주소 풀기처럼 아무 값이나 들어오는 곳에서 */
    public static function find($ref)
    {
        global $wpdb;
        $ref = (string)$ref;
        if ($ref === '') {
            return 0;
        }
        if (isset(self::$num[$ref])) {
            return self::$num[$ref];
        }
        $table = self::ids();
        $id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE ref = %s", $ref));
        if ($id) {
            self::$num[$ref] = $id;
            self::$ref[$id] = $ref;
        }
        return $id;
    }

    /** 미리 여러 개를 한 번에 (목록용) */
    public static function nums(array $refs)
    {
        $out = [];
        foreach ($refs as $ref) {
            $out[$ref] = self::num($ref);
        }
        return $out;
    }

    /** 정수 번호의 열쇠 (없으면 null) */
    public static function ref($num)
    {
        global $wpdb;
        $num = (int)$num;
        if ($num < self::ID_BASE) {
            return null;
        }
        if (!array_key_exists($num, self::$ref)) {
            $table = self::ids();
            $ref = $wpdb->get_var($wpdb->prepare("SELECT ref FROM $table WHERE id = %d", $num));
            self::$ref[$num] = $ref === null ? null : (string)$ref;
        }
        return self::$ref[$num];
    }

    // ---- 토큰

    public static function passwordSig($passwordHash)
    {
        return hash('sha256', 'appapi|' . $passwordHash);
    }

    private static function newToken()
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    private static function hash($token)
    {
        return hash('sha256', (string)$token);
    }

    private static function output($access, $refresh)
    {
        return [
            'access_token' => $access,
            'access_expires_in' => self::ACCESS_TTL,
            'refresh_token' => $refresh,
            'refresh_expires_in' => self::REFRESH_TTL,
        ];
    }

    /** $appPassword: 애플리케이션 비밀번호로 로그인했으면 그 비밀번호의 uuid (그 비밀번호를 지우면 토큰도 무효) */
    public static function issue($userId, $passwordHash, $deviceName, $platform, $ip, $appPassword = '')
    {
        global $wpdb;
        $access = self::newToken();
        $refresh = self::newToken();
        $now = time();
        $wpdb->insert(self::tokens(), [
            'user_id' => (int)$userId,
            'access_hash' => self::hash($access), 'access_expires' => $now + self::ACCESS_TTL,
            'refresh_hash' => self::hash($refresh), 'refresh_expires' => $now + self::REFRESH_TTL,
            'password_sig' => self::passwordSig($passwordHash),
            'app_password' => substr((string)$appPassword, 0, 36),
            'device_name' => mb_substr((string)$deviceName, 0, 100), 'platform' => mb_substr((string)$platform, 0, 20),
            'ipaddress' => (string)$ip, 'created' => $now, 'last_used' => $now,
        ]);
        if (mt_rand(1, 50) === 1) {
            $wpdb->query($wpdb->prepare('DELETE FROM ' . self::tokens() . ' WHERE refresh_expires < %d', $now));
        }
        return self::output($access, $refresh);
    }

    public static function findByAccess($access)
    {
        global $wpdb;
        if ((string)$access === '') {
            return null;
        }
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::tokens() . ' WHERE access_hash = %s', self::hash($access)));
        return ($row && (int)$row->access_expires >= time()) ? $row : null;
    }

    /** 새 접근 토큰이 처음 쓰였으니 직전 갱신 토큰은 더 받지 않는다 */
    public static function touch($row)
    {
        global $wpdb;
        $now = time();
        if ($row->prev_refresh_hash !== null || (int)$row->last_used < $now - 60) {
            $wpdb->update(self::tokens(), ['last_used' => $now, 'prev_refresh_hash' => null], ['token_id' => (int)$row->token_id]);
        }
    }

    /** 갱신 토큰으로 새 쌍 (회전). 응답이 유실돼도, 새 접근 토큰이 처음 쓰일 때까지 직전 갱신 토큰도 받는다. [행, 토큰] 또는 null */
    public static function rotate($refresh, $ip)
    {
        global $wpdb;
        if ((string)$refresh === '') {
            return null;
        }
        $hash = self::hash($refresh);
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::tokens() . ' WHERE refresh_hash = %s OR prev_refresh_hash = %s LIMIT 1', $hash, $hash));
        if (!$row || (int)$row->refresh_expires < time()) {
            return null;
        }
        $access = self::newToken();
        $newRefresh = self::newToken();
        $now = time();
        $wpdb->update(self::tokens(), [
            'access_hash' => self::hash($access), 'access_expires' => $now + self::ACCESS_TTL,
            'refresh_hash' => self::hash($newRefresh), 'prev_refresh_hash' => $row->refresh_hash,
            'refresh_expires' => $now + self::REFRESH_TTL, 'ipaddress' => (string)$ip, 'last_used' => $now,
        ], ['token_id' => (int)$row->token_id]);
        return [$row, self::output($access, $newRefresh)];
    }

    public static function revoke($tokenId)
    {
        global $wpdb;
        $wpdb->delete(self::tokens(), ['token_id' => (int)$tokenId]);
    }

    public static function revokeAppPassword($userId, $uuid)
    {
        global $wpdb;
        if ((string)$uuid !== '') {
            self::ensureTables();
            $wpdb->delete(self::tokens(), ['user_id' => (int)$userId, 'app_password' => (string)$uuid]);
        }
    }

        public static function revokeUser($userId)
    {
        global $wpdb;
        $wpdb->delete(self::tokens(), ['user_id' => (int)$userId]);
    }
}
