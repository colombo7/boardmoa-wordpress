<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 사이트 전체를 회원만 보게 하는 플러그인 (웹은 비회원을 로그인 화면으로 보낸다).
 * 그 플러그인들은 화면을 그리기 직전(template_redirect·parse_request)에 막는데, 앱 요청은 그 전에 처리하고 끝나서
 * 같은 판단을 여기서 다시 한다. 비회원에게만 해당한다(이 플러그인들은 로그인한 회원은 들여보낸다).
 *  - Force Login (wp-force-login): 모든 주소. 예외는 플러그인 필터 v_forcelogin_bypass(·옛 v_forcelogin_whitelist) 그대로
 *  - Members: 설정 '사이트 비공개'(members_is_private_blog). 예외는 members_is_private_page 필터
 *  - Ultimate Member: 전체 접근 '로그인한 회원만'(accessible 2). 예외: 첫 화면·분류 보관함 허용 설정, 제외 주소
 *  - Restricted Site Access: 플러그인의 판단 함수(restrict_access_check, 허용 IP 포함)
 *  - 그 밖의 플러그인은 필터 boardmoa_guest_blocked($blocked, $url) 로 알린다
 * 막힌 주소의 게시판은 메뉴·모아 보기·링크에 나오지 않고, 열면 401 login_required(앱이 로그인을 권한다).
 */
class BoardMoa_Gate
{
    private static $cache = [];

    /** 비회원이 웹에서 이 주소를 열면 로그인 화면으로 가는가 */
    public static function blocks($url)
    {
        if (is_user_logged_in()) {
            return self::maintenance();
        }
        $url = (string)$url;
        if ($url === '') {
            $url = home_url('/');
        }
        if (!array_key_exists($url, self::$cache)) {
            $blocked = false;
            try {
                $blocked = self::maintenance() || self::forceLogin($url) || self::members() || self::ultimateMember($url) || self::restrictedSiteAccess();
            } catch (Throwable $e) {
                $blocked = true; // 판단하지 못하면 막는다 (웹보다 더 보여 주지 않게)
            }
            self::$cache[$url] = (bool)apply_filters('boardmoa_guest_blocked', $blocked, $url);
        }
        return self::$cache[$url];
    }

    /** 사이트 첫 화면부터 막혔는가 (사이트 전체가 회원 전용) */
    public static function siteLocked()
    {
        return self::blocks(home_url('/'));
    }

    /**
     * 점검·준비 중 화면 (Elementor 의 유지 보수 모드): 웹은 제외한 사람(로그인한 회원 또는 고른 역할) 말고는 점검 화면만 보인다.
     * 회원에게도 해당할 수 있다.
     */
    public static function maintenance()
    {
        static $result = null;
        if ($result === null) {
            $result = false;
            if (class_exists('Elementor\\Maintenance_Mode') && get_option('elementor_maintenance_mode_mode') && get_option('elementor_maintenance_mode_template_id')) {
                $exclude = get_option('elementor_maintenance_mode_exclude_mode', []);
                $result = true;
                if ($exclude === 'logged_in' && is_user_logged_in()) {
                    $result = false;
                } elseif ($exclude === 'custom') {
                    $user = wp_get_current_user();
                    $roles = (array)$user->roles;
                    if (is_multisite() && is_super_admin()) {
                        $roles[] = 'super_admin';
                    }
                    if (array_intersect($roles, (array)get_option('elementor_maintenance_mode_exclude_roles', []))) {
                        $result = false;
                    }
                }
            }
            $result = (bool)apply_filters('boardmoa_maintenance', $result);
        }
        return $result;
    }

    private static function forceLogin($url)
    {
        if (!function_exists('v_forcelogin') || has_action('template_redirect', 'v_forcelogin') === false) {
            return false;
        }
        // 플러그인과 같은 예외: 허용 목록(옛 필터) 또는 v_forcelogin_bypass 가 참인 주소
        $allowed = (array)apply_filters('v_forcelogin_whitelist', []);
        return !apply_filters('v_forcelogin_bypass', in_array($url, $allowed, true), $url);
    }

    private static function members()
    {
        if (!function_exists('members_is_private_blog') || !members_is_private_blog()) {
            return false;
        }
        if (has_action('template_redirect', 'members_please_log_in') === false) {
            return false;
        }
        return function_exists('members_is_private_page') ? (bool)members_is_private_page() : true;
    }

    private static function ultimateMember($url)
    {
        if (!function_exists('UM')) {
            return false;
        }
        $options = UM()->options();
        if ((int)$options->get('accessible') !== 2) {
            return false;
        }
        $path = untrailingslashit((string)parse_url($url, PHP_URL_PATH));
        $home = untrailingslashit((string)parse_url(home_url('/'), PHP_URL_PATH));
        if ($path === $home && !parse_url($url, PHP_URL_QUERY)) {
            return !$options->get('home_page_accessible');
        }
        // 분류 보관함 (UM 설정 '분류 페이지는 누구나')
        if ($options->get('category_page_accessible')) {
            $base = trim((string)get_option('category_base'), '/') ?: 'category';
            if (strpos(rawurldecode($path), $home . '/' . $base . '/') === 0) {
                return false;
            }
        }
        $exclude = array_map('trim', (array)$options->get('access_exclude_uris'));
        $exclude[] = trim((string)$options->get('access_redirect'));
        $plain = untrailingslashit($url);
        foreach ($exclude as $item) {
            if ($item !== '' && ($item === $plain || $item === trailingslashit($plain))) {
                return false;
            }
        }
        return true;
    }

    private static function restrictedSiteAccess()
    {
        if (!class_exists('Restricted_Site_Access') || !method_exists('Restricted_Site_Access', 'restrict_access_check')) {
            return false;
        }
        $result = null;
        $run = BoardMoa_Run::call(function () use (&$result) {
            $result = Restricted_Site_Access::restrict_access_check(new WP());
        });
        if ($run['redirect'] !== null || $run['died'] !== null) {
            return true;
        }
        return is_array($result);
    }

    /** 401: 회원만 보는 사이트·게시판 */
    public static function error()
    {
        if (is_user_logged_in()) {
            return new BoardMoa_Error(403, 'not_permitted', '사이트를 점검하고 있습니다. 잠시 뒤에 다시 와 주세요.');
        }
        return new BoardMoa_Error(401, 'login_required', self::maintenance() ? '사이트를 점검하고 있습니다. 잠시 뒤에 다시 와 주세요.' : '로그인해야 볼 수 있습니다.');
    }
}
