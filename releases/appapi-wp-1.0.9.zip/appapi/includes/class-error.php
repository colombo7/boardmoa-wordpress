<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 앱에 돌려줄 오류 (HTTP 상태, 오류 코드, 사용자에게 보일 문장 — 한국어 원문, BoardMoa_Text 가 바꾼다) */
class BoardMoa_Error extends Exception
{
    public $status;
    public $codeName;
    /** 이미 번역됐거나 엔진·플러그인이 만든 문구라 그대로 보낸다 */
    public $raw;
    /** error 에 더할 값 (captcha 위젯 등) */
    public $extra = [];

    public function __construct($status, $code, $message, $raw = false, array $extra = [])
    {
        parent::__construct((string)$message);
        $this->extra = $extra;
        $this->status = (int)$status;
        $this->codeName = (string)$code;
        $this->raw = (bool)$raw;
    }
}
