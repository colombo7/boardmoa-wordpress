<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 내 활동·회원 (docs/API.md '내 활동', '내 정보 수정', '회원가입') */
class BoardMoa_My
{
    /** 이 사이트에서 되는 것만 보낸다. 쪽지·친구·스크랩·알림은 워드프레스에 없다 */
    public static function menu()
    {
        return ['items' => [
            ['key' => 'documents', 'title' => BoardMoa_Text::t('내가 쓴 글')],
            ['key' => 'comments', 'title' => BoardMoa_Text::t('내가 쓴 댓글')],
        ]];
    }

    /** 내가 쓴 글: 목록을 볼 수 있는 게시판의 내 글 (어댑터마다 모아 최신순) */
    public static function documents()
    {
        $page = min(BoardMoa_Boards::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $count = 20;
        $rows = [];
        foreach (BoardMoa_Boards::adapters() as $adapter) {
            if (method_exists($adapter, 'myDocuments')) {
                $rows = array_merge($rows, $adapter->myDocuments($page * $count + 1));
            }
        }
        usort($rows, function ($a, $b) {
            return $b['time'] <=> $a['time'];
        });
        $total = count($rows);
        $docs = array_map(function ($row) {
            return $row['summary'];
        }, array_slice($rows, ($page - 1) * $count, $count));
        return ['documents' => $docs, 'page' => $page, 'total_pages' => $total > $page * $count ? $page + 1 : $page, 'total_count' => $total];
    }

    public static function comments()
    {
        $page = min(BoardMoa_Boards::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $count = 20;
        $rows = [];
        foreach (BoardMoa_Boards::adapters() as $adapter) {
            if (method_exists($adapter, 'myComments')) {
                $rows = array_merge($rows, $adapter->myComments($page * $count + 1));
            }
        }
        usort($rows, function ($a, $b) {
            return $b['time'] <=> $a['time'];
        });
        $total = count($rows);
        $items = array_map(function ($row) {
            return $row['comment'];
        }, array_slice($rows, ($page - 1) * $count, $count));
        return ['comments' => $items, 'page' => $page, 'total_pages' => $total > $page * $count ? $page + 1 : $page, 'total_count' => $total];
    }

    /** 이름 메뉴: 워드프레스에는 회원 정보 공개 화면·쪽지가 없어 앱이 할 것이 없다 */
    public static function memberMenu()
    {
        return ['member_srl' => BoardMoa_Api::intParam('member_srl'), 'actions' => []];
    }

    /** 회원가입은 웹에서 (워드프레스 가입 화면·가입 플러그인마다 항목이 다르다) */
    public static function signupForm()
    {
        $enabled = (bool)get_option('users_can_register');
        return [
            'enabled' => $enabled,
            'web_only' => true,
            'web_url' => wp_registration_url(),
            'basic' => [], 'agreements' => [], 'password_hint' => '', 'needs_confirm' => false, 'fields' => [],
        ];
    }

    // ---- 내 정보 수정 (웹의 프로필 화면 profile.php 와 같은 함수: wp_update_user)

    public static function form()
    {
        $user = wp_get_current_user();
        return [
            'nick_name' => (string)$user->display_name,
            'email_address' => (string)$user->user_email,
            'profile_image' => BoardMoa_Api::avatar($user->ID),
            'can_change_nickname' => true,
            // 메일을 바꾸면 워드프레스가 새 주소로 확인 메일을 보낸다(웹 프로필 화면) — 웹에서
            'can_change_email' => false,
            'profile_image_enabled' => false,
            'fields' => [],
        ];
    }

    private static function checkPassword($user)
    {
        $current = (string)BoardMoa_Api::param('current_password', '');
        if ($current === '' || !wp_check_password($current, $user->user_pass, $user->ID)) {
            throw new BoardMoa_Error(400, 'invalid_password', '지금 비밀번호가 맞지 않습니다.');
        }
    }

    public static function update()
    {
        $user = wp_get_current_user();
        self::checkPassword($user);
        $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
        if ($nick !== '' && $nick !== $user->display_name) {
            $result = wp_update_user(['ID' => $user->ID, 'display_name' => $nick, 'nickname' => $nick]);
            if (is_wp_error($result)) {
                throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
            }
        }
        return BoardMoa_Api::profile(get_userdata($user->ID));
    }

    public static function password()
    {
        $user = wp_get_current_user();
        self::checkPassword($user);
        $new = (string)BoardMoa_Api::param('new_password', '');
        if (strlen($new) < 6) {
            throw new BoardMoa_Error(400, 'update_failed', '새 비밀번호가 너무 짧습니다.');
        }
        $result = wp_update_user(['ID' => $user->ID, 'user_pass' => $new]);
        if (is_wp_error($result)) {
            throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
        }
        // 다른 기기의 앱 토큰은 모두 무효, 이 기기에는 새 토큰
        BoardMoa_Store::revokeUser($user->ID);
        $user = get_userdata($user->ID);
        return ['tokens' => BoardMoa_Store::issue($user->ID, $user->user_pass, BoardMoa_Api::param('device_name', ''), BoardMoa_Api::param('platform', ''), BoardMoa_Api::ip())];
    }
}
