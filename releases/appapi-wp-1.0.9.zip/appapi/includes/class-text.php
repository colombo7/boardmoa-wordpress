<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 플러그인 문구 언어 (한국어 원문 + 앱과 같은 11개 언어). 한국어 원문을 열쇠로 BoardMoa_Text::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 언어별 문구는 lang/text.<코드>.php (열쇠는 text.en.php 와 같다). 앱에 보내는 문구는 X-App-Lang(ko, en, ja, es, pt-BR, de, fr, it, vi, id, zh-Hant, zh-Hans),
 * 없으면(예전 앱) 사이트 언어. 관리 화면은 관리자 언어. 없는 언어는 영어(한국어는 한국어일 때만).
 * 문구 하나가 없으면 그 언어 → 기본 언어(pt-BR → pt) → 영어 → 한국어 원문.
 * 워드프레스·게시판 플러그인이 만든 문구와 사이트 내용은 바꾸지 않는다.
 */
class BoardMoa_Text
{
    /** 문구 언어 (앱의 Lang.Code 와 같다). ko 는 원문이라 파일이 없다 */
    const LANGUAGES = ['ko', 'en', 'ja', 'es', 'pt-BR', 'de', 'fr', 'it', 'vi', 'id', 'zh-Hant', 'zh-Hans'];

    private static $code = null;
    private static $tables = [];

    public static function code()
    {
        if (self::$code === null) {
            $requested = trim((string)($_SERVER['HTTP_X_APP_LANG'] ?? ''));
            if (defined('BOARDMOA_DOING_API') && $requested !== '') {
                self::$code = self::resolve($requested);
            } else {
                $locale = (string)(function_exists('determine_locale') ? determine_locale() : get_locale());
                self::$code = $locale === '' ? 'ko' : self::resolve($locale);
            }
        }
        return self::$code;
    }

    /**
     * 언어 표시(앱 코드, 워드프레스 locale ko_KR·ja·pt_BR·zh_TW 꼴 등) → 문구 언어. 없는 언어는 영어.
     * 중국어는 번체(Hant·TW·HK·MO)는 zh-Hant, 그 밖(Hans·CN·SG·지역 없는 zh)은 zh-Hans, 포르투갈어는 모두 pt-BR.
     */
    public static function resolve($tag)
    {
        $tag = strtolower(str_replace('_', '-', trim((string)$tag)));
        foreach (self::LANGUAGES as $code) {
            if (strtolower($code) === $tag) {
                return $code;
            }
        }
        $parts = explode('-', $tag);
        $base = $parts[0];
        if ($base === 'pt') {
            return 'pt-BR';
        }
        if ($base === 'jp') {
            return 'ja';
        }
        if ($base === 'in') {
            return 'id';
        }
        if ($base === 'zh') {
            $rest = array_slice($parts, 1);
            $traditional = in_array('hant', $rest, true) || (!in_array('hans', $rest, true) && array_intersect(['tw', 'hk', 'mo'], $rest));
            return $traditional ? 'zh-Hant' : 'zh-Hans';
        }
        return in_array($base, self::LANGUAGES, true) ? $base : 'en';
    }

    /** lang/text.<코드>.php (없으면 빈 표) */
    private static function table($code)
    {
        if (!isset(self::$tables[$code])) {
            $file = BOARDMOA_DIR . '/lang/text.' . $code . '.php';
            self::$tables[$code] = preg_match('/^[A-Za-z-]+$/', $code) && is_file($file) ? (array)include $file : [];
        }
        return self::$tables[$code];
    }

    public static function t($ko, ...$args)
    {
        $text = (string)$ko;
        $code = self::code();
        if ($code !== 'ko') {
            foreach (array_unique([$code, explode('-', $code)[0], 'en']) as $c) {
                $table = self::table($c);
                if (isset($table[$text])) {
                    $text = $table[$text];
                    break;
                }
            }
        }
        foreach ($args as $i => $value) {
            $text = str_replace('{' . $i . '}', (string)$value, $text);
        }
        return $text;
    }
}
