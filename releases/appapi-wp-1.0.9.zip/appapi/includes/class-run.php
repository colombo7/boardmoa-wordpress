<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 웹 처리 함수가 이동(redirect)하며 끝내려 할 때 그 주소를 들고 빠져나온다 */
class BoardMoa_Redirect extends Exception
{
    public $location;

    public function __construct($location)
    {
        parent::__construct('redirect');
        $this->location = (string)$location;
    }
}

/** 웹 처리 함수가 wp_die() 로 끝내려 할 때 그 문구를 들고 빠져나온다 */
class BoardMoa_Died extends Exception
{
    public $title;

    public function __construct($message, $title = '')
    {
        parent::__construct((string)$message);
        $this->title = (string)$title;
    }
}

/**
 * 게시판 플러그인의 웹 처리 함수(글 등록 등)를 그대로 실행한다. 그래서 권한·금지어·포인트·알림 메일·훅이 웹과 같다.
 * 웹 처리 함수는 끝에 이동(wp_redirect)·wp_die()·die('<script>alert(…)</script>') 로 끝나므로:
 *  - wp_redirect 는 필터에서 예외로 바꿔 이동할 주소를 받는다 (exit 앞에서 빠져나온다)
 *  - wp_die 는 처리기를 바꿔 예외로 받는다
 *  - die()/exit 는 막을 수 없어서, 종료 때(shutdown) 찍힌 화면에서 alert 문구를 꺼내 JSON 오류로 바꿔 보낸다 (XE 모듈의 'blocked')
 */
class BoardMoa_Run
{
    /** @var array|null 실행 중인 것: ['code' => 오류 코드, 'status' => HTTP, 'message' => alert 가 없을 때 보일 문구] */
    private static $running = null;

    /** $failMessage: 처리 함수가 alert 없이 화면을 찍고 끝냈을 때(2단계 인증 화면 등) 그 화면 글자 대신 보일 문구 */
    public static function call(callable $fn, $failCode = 'blocked', $failStatus = 403, $failMessage = null)
    {
        $redirectFilter = function ($location) {
            throw new BoardMoa_Redirect($location);
        };
        $dieHandler = function () {
            return function ($message, $title = '', $args = []) {
                if (is_wp_error($message)) {
                    $message = $message->get_error_message();
                }
                throw new BoardMoa_Died(trim(wp_strip_all_tags((string)$message)), is_string($title) ? $title : '');
            };
        };
        add_filter('wp_redirect', $redirectFilter, PHP_INT_MAX);
        foreach (['wp_die_handler', 'wp_die_ajax_handler', 'wp_die_json_handler', 'wp_die_jsonp_handler', 'wp_die_xml_handler'] as $hook) {
            add_filter($hook, $dieHandler, PHP_INT_MAX);
        }
        self::$running = ['code' => $failCode, 'status' => $failStatus, 'message' => $failMessage];
        $level = ob_get_level();
        ob_start();
        $result = ['redirect' => null, 'died' => null, 'value' => null, 'output' => ''];
        try {
            $result['value'] = $fn();
        } catch (BoardMoa_Redirect $e) {
            $result['redirect'] = $e->location;
        } catch (BoardMoa_Died $e) {
            $result['died'] = $e->getMessage();
        } finally {
            $out = '';
            while (ob_get_level() > $level) {
                $out = ob_get_clean() . $out;
            }
            $result['output'] = $out;
            self::$running = null;
            remove_filter('wp_redirect', $redirectFilter, PHP_INT_MAX);
            foreach (['wp_die_handler', 'wp_die_ajax_handler', 'wp_die_json_handler', 'wp_die_jsonp_handler', 'wp_die_xml_handler'] as $hook) {
                remove_filter($hook, $dieHandler, PHP_INT_MAX);
            }
        }
        return $result;
    }

    /** 화면 HTML 에서 사용자에게 보이던 글자 (alert 문구가 있으면 그것) */
    public static function messageOf($html)
    {
        $html = (string)$html;
        if (preg_match_all('/alert\(\s*([\'"])(.*?)(?<!\\\\)\1\s*\)/s', $html, $m)) {
            $text = trim(stripcslashes(end($m[2])));
            if ($text !== '') {
                return html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES, 'UTF-8');
            }
        }
        $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags(preg_replace('#<(script|style)\b.*?</\1>#is', '', $html)), ENT_QUOTES, 'UTF-8')));
        return mb_substr($text, 0, 300);
    }

    /** 종료 때: 웹 처리 함수가 die()/exit 로 끝냈으면 찍힌 화면 대신 JSON 오류 */
    public static function onShutdown()
    {
        if (self::$running === null) {
            return;
        }
        $state = self::$running;
        self::$running = null;
        $out = '';
        while (ob_get_level() > 0) {
            $out = ob_get_clean() . $out;
        }
        $message = self::messageOf($out);
        if (!empty($state['message']) && !preg_match('/alert\(/', $out)) {
            $message = (string)$state['message'];
        }
        if ($message === '') {
            $message = BoardMoa_Text::t('처리하지 못했습니다.');
        }
        BoardMoa_Api::sendJson(['ok' => false, 'error' => ['code' => $state['code'], 'message' => $message]], $state['status']);
        exit; // 워드프레스의 종료 처리(wp_ob_end_flush_all)가 찍힌 화면을 내보내지 않게
    }

    /**
     * 처리 함수가 성공하면 직접 응답을 보내는 경우(파일 내려받기): 그 전에 die()/exit 로 끝나면 찍힌 화면 대신 JSON 오류.
     * 응답을 보내기 시작할 때 release() 를 부른다.
     */
    public static function guard($failCode, $failStatus, $failMessage = null)
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        self::$running = ['code' => $failCode, 'status' => $failStatus, 'message' => $failMessage];
        ob_start();
    }

    /** guard() 를 풀고 그동안 찍힌 것(화면 조각)은 버린다 */
    public static function release()
    {
        if (self::$running === null) {
            return;
        }
        self::$running = null;
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
    }

    public static function isRunning()
    {
        return self::$running !== null;
    }
}
