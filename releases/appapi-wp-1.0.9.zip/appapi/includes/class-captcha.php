<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 워드프레스 로그인·댓글 양식에 CAPTCHA 를 넣는 플러그인 (앱의 captcha_solve 와 같은 길).
 *  - CAPTCHA 4WP (advanced-nocaptcha-recaptcha): 설정의 '양식'에 로그인·댓글이 있을 때. 구글 reCAPTCHA v2 체크박스·Cloudflare Turnstile 은
 *    앱이 위젯을 풀어 captcha_response 로 보내고, 여기서 웹 양식과 같은 이름(g-recaptcha-response·cf-turnstile-response)으로 넘긴다.
 *    확인(구글·Cloudflare 에 묻기)은 플러그인이 한다. v2 보이지 않는 것·v3·hCaptcha 는 앱이 풀 수 없어 위젯 없이 captcha_required(웹으로 안내).
 *  - 그 밖의 플러그인이 같은 오류 코드로 막으면 위젯 없이 captcha_required.
 */
class BoardMoa_Captcha
{
    /** 로그인·댓글을 막는 CAPTCHA 플러그인 오류 코드 */
    const ERROR_CODES = ['c4wp_error', 'gglcptch_error', 'invalid_captcha', 'captcha_error'];

    /**
     * 이 양식(login|comment)을 지키는 CAPTCHA 의 앱 위젯 (없거나 앱이 풀 수 없으면 null).
     * $guarded: CAPTCHA 플러그인이 이 양식을 지키는가
     */
    public static function widget($form, &$guarded = null)
    {
        $guarded = false;
        if (!class_exists('C4WP\\C4WP_Functions')) {
            return null;
        }
        $f = 'C4WP\\C4WP_Functions';
        if (!$f::c4wp_is_form_enabled($form) || trim((string)$f::c4wp_get_secret_key()) === '') {
            return null;
        }
        if ($form === 'comment' && is_user_logged_in() && class_exists('C4WP\\C4WP_Hide_Captcha') && C4WP\C4WP_Hide_Captcha::c4wp_hide_for_logged_in_user_or_role()) {
            return null;
        }
        $guarded = true;
        $version = (string)$f::c4wp_get_option('captcha_version', 'v2_checkbox');
        $siteKey = trim((string)$f::c4wp_get_site_key());
        if ($siteKey === '') {
            return null;
        }
        if ($version === 'v2_checkbox') {
            return ['type' => 'recaptcha', 'site_key' => $siteKey, 'theme' => 'auto', 'size' => 'normal'];
        }
        if ($version === 'cloudflare') {
            return ['type' => 'turnstile', 'site_key' => $siteKey, 'theme' => 'auto', 'size' => 'normal'];
        }
        return null;
    }

    /** 앱이 푼 답을 웹 양식의 이름으로 (플러그인이 $_POST 에서 읽는다) */
    public static function prepare()
    {
        $answer = trim((string)BoardMoa_Api::param('captcha_response', ''));
        if ($answer === '') {
            return '';
        }
        $_POST['g-recaptcha-response'] = $answer;
        $_POST['cf-turnstile-response'] = $answer;
        return $answer;
    }

    /**
     * 보내기 전에: 앱이 풀 수 있는 CAPTCHA 가 이 양식을 지키는데 답이 없으면 403 captcha_required (웹 양식에는 늘 위젯이 있다).
     * 앱이 풀 수 없는 종류는 여기서 막지 않고 플러그인의 판단(isError)을 따른다.
     */
    public static function check($form)
    {
        $widget = self::widget($form);
        $answer = self::prepare();
        if ($widget && $answer === '') {
            throw self::error($form);
        }
    }

    public static function isError($wpError)
    {
        return is_wp_error($wpError) && in_array($wpError->get_error_code(), self::ERROR_CODES, true);
    }

    public static function error($form, $message = null)
    {
        $widget = self::widget($form);
        $text = $message !== null ? $message : ($widget ? BoardMoa_Text::t('자동 입력 방지 확인이 필요합니다.') : BoardMoa_Text::t('이 사이트는 웹에서 자동 입력 방지 확인을 해야 합니다.'));
        return new BoardMoa_Error(403, 'captcha_required', $text, true, ['captcha' => $widget]);
    }
}
