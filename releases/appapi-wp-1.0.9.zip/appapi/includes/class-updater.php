<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 업데이트 확인·스스로 업데이트, 설치 현황 알리기. XE1 모듈·XE3 플러그인과 같은 방식.
 * 공개 저장소(github.com/colombo7/boardmoa-wordpress)의 latest.json 을 읽고, zip 의 SHA-256·전자서명(conf/release-public.pem)을
 * 확인한 뒤 지금 폴더를 wp-content/uploads/boardmoa-backup/ 에 백업하고 덮어쓴다.
 */
class BoardMoa_Updater
{
    const MANIFEST_URL = 'https://raw.githubusercontent.com/colombo7/boardmoa-wordpress/main/latest.json';
    const RELEASE_BASE = 'https://raw.githubusercontent.com/colombo7/boardmoa-wordpress/main/';
    const REGISTRY_URL = 'https://easyapplabs.com/boardmoa/registry.php';

    public static function pluginDir()
    {
        return trailingslashit(str_replace('\\', '/', BOARDMOA_DIR));
    }

    /** 디스크에 적힌 버전 (업데이트 직후에도 맞게) */
    public static function currentVersion()
    {
        $text = (string)@file_get_contents(self::pluginDir() . 'appapi.php');
        return preg_match("/define\('BOARDMOA_VERSION', '([0-9.]+)'\)/", $text, $m) ? $m[1] : BOARDMOA_VERSION;
    }

    /** 개발자에게 알리기 (기본 켬) */
    public static function shareSite()
    {
        return get_option('boardmoa_share_site', 'Y') !== 'N';
    }

    /** 설치 현황: 이 사이트 주소를 게시판모아 개발자 서버에 알린다. 실패해도 조용히 넘어간다 */
    public static function report()
    {
        if (!self::shareSite()) {
            return;
        }
        wp_remote_post(self::REGISTRY_URL, [
            'timeout' => 20, 'blocking' => true, 'user-agent' => 'BoardMoa-appapi-wp',
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode(['url' => trailingslashit(home_url('/')), 'connector' => 'appapi-wp']),
        ]);
    }

    private static function fetch($url)
    {
        for ($try = 1; $try <= 3; $try++) {
            $response = wp_remote_get($url, ['timeout' => 60, 'user-agent' => 'BoardMoa-appapi-wp']);
            if (!is_wp_error($response) && (int)wp_remote_retrieve_response_code($response) === 200) {
                return (string)wp_remote_retrieve_body($response);
            }
            if ($try < 3) {
                sleep(1);
            }
        }
        return false;
    }

    private static function manifest()
    {
        $text = self::fetch(self::MANIFEST_URL . '?t=' . time());
        if ($text === false || $text === '') {
            return BoardMoa_Text::t('업데이트 정보를 받아 오지 못했습니다. 이 서버에서 GitHub(github.com)에 접속할 수 있는지 확인해 주세요.');
        }
        $m = json_decode($text, true);
        if (!is_array($m) || empty($m['version']) || empty($m['zip']) || empty($m['sha256']) || empty($m['signature'])
            || !preg_match('/^[0-9]+(\.[0-9]+){1,3}$/', $m['version']) || !preg_match('#^releases/appapi-wp-[0-9.]+\.zip$#', $m['zip'])) {
            return BoardMoa_Text::t('업데이트 정보 형식이 올바르지 않습니다.');
        }
        if (!empty($m['min_php']) && version_compare(PHP_VERSION, $m['min_php'], '<')) {
            return BoardMoa_Text::t('새 버전을 쓰려면 PHP {0} 이상이 필요합니다. 이 서버의 PHP는 {1}입니다.', $m['min_php'], PHP_VERSION);
        }
        return $m;
    }

    public static function check()
    {
        self::report();
        $result = ['current' => self::currentVersion(), 'latest' => null, 'notes' => '', 'date' => '', 'has_update' => false,
            'is_newer' => false, 'writable' => wp_is_writable(self::pluginDir()), 'zip_available' => class_exists('ZipArchive'), 'error' => null];
        $m = self::manifest();
        if (!is_array($m)) {
            $result['error'] = $m;
            return $result;
        }
        $result['latest'] = $m['version'];
        $result['notes'] = (string)($m['notes'] ?? '');
        $result['date'] = (string)($m['date'] ?? '');
        $result['has_update'] = version_compare($m['version'], $result['current'], '>');
        $result['is_newer'] = version_compare($result['current'], $m['version'], '>');
        return $result;
    }

    private static function verify($data, $signature)
    {
        $public = @file_get_contents(self::pluginDir() . 'conf/release-public.pem');
        $sig = base64_decode((string)$signature, true);
        return $public && $sig !== false && function_exists('openssl_verify') && openssl_verify($data, $sig, $public, OPENSSL_ALGO_SHA256) === 1;
    }

    public static function update()
    {
        $from = self::currentVersion();
        $fail = function ($message) use ($from) {
            return ['ok' => false, 'message' => $message, 'from' => $from, 'to' => null, 'backup' => null];
        };
        if (!class_exists('ZipArchive')) {
            return $fail(BoardMoa_Text::t('서버의 PHP에 zip 확장 기능(ZipArchive)이 없어서 자동 업데이트를 할 수 없습니다.'));
        }
        if (!wp_is_writable(self::pluginDir())) {
            return $fail(BoardMoa_Text::t('플러그인 폴더에 쓰기 권한이 없습니다.'));
        }
        $m = self::manifest();
        if (!is_array($m)) {
            return $fail($m);
        }
        if (!version_compare($m['version'], $from, '>')) {
            return ['ok' => true, 'message' => BoardMoa_Text::t('이미 최신 버전입니다.'), 'from' => $from, 'to' => $from, 'backup' => null];
        }
        $zipData = self::fetch(self::RELEASE_BASE . $m['zip']);
        if ($zipData === false || $zipData === '') {
            return $fail(BoardMoa_Text::t('업데이트 파일을 받지 못했습니다.'));
        }
        if (!hash_equals(strtolower($m['sha256']), hash('sha256', $zipData))) {
            return $fail(BoardMoa_Text::t('내려받은 파일이 손상되었습니다(SHA-256 값이 맞지 않음).'));
        }
        if (!self::verify($zipData, $m['signature'])) {
            return $fail(BoardMoa_Text::t('전자서명이 맞지 않아 업데이트하지 않았습니다.'));
        }
        $tmp = trailingslashit(get_temp_dir()) . 'boardmoa-update-' . wp_generate_password(8, false);
        wp_mkdir_p($tmp);
        file_put_contents($tmp . '/package.zip', $zipData);
        $zip = new ZipArchive();
        if ($zip->open($tmp . '/package.zip') !== true) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('업데이트 파일을 열 수 없습니다.'));
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (strpos($name, 'appapi/') !== 0 || strpos($name, '..') !== false || strpos($name, "\0") !== false) {
                $zip->close();
                self::removeDir($tmp);
                return $fail(BoardMoa_Text::t('업데이트 파일 구성이 올바르지 않습니다.'));
            }
        }
        $zip->extractTo($tmp . '/x');
        $zip->close();
        $source = $tmp . '/x/appapi/';
        if (strpos((string)@file_get_contents($source . 'appapi.php'), "define('BOARDMOA_VERSION', '" . $m['version'] . "')") === false) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('업데이트 파일의 버전이 맞지 않습니다.'));
        }
        $uploads = wp_upload_dir();
        $backup = trailingslashit($uploads['basedir']) . 'boardmoa-backup/' . preg_replace('/[^0-9.]/', '', $from) . '-' . gmdate('YmdHis') . '/';
        if (!wp_mkdir_p($backup) || !self::copyDir(self::pluginDir(), $backup)) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('지금 파일을 백업하지 못해서 업데이트를 중단했습니다.'));
        }
        @file_put_contents(dirname($backup) . '/index.php', "<?php // Silence\n");
        if (!self::copyDir($source, self::pluginDir())) {
            self::copyDir($backup, self::pluginDir());
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('새 파일을 쓰는 중에 오류가 나서 이전 버전으로 되돌렸습니다.'));
        }
        self::removeDir($tmp);
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        return ['ok' => true, 'message' => BoardMoa_Text::t('{0} → {1} 업데이트를 마쳤습니다.', $from, $m['version']), 'from' => $from, 'to' => $m['version'], 'backup' => $backup];
    }

    private static function copyDir($from, $to)
    {
        $from = trailingslashit($from);
        $to = trailingslashit($to);
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($it as $path => $info) {
            $rel = substr(str_replace('\\', '/', $path), strlen($from));
            if (basename($rel) === '.DS_Store') {
                continue;
            }
            if ($info->isDir()) {
                if (!is_dir($to . $rel) && !wp_mkdir_p($to . $rel)) {
                    return false;
                }
            } elseif (!@copy($path, $to . $rel)) {
                return false;
            }
        }
        return true;
    }

    private static function removeDir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $path => $info) {
            $info->isDir() ? @rmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }
}
