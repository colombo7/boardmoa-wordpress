<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * bbPress 포럼. 포럼 = 게시판(forum-<번호>), 토픽 = 글, 답글 = 댓글. 분류 포럼(카테고리)은 메뉴의 묶음.
 * 권한은 bbPress 함수를 쓴다: bbp_user_can_view_forum(공개·비공개·숨김), read_topic·edit_topic·delete_topic·moderate 권한,
 * bbp_current_user_can_publish_topics/replies, bbp_current_user_can_post_in_forums, 포럼·토픽 닫힘.
 * 토픽·답글 등록과 고치기는 웹 양식을 받는 처리 함수(bbp_new_topic_handler 등)를 그대로 실행한다
 * (도배·중복·검토 대기·금지어(토론 설정)·익명 글 규칙이 웹과 같다).
 */
class BoardMoa_BBPress extends BoardMoa_Adapter
{
    private $boards = null;

    public function key()
    {
        return 'bbpress';
    }

    public function available()
    {
        return function_exists('bbpress') && function_exists('bbp_get_forum_post_type');
    }

    public function features()
    {
        return ['guest_write', 'guest_comment'];
    }

    public function boards()
    {
        if ($this->boards === null) {
            $this->boards = [];
            // 모든 포럼 (볼 수 있는지는 canList 가 bbPress 함수로 정한다). get_posts 는 bbPress 가 회원에 따라 걸러 표에서 바로
            global $wpdb;
            $forums = $wpdb->get_results($wpdb->prepare("SELECT ID, post_title, post_parent FROM {$wpdb->posts} WHERE post_type = %s AND post_status IN (%s, %s, %s) ORDER BY menu_order ASC, post_title ASC",
                bbp_get_forum_post_type(), bbp_get_public_status_id(), bbp_get_private_status_id(), bbp_get_hidden_status_id()));
            foreach ($forums as $f) {
                $this->boards['forum-' . $f->ID] = [
                    'mid' => 'forum-' . $f->ID, 'adapter' => 'bbpress', 'module' => 'board', 'ref' => (int)$f->ID, 'parent' => (int)$f->post_parent,
                    'category' => bbp_is_forum_category($f->ID), 'title' => BoardMoa_Html::text($f->post_title), 'url' => get_permalink((int)$f->ID),
                ];
            }
        }
        return $this->boards;
    }

    /** 아래 포럼 메뉴 줄 (분류 포럼은 묶음) */
    private function nodes($parent)
    {
        $out = [];
        foreach ($this->boards() as $b) {
            if ($b['parent'] !== (int)$parent) {
                continue;
            }
            $children = $this->nodes($b['ref']);
            if ($b['category']) {
                $out[] = ['title' => $b['title'], 'url' => '#', 'children' => $children];
            } else {
                $out[] = ['mid' => $b['mid'], 'title' => $b['title'], 'children' => $children];
            }
        }
        return $out;
    }

    public function fromMenuNode($node)
    {
        $type = isset($node['type']) ? $node['type'] : '';
        $object = isset($node['object']) ? $node['object'] : '';
        $id = isset($node['object_id']) ? (int)$node['object_id'] : 0;
        if ($type === 'post_type' && $object === bbp_get_forum_post_type() && $id) {
            $boards = $this->boards();
            if (!isset($boards['forum-' . $id])) {
                return ['mid' => null, 'expand' => null];
            }
            if ($boards['forum-' . $id]['category']) {
                return ['mid' => null, 'expand' => $this->nodes($id)];
            }
            return ['mid' => 'forum-' . $id, 'expand' => $this->nodes($id)];
        }
        if ($type === 'post_type_archive' && $object === bbp_get_forum_post_type()) {
            return ['mid' => null, 'expand' => $this->nodes(0)];
        }
        // 포럼 목록 페이지 ([bbp-forum-index]) 또는 포럼 첫 화면 주소
        if ($type === 'post_type' && $id && ($post = get_post($id)) && $post->post_type === 'page' && has_shortcode($post->post_content, 'bbp-forum-index')) {
            return ['mid' => null, 'expand' => $this->nodes(0)];
        }
        if ($type === 'custom' && !empty($node['url']) && untrailingslashit(BoardMoa_Html::absolute($node['url'])) === untrailingslashit(bbp_get_forums_url())) {
            return ['mid' => null, 'expand' => $this->nodes(0)];
        }
        return null;
    }

    public function menuBoards()
    {
        $nodes = $this->nodes(0);
        return $nodes ? [['title' => BoardMoa_Text::t('포럼'), 'url' => '#', 'children' => $nodes]] : [];
    }

    public function canList($board)
    {
        $id = (int)$board['ref'];
        if (!empty($board['category'])) {
            return false;
        }
        if (function_exists('bbp_get_password_required_id') && bbp_get_password_required_id($id)) {
            return false; // 비밀번호 포럼은 웹에서
        }
        return (bool)bbp_user_can_view_forum(['forum_id' => $id]);
    }

    private function canPublishTopic($id)
    {
        $ok = bbp_is_user_keymaster() || (bbp_is_forum_open($id) && bbp_current_user_can_publish_topics());
        return $ok && bbp_current_user_can_post_in_forums();
    }

    public function grant($board)
    {
        $id = (int)$board['ref'];
        $list = $this->canList($board);
        return [
            'list' => $list,
            'view' => $list,
            'write_document' => $list && $this->canPublishTopic($id),
            'write_comment' => $list && (bbp_is_user_keymaster() || (bbp_is_forum_open($id) && bbp_current_user_can_publish_replies())) && bbp_current_user_can_post_in_forums(),
            'manager' => current_user_can('moderate', $id),
        ];
    }

    private function info($board, $grant)
    {
        $anon = !is_user_logged_in() && bbp_allow_anonymous();
        return $this->boardInfo($board, $grant, [
            'style' => 'list',
            'columns' => ['read_count' => false, 'vote_count' => false],
            'write_url' => $board['url'],
            'guest_fields' => ($grant['write_document'] && $anon) ? ['nick_name', 'email_address'] : null,
            'guest_comment_fields' => ($grant['write_comment'] && $anon) ? ['nick_name', 'email_address'] : null,
            'guest_certify_fields' => null,
        ]);
    }

    public function listPage($board)
    {
        $grant = $this->grant($board);
        list($page, $perPage) = self::pageArgs(bbp_get_topics_per_page());
        list($keyword) = self::search();
        $args = ['post_parent' => (int)$board['ref'], 'paged' => $page, 'posts_per_page' => $perPage, 'show_stickies' => $page === 1 && $keyword === '', 'max_num_pages' => false];
        if ($keyword !== '') {
            $args['s'] = $keyword;
        }
        $notices = [];
        $documents = [];
        $total = 0;
        $pages = 1;
        if (bbp_has_topics($args)) {
            $q = bbpress()->topic_query;
            foreach ($q->posts as $topic) {
                $s = $this->summarize($topic);
                if ($s['is_notice'] && $page === 1) {
                    $notices[] = $s;
                } else {
                    $documents[] = $s;
                }
            }
            $total = (int)$q->found_posts;
            $pages = max(1, (int)$q->max_num_pages);
        }
        return ['board' => $this->info($board, $grant), 'notices' => $notices, 'documents' => $documents, 'page' => $page, 'total_pages' => $pages, 'total_count' => $total];
    }

    public function recent($board, $limit)
    {
        $out = [];
        if (bbp_has_topics(['post_parent' => (int)$board['ref'], 'posts_per_page' => $limit, 'show_stickies' => false, 'orderby' => 'date', 'max_num_pages' => false])) {
            foreach (bbpress()->topic_query->posts as $topic) {
                $out[] = ['time' => (int)get_post_time('U', true, $topic), 'summary' => $this->summarize($topic)];
            }
        }
        return $out;
    }

    private function summarize($topic)
    {
        $id = (int)$topic->ID;
        $uid = get_current_user_id();
        $anonymous = bbp_is_topic_anonymous($id);
        return $this->summary([
            'document_srl' => $id,
            'title' => BoardMoa_Html::text(bbp_get_topic_title($id)),
            'author' => BoardMoa_Html::text(bbp_get_topic_author_display_name($id)),
            'author_image' => $anonymous ? null : BoardMoa_Api::avatar($topic->post_author),
            'author_srl' => $anonymous ? 0 : (int)$topic->post_author,
            'is_mine' => $uid && !$anonymous && (int)$topic->post_author === $uid,
            'regdate' => BoardMoa_Html::iso($topic->post_date),
            'last_update' => BoardMoa_Html::iso(get_post_meta($id, '_bbp_last_active_time', true) ?: $topic->post_modified),
            'comment_count' => (int)bbp_get_topic_reply_count($id, true),
            'is_notice' => bbp_is_topic_sticky($id),
            'summary' => BoardMoa_Html::summary($topic->post_content),
        ]);
    }

    /** 웹 토픽 화면과 같은 판단: 이 포럼의 토픽이고, 포럼을 볼 수 있고, read_topic (공개 상태, 또는 글쓴이·관리자) */
    private function topic($board, $srl)
    {
        $topic = get_post((int)$srl);
        if (!$topic || $topic->post_type !== bbp_get_topic_post_type() || (int)bbp_get_topic_forum_id($topic->ID) !== (int)$board['ref']) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        // 공개 상태(공개·닫힘)는 포럼을 볼 수 있으면 누구나. 그 밖(검토 대기·스팸·비공개)은 read_topic (글쓴이·관리자)
        $public = in_array($topic->post_status, bbp_get_public_topic_statuses(), true);
        if ((!$public && !current_user_can('read_topic', $topic->ID)) || in_array($topic->post_status, ['trash', 'draft', 'auto-draft'], true)) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        return $topic;
    }

    /** 웹의 고치기 링크와 같은 판단: edit_topic 권한 + (관리자가 아니면) 고칠 수 있는 시간 안 */
    private static function canEdit($post, $cap)
    {
        if (!current_user_can($cap, $post->ID)) {
            return false;
        }
        return current_user_can('moderate', $post->ID) || !bbp_past_edit_lock($post->post_date_gmt);
    }

    public function document($board, $srl)
    {
        $topic = $this->topic($board, $srl);
        $grant = $this->grant($board);
        $id = (int)$topic->ID;
        $canReply = $grant['write_comment'] && (bbp_is_user_keymaster() || (bbp_is_topic_open($id) && bbp_is_topic_published($id)));
        return $this->detail($this->summarize($topic), [
            'content_html' => BoardMoa_Html::content(bbp_get_topic_content($id)),
            'permanent_url' => bbp_get_topic_permalink($id),
            'can_comment' => $canReply,
            'can_edit' => self::canEdit($topic, 'edit_topic'),
            'can_delete' => current_user_can('delete_topic', $id),
            'board' => $this->info($board, $grant),
            'comments' => $this->replyPage($topic),
        ]);
    }

    public function comments($board, $srl)
    {
        return $this->replyPage($this->topic($board, $srl));
    }

    /** 답글: 웹 토픽 화면과 같은 bbp_has_replies (공개 상태, 관리자는 전부), 답글의 답글은 _bbp_reply_to 로 깊이 */
    private function replyPage($topic)
    {
        $perPage = 100;
        $page = max(1, BoardMoa_Api::intParam('cpage', 1));
        $items = [];
        $total = 0;
        $pages = 1;
        if (bbp_has_replies(['post_parent' => $topic->ID, 'post_type' => bbp_get_reply_post_type(), 'paged' => $page, 'posts_per_page' => $perPage, 'hierarchical' => false])) {
            $q = bbpress()->reply_query;
            $threaded = bbp_thread_replies();
            $maxDepth = $threaded ? max(1, (int)bbp_thread_replies_depth()) : 1;
            $uid = get_current_user_id();
            foreach ($q->posts as $reply) {
                $rid = (int)$reply->ID;
                $to = $threaded ? (int)bbp_get_reply_to($rid) : 0;
                $depth = 0;
                for ($p = $to; $p && $depth < 20; $p = (int)bbp_get_reply_to($p)) {
                    $depth++;
                }
                $anonymous = bbp_is_reply_anonymous($rid);
                $items[] = $this->commentItem([
                    'comment_srl' => $rid,
                    'parent_srl' => $to,
                    'depth' => min($depth, $maxDepth - 1),
                    'author' => BoardMoa_Html::text(bbp_get_reply_author_display_name($rid)),
                    'author_image' => $anonymous ? null : BoardMoa_Api::avatar($reply->post_author),
                    'author_srl' => $anonymous ? 0 : (int)$reply->post_author,
                    'is_mine' => $uid && !$anonymous && (int)$reply->post_author === $uid,
                    'regdate' => BoardMoa_Html::iso($reply->post_date),
                    'content_html' => BoardMoa_Html::content(bbp_get_reply_content($rid)),
                    'can_edit' => self::canEdit($reply, 'edit_reply'),
                    'can_delete' => current_user_can('delete_reply', $rid),
                ]);
            }
            $total = (int)$q->found_posts;
            $pages = max(1, (int)ceil($total / $perPage));
        }
        return ['items' => $items, 'page' => $page, 'total_pages' => $pages, 'total_count' => $total];
    }

    public function boardOfDocument($srl)
    {
        $post = get_post((int)$srl);
        if (!$post || $post->post_type !== bbp_get_topic_post_type()) {
            return null;
        }
        $boards = $this->boards();
        $key = 'forum-' . (int)bbp_get_topic_forum_id($post->ID);
        return isset($boards[$key]) ? $boards[$key] : null;
    }

    public function locate($url)
    {
        $id = url_to_postid($url);
        $post = $id ? get_post($id) : null;
        if (!$post) {
            return null;
        }
        if ($post->post_type === bbp_get_forum_post_type()) {
            return ['mid' => 'forum-' . $post->ID];
        }
        if ($post->post_type === bbp_get_topic_post_type()) {
            return ['mid' => 'forum-' . (int)bbp_get_topic_forum_id($post->ID), 'document_srl' => (int)$post->ID];
        }
        if ($post->post_type === bbp_get_reply_post_type()) {
            return ['mid' => 'forum-' . (int)bbp_get_reply_forum_id($post->ID), 'document_srl' => (int)bbp_get_reply_topic_id($post->ID)];
        }
        return null;
    }

    // ---- 쓰기 (웹 양식 처리 함수를 그대로)

    /** bbPress 처리 함수 실행. [$id(훅에서 받은 새 글 번호), 오류 문구] */
    private function runHandler($handler, $action, array $post, $hook)
    {
        $_POST = wp_slash($post);
        $_REQUEST = $_POST;
        bbpress()->errors = new WP_Error();
        $captured = 0;
        $catch = function ($id) use (&$captured) {
            $captured = (int)$id;
        };
        if ($hook) {
            add_action($hook, $catch, 1);
        }
        $run = BoardMoa_Run::call(function () use ($handler, $action) {
            call_user_func($handler, $action);
        });
        if ($hook) {
            remove_action($hook, $catch, 1);
        }
        $messages = [];
        foreach (bbpress()->errors->get_error_codes() as $code) {
            if (in_array($code, ['bbp_topic_moderated', 'bbp_reply_moderated'], true)) {
                continue;
            }
            $messages[] = BoardMoa_Html::text(str_replace(['<strong>', '</strong>'], '', bbpress()->errors->get_error_message($code)));
        }
        if ($run['died'] !== null) {
            $messages[] = $run['died'];
        }
        return [$captured, $messages, $run];
    }

    private function anonymousFields(array &$post)
    {
        if (is_user_logged_in()) {
            return;
        }
        $name = trim((string)BoardMoa_Api::param('nick_name', ''));
        $email = trim((string)BoardMoa_Api::param('email_address', ''));
        if ($name === '' && $email === '') {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if ($name === '' || $email === '') {
            throw new BoardMoa_Error(400, 'guest_info_required', '이름과 메일을 입력해 주세요.');
        }
        $post['bbp_anonymous_name'] = $name;
        $post['bbp_anonymous_email'] = $email;
        $post['bbp_anonymous_website'] = '';
    }

    public function write($board)
    {
        $grant = $this->grant($board);
        if (!$grant['write_document']) {
            throw BoardMoa_Api::denied();
        }
        $title = trim((string)BoardMoa_Api::param('title', ''));
        // bbPress 웹 양식은 글자 칸(허용 태그 몇 개만, 나머지는 bbPress 가 글자로 바꾼다)이고 보일 때 문단을 나눈다: 일반 글자는 그대로 넘긴다
        $content = BoardMoa_Api::param('content_format') === 'html' ? BoardMoa_Html::fromEditor(BoardMoa_Api::param('content', '')) : trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        if ($title === '' || $content === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        if (self::photos()) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        $post = ['action' => 'bbp-new-topic', 'bbp_topic_title' => $title, 'bbp_topic_content' => $content, 'bbp_forum_id' => (int)$board['ref'],
            '_wpnonce' => wp_create_nonce('bbp-new-topic')];
        $this->anonymousFields($post);
        list($id, $messages) = $this->runHandler('bbp_new_topic_handler', 'bbp-new-topic', $post, 'bbp_new_topic');
        if (!$id) {
            throw new BoardMoa_Error(400, 'write_failed', $messages ? implode(' ', $messages) : BoardMoa_Text::t('글을 저장하지 못했습니다.'), (bool)$messages);
        }
        return ['document_srl' => $id];
    }

    private function editableTopic($board, $srl)
    {
        $topic = $this->topic($board, $srl);
        if (!self::canEdit($topic, 'edit_topic')) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        return $topic;
    }

    public function source($board, $srl)
    {
        $topic = $this->editableTopic($board, $srl);
        return [
            'document_srl' => (int)$topic->ID, 'title' => (string)$topic->post_title, 'content' => (string)$topic->post_content,
            'base_url' => trailingslashit(home_url('/')), 'manage' => null, 'category_srl' => 0, 'extra_keys' => [], 'extra_values' => (object)[],
            'board' => $this->info($board, $this->grant($board)), 'upload' => ['allowed' => false, 'max_file_size' => null, 'max_total_size' => null],
        ];
    }

    public function update($board, $srl)
    {
        $topic = $this->editableTopic($board, $srl);
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $content = (string)BoardMoa_Api::param('content', '');
        if ($title === '' || trim(wp_strip_all_tags($content)) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $post = ['action' => 'bbp-edit-topic', 'bbp_topic_id' => (int)$topic->ID, 'bbp_topic_title' => $title, 'bbp_topic_content' => $content,
            'bbp_forum_id' => (int)$board['ref'], '_wpnonce' => wp_create_nonce('bbp-edit-topic_' . (int)$topic->ID)];
        list(, $messages, $run) = $this->runHandler('bbp_edit_topic_handler', 'bbp-edit-topic', $post, null);
        if ($run['redirect'] === null || $messages) {
            throw new BoardMoa_Error(400, 'update_failed', $messages ? implode(' ', $messages) : BoardMoa_Text::t('글을 저장하지 못했습니다.'), (bool)$messages);
        }
        return ['document_srl' => (int)$topic->ID];
    }

    public function delete($board, $srl)
    {
        $topic = $this->topic($board, $srl);
        // 웹의 '휴지통' 링크와 같은 권한 (delete_topic). 휴지통으로 옮기면 bbPress 가 답글·수를 정리한다
        if (!current_user_can('delete_topic', $topic->ID)) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!wp_trash_post($topic->ID)) {
            throw new BoardMoa_Error(400, 'delete_failed', '지우지 못했습니다.');
        }
        return ['deleted' => true];
    }

    public function commentWrite($board, $srl)
    {
        $topic = $this->topic($board, $srl);
        $grant = $this->grant($board);
        $id = (int)$topic->ID;
        if (!$grant['write_comment'] || !(bbp_is_user_keymaster() || (bbp_is_topic_open($id) && bbp_is_topic_published($id)))) {
            throw BoardMoa_Api::denied();
        }
        $text = (string)BoardMoa_Api::param('content', '');
        if (trim($text) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $post = ['action' => 'bbp-new-reply', 'bbp_reply_content' => trim(str_replace(["\r\n", "\r"], "\n", $text)), 'bbp_topic_id' => $id, 'bbp_forum_id' => (int)$board['ref'],
            '_wpnonce' => wp_create_nonce('bbp-new-reply')];
        if ($parent = BoardMoa_Api::intParam('parent_srl')) {
            $post['bbp_reply_to'] = $parent;
        }
        $this->anonymousFields($post);
        list($rid, $messages) = $this->runHandler('bbp_new_reply_handler', 'bbp-new-reply', $post, 'bbp_new_reply');
        if (!$rid) {
            throw new BoardMoa_Error(400, 'comment_failed', $messages ? implode(' ', $messages) : BoardMoa_Text::t('댓글을 쓰지 못했습니다.'), (bool)$messages);
        }
        return ['comment_srl' => $rid, 'document_srl' => $id, 'pending' => bbp_get_reply_status($rid) === bbp_get_pending_status_id()];
    }

    private function reply($board, $commentSrl)
    {
        $reply = get_post((int)$commentSrl);
        if (!$reply || $reply->post_type !== bbp_get_reply_post_type()) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        $this->topic($board, (int)bbp_get_reply_topic_id($reply->ID));
        if (!in_array($reply->post_status, bbp_get_public_reply_statuses(), true) && !current_user_can('read_reply', $reply->ID)) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        return $reply;
    }

    public function commentUpdate($board, $commentSrl)
    {
        $reply = $this->reply($board, $commentSrl);
        if (!self::canEdit($reply, 'edit_reply')) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $text = (string)BoardMoa_Api::param('content', '');
        if (trim($text) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $post = ['action' => 'bbp-edit-reply', 'bbp_reply_id' => (int)$reply->ID, 'bbp_reply_content' => trim(str_replace(["\r\n", "\r"], "\n", $text)),
            'bbp_reply_to' => (int)bbp_get_reply_to($reply->ID), '_wpnonce' => wp_create_nonce('bbp-edit-reply_' . (int)$reply->ID)];
        list(, $messages, $run) = $this->runHandler('bbp_edit_reply_handler', 'bbp-edit-reply', $post, null);
        if ($run['redirect'] === null || $messages) {
            throw new BoardMoa_Error(400, 'update_failed', $messages ? implode(' ', $messages) : BoardMoa_Text::t('댓글을 고치지 못했습니다.'), (bool)$messages);
        }
        return ['comment_srl' => (int)$reply->ID, 'document_srl' => (int)bbp_get_reply_topic_id($reply->ID)];
    }

    public function commentDelete($board, $commentSrl)
    {
        $reply = $this->reply($board, $commentSrl);
        if (!current_user_can('delete_reply', $reply->ID)) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!wp_trash_post($reply->ID)) {
            throw new BoardMoa_Error(400, 'delete_failed', '지우지 못했습니다.');
        }
        return ['deleted' => true];
    }

    // ---- 내 활동

    private function myPosts($type, $limit)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->posts} WHERE post_type = %s AND post_author = %d AND post_status IN ('publish','closed','pending') ORDER BY post_date DESC LIMIT %d", $type, get_current_user_id(), $limit));
    }

    public function myDocuments($limit)
    {
        $boards = $this->boards();
        $out = [];
        foreach ((array)$this->myPosts(bbp_get_topic_post_type(), $limit) as $row) {
            $key = 'forum-' . (int)bbp_get_topic_forum_id($row->ID);
            if (!isset($boards[$key]) || !$this->canList($boards[$key])) {
                continue;
            }
            $s = $this->summarize(get_post($row->ID));
            $s['mid'] = $key;
            $s['board_title'] = $boards[$key]['title'];
            $out[] = ['time' => strtotime($row->post_date_gmt . ' UTC'), 'summary' => $s];
        }
        return $out;
    }

    public function myComments($limit)
    {
        $boards = $this->boards();
        $out = [];
        foreach ((array)$this->myPosts(bbp_get_reply_post_type(), $limit) as $row) {
            $key = 'forum-' . (int)bbp_get_reply_forum_id($row->ID);
            if (!isset($boards[$key]) || !$this->canList($boards[$key])) {
                continue;
            }
            $topic = (int)bbp_get_reply_topic_id($row->ID);
            $out[] = ['time' => strtotime($row->post_date_gmt . ' UTC'), 'comment' => [
                'comment_srl' => (int)$row->ID, 'document_srl' => $topic, 'content' => BoardMoa_Html::summary($row->post_content, 200),
                'regdate' => BoardMoa_Html::iso($row->post_date), 'is_secret' => false, 'document_title' => BoardMoa_Html::text(get_the_title($topic)),
                'mid' => $key, 'board_title' => $boards[$key]['title'],
            ]];
        }
        return $out;
    }
}
