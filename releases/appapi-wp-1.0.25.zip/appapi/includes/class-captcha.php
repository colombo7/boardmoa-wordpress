<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 워드프레스 로그인·댓글 양식에 CAPTCHA 를 넣는 플러그인 (앱의 captcha_solve 와 같은 길).
 *  - CAPTCHA 4WP (advanced-nocaptcha-recaptcha): 설정의 '양식'에 로그인·댓글이 있을 때. 구글 reCAPTCHA v2 체크박스·Cloudflare Turnstile 은
 *    앱이 위젯을 풀어 captcha_response 로 보내고, 여기서 웹 양식과 같은 이름(g-recaptcha-response·cf-turnstile-response)으로 넘긴다.
 *    확인(구글·Cloudflare 에 묻기)은 플러그인이 한다. v2 보이지 않는 것·v3·hCaptcha 는 앱이 풀 수 없어 위젯 없이 captcha_required(웹으로 안내).
 *  - 그 밖의 플러그인이 같은 오류 코드로 막으면 위젯 없이 captcha_required.
 */
class BoardMoa_Captcha
{
    /** 로그인·댓글을 막는 CAPTCHA 플러그인 오류 코드 */
    const ERROR_CODES = ['c4wp_error', 'gglcptch_error', 'invalid_captcha', 'captcha_error'];

    /**
     * 이 양식(login|comment)을 지키는 CAPTCHA 의 앱 위젯 (없거나 앱이 풀 수 없으면 null).
     * $guarded: CAPTCHA 플러그인이 이 양식을 지키는가
     */
    public static function widget($form, &$guarded = null)
    {
        $guarded = false;
        if (!class_exists('C4WP\\C4WP_Functions')) {
            return null;
        }
        $f = 'C4WP\\C4WP_Functions';
        if (!$f::c4wp_is_form_enabled($form) || trim((string)$f::c4wp_get_secret_key()) === '') {
            return null;
        }
        if ($form === 'comment' && is_user_logged_in() && class_exists('C4WP\\C4WP_Hide_Captcha') && C4WP\C4WP_Hide_Captcha::c4wp_hide_for_logged_in_user_or_role()) {
            return null;
        }
        $guarded = true;
        $version = (string)$f::c4wp_get_option('captcha_version', 'v2_checkbox');
        $siteKey = trim((string)$f::c4wp_get_site_key());
        if ($siteKey === '') {
            return null;
        }
        if ($version === 'v2_checkbox') {
            return ['type' => 'recaptcha', 'site_key' => $siteKey, 'theme' => 'auto', 'size' => 'normal'];
        }
        if ($version === 'cloudflare') {
            return ['type' => 'turnstile', 'site_key' => $siteKey, 'theme' => 'auto', 'size' => 'normal'];
        }
        return null;
    }

    /** 앱이 푼 답을 웹 양식의 이름으로 (플러그인이 $_POST 에서 읽는다) */
    public static function prepare()
    {
        $answer = trim((string)BoardMoa_Api::param('captcha_response', ''));
        if ($answer === '') {
            return '';
        }
        $_POST['g-recaptcha-response'] = $answer;
        $_POST['cf-turnstile-response'] = $answer;
        return $answer;
    }

    /**
     * 보내기 전에: 앱이 풀 수 있는 CAPTCHA 가 이 양식을 지키는데 답이 없으면 403 captcha_required (웹 양식에는 늘 위젯이 있다).
     * 앱이 풀 수 없는 종류는 여기서 막지 않고 플러그인의 판단(isError)을 따른다.
     */
    public static function check($form)
    {
        $widget = self::widget($form);
        $answer = self::prepare();
        if ($widget && $answer === '') {
            throw self::error($form);
        }
    }

    public static function isError($wpError)
    {
        return is_wp_error($wpError) && in_array($wpError->get_error_code(), self::ERROR_CODES, true);
    }

    public static function error($form, $message = null)
    {
        $widget = self::widget($form);
        $text = $message !== null ? $message : ($widget ? BoardMoa_Text::t('자동 입력 방지 확인이 필요합니다.') : BoardMoa_Text::t('이 사이트는 웹에서 자동 입력 방지 확인을 해야 합니다.'));
        return new BoardMoa_Error(403, 'captcha_required', $text, true, ['captcha' => $widget]);
    }

    // ---- 그림 글자 CAPTCHA (KBoard·망보드): 앱이 그림을 받아 사람이 읽은 글자를 '번호:답' 으로 보낸다

    /** 그림 CAPTCHA 를 풀 줄 아는 앱(2.0.4~)은 X-App-Captcha: image 를 보낸다. 예전 앱에는 그림 위젯을 주지 않는다(예전처럼 웹 안내) */
    public static function appSolvesImage()
    {
        $h = isset($_SERVER['HTTP_X_APP_CAPTCHA']) ? strtolower((string)$_SERVER['HTTP_X_APP_CAPTCHA']) : '';
        return in_array('image', array_map('trim', explode(',', $h)), true);
    }

    /** 그림 위젯 (앱이 image_url 로 captcha.image 를 부른다). 예전 앱이면 null */
    public static function imageWidget($mid, $for, $length, $input)
    {
        if (!self::appSolvesImage()) {
            return null;
        }
        $url = add_query_arg(['r' => 'captcha.image', 'mid' => (string)$mid, 'for' => $for], plugins_url('api.php', BOARDMOA_FILE));
        return ['type' => 'image', 'site_key' => '', 'theme' => 'auto', 'size' => 'normal', 'image_url' => $url, 'length' => (int)$length, 'input' => $input];
    }

    /**
     * 그림과 답: 웹은 답을 세션에 두는데 앱 요청은 세션이 이어지지 않아 번호별로 10분 둔다(한 번 쓰면 지움).
     * 답 확인은 쓸 때 그 값을 게시판 플러그인이 보는 세션 자리에 넣고 플러그인이 한다.
     */
    public static function imageResult($answer, $bytes, $length, $input)
    {
        $id = bin2hex(random_bytes(16));
        set_transient('boardmoa_cap_' . hash('sha256', $id), (string)$answer, 600);
        $mime = substr($bytes, 0, 3) === "\xFF\xD8\xFF" ? 'image/jpeg' : (substr($bytes, 0, 4) === 'GIF8' ? 'image/gif' : 'image/png');
        return ['id' => $id, 'image' => 'data:' . $mime . ';base64,' . base64_encode($bytes), 'length' => (int)$length, 'input' => $input];
    }

    /** 앱이 보낸 '번호:답' → [그 번호의 답, 사람이 읽은 글자]. 번호가 없거나 지났으면 null */
    public static function take($response)
    {
        $parts = explode(':', (string)$response, 2);
        if (count($parts) !== 2 || !preg_match('/^[0-9a-f]{32}$/', $parts[0])) {
            return null;
        }
        $key = 'boardmoa_cap_' . hash('sha256', $parts[0]);
        $stored = get_transient($key);
        delete_transient($key);
        return ($stored === false || $stored === '') ? null : [(string)$stored, trim($parts[1])];
    }

    /** 게시판 플러그인이 답을 세션에서 읽는다: 쿠키 없는 이번 요청만의 세션 */
    public static function session()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_start();
        }
    }
}
